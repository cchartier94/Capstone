-- Esquema Base de Datos FitAI
-- Optimizado para PostgreSQL

-- ==========================================
-- 1. Módulo de Usuarios y Perfil
-- ==========================================

CREATE TABLE usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    correo_electronico VARCHAR(255) UNIQUE NOT NULL,
    contrasena VARCHAR(255),
    fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE perfiles_usuario (
    usuario_id UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    nombre VARCHAR(100) NOT NULL,
    edad INTEGER NOT NULL,
    sexo_biologico VARCHAR(50) NOT NULL,
    peso_actual_kg DECIMAL(5,2) NOT NULL,
    estatura_cm DECIMAL(5,2) NOT NULL,
    objetivo_principal VARCHAR(100) NOT NULL, -- Ej: Bajar grasa, Ganar masa muscular...
    nivel_actividad VARCHAR(100) NOT NULL,
    nivel_experiencia VARCHAR(100) NOT NULL,
    lugar_entrenamiento VARCHAR(100) NOT NULL,
    tipo_entrenamiento VARCHAR(100) NOT NULL,
    dias_disponibles_semana INTEGER NOT NULL,
    tiempo_por_sesion_minutos INTEGER NOT NULL,
    condiciones_salud TEXT,
    tipo_dieta VARCHAR(100),
    preferencias_alimenticias TEXT,
    alimentos_excluidos TEXT
);

CREATE TABLE configuracion_usuario (
    usuario_id UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    unidad_peso VARCHAR(10) DEFAULT 'kg',
    notificaciones_activas BOOLEAN DEFAULT TRUE,
    recordatorios_entrenamiento BOOLEAN DEFAULT TRUE,
    recordatorios_alimentacion BOOLEAN DEFAULT TRUE
);

-- ==========================================
-- 2. Módulo de Planes
-- ==========================================

CREATE TABLE planes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE,
    fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    duracion_meses INTEGER NOT NULL,
    objetivo_seleccionado VARCHAR(100) NOT NULL,
    estado VARCHAR(50) DEFAULT 'activo', -- activo, completado, cancelado
    respuesta_raw_ia JSONB -- Se guarda el JSON generado por Claude
);

-- ==========================================
-- 3. Módulo de Entrenamiento
-- ==========================================

CREATE TABLE semanas_entrenamiento (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id UUID REFERENCES planes(id) ON DELETE CASCADE,
    numero_semana INTEGER NOT NULL,
    enfoque_semana VARCHAR(255)
);

CREATE TABLE dias_entrenamiento (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    semana_entrenamiento_id UUID REFERENCES semanas_entrenamiento(id) ON DELETE CASCADE,
    numero_dia INTEGER NOT NULL,
    es_dia_descanso BOOLEAN DEFAULT FALSE
);

CREATE TABLE ejercicios_catalogo (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(150) NOT NULL,
    grupo_muscular VARCHAR(100),
    descripcion TEXT,
    instrucciones TEXT,
    equipamiento_necesario VARCHAR(150),
    url_video_imagen VARCHAR(500)
);

CREATE TABLE ejercicios_planificados (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dia_entrenamiento_id UUID REFERENCES dias_entrenamiento(id) ON DELETE CASCADE,
    ejercicio_catalogo_id UUID REFERENCES ejercicios_catalogo(id) ON DELETE SET NULL,
    series_objetivo INTEGER,
    repeticiones_objetivo VARCHAR(50), -- String para "Al fallo", o "10-12"
    descanso_objetivo_segundos INTEGER,
    orden_rutina INTEGER NOT NULL
);

-- ==========================================
-- 4. Módulo de Nutrición
-- ==========================================

CREATE TABLE dias_nutricion (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id UUID REFERENCES planes(id) ON DELETE CASCADE,
    numero_dia INTEGER NOT NULL
);

CREATE TABLE comidas_planificadas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dia_nutricion_id UUID REFERENCES dias_nutricion(id) ON DELETE CASCADE,
    tipo_comida VARCHAR(50) NOT NULL, -- Desayuno, Almuerzo, Cena, Snack
    nombre VARCHAR(200) NOT NULL,
    calorias INTEGER,
    proteinas_g DECIMAL(5,2),
    carbohidratos_g DECIMAL(5,2),
    grasas_g DECIMAL(5,2),
    ingredientes JSONB, -- Formato esperado: [{"ingrediente": "Pollo", "cantidad": "100g"}]
    pasos_preparacion TEXT
);

-- ==========================================
-- 5. Seguimiento, Métricas y Coach
-- ==========================================

CREATE TABLE registros_entrenamiento (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE,
    dia_entrenamiento_id UUID REFERENCES dias_entrenamiento(id) ON DELETE CASCADE,
    fecha_ejecucion DATE DEFAULT CURRENT_DATE,
    puntaje_adherencia INTEGER,
    notas_sensaciones TEXT
);

CREATE TABLE registros_ejercicios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    registro_entrenamiento_id UUID REFERENCES registros_entrenamiento(id) ON DELETE CASCADE,
    ejercicio_planificado_id UUID REFERENCES ejercicios_planificados(id) ON DELETE CASCADE,
    series_completadas INTEGER,
    repeticiones_completadas INTEGER,
    peso_utilizado_kg DECIMAL(5,2),
    tiempo_descanso_segundos INTEGER
);

CREATE TABLE metricas_fisicas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE,
    fecha_registro DATE DEFAULT CURRENT_DATE,
    peso_corporal_kg DECIMAL(5,2),
    medida_cintura_cm DECIMAL(5,2),
    medida_pecho_cm DECIMAL(5,2),
    medida_cadera_cm DECIMAL(5,2),
    medida_brazos_cm DECIMAL(5,2),
    medida_piernas_cm DECIMAL(5,2),
    pasos_diarios INTEGER,
    calorias_quemadas DECIMAL(8,2)
);

CREATE TABLE sesiones_chat (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE,
    fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE mensajes_chat (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sesion_chat_id UUID REFERENCES sesiones_chat(id) ON DELETE CASCADE,
    remitente VARCHAR(50) NOT NULL, -- 'usuario' o 'ia'
    contenido TEXT NOT NULL,
    fecha_envio TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);


-- ==========================================
-- DATOS SEMILLA / HARDCODED 
-- (Para pruebas e inicio rápido de Onboarding)
-- ==========================================

-- Insertar un usuario por defecto (Carlos Avanzado)
INSERT INTO usuarios (id, correo_electronico, contrasena) 
VALUES ('11111111-1111-1111-1111-111111111111', 'carlos.avanzado@fitai.test', '$2b$12$OsqP45QqwlPSrZRIH6RdC.BD/dG6mn4J6esU.UFi0hAKP/xNr6EC6');

-- Perfil inicial para este usuario (Carlos Avanzado)
INSERT INTO perfiles_usuario (
    usuario_id, nombre, edad, sexo_biologico, peso_actual_kg, estatura_cm, objetivo_principal,
    nivel_actividad, nivel_experiencia, lugar_entrenamiento, tipo_entrenamiento, dias_disponibles_semana, 
    tiempo_por_sesion_minutos, condiciones_salud, tipo_dieta, preferencias_alimenticias, alimentos_excluidos
) VALUES (
    '11111111-1111-1111-1111-111111111111', 'Carlos Martínez', 30, 'Masculino', 86.0, 180, 'Bajar grasa',
    'Activo', 'Avanzado', 'Gimnasio', 'Pesas', 5, 60, 
    'Ninguna', 'Sin restricciones', 'Me gusta la pasta y el pollo', 'Mariscos'
);

-- Configuración inicial
INSERT INTO configuracion_usuario (usuario_id, unidad_peso)
VALUES ('11111111-1111-1111-1111-111111111111', 'kg');

-- Algunos ejercicios de catálogo
INSERT INTO ejercicios_catalogo (id, nombre, grupo_muscular, descripcion, instrucciones, equipamiento_necesario) VALUES
('eeeeeeee-1111-1111-1111-111111111111', 'Sentadilla libre', 'Piernas', 'Ejercicio compuesto principal', 'Bajar hasta romper paralelo, empujar con talones.', 'Barra y discos'),
('eeeeeeee-2222-2222-2222-222222222222', 'Press de Banca', 'Pecho', 'Empuje horizontal', 'Tocar pecho con pausa breve.', 'Banco, barra y discos'),
('eeeeeeee-3333-3333-3333-333333333333', 'Dominadas', 'Espalda', 'Tirón vertical', 'Subir barbilla por encima de barra.', 'Barra de dominadas');

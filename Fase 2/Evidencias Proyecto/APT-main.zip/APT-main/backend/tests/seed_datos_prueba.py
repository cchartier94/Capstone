import os
import sys
import json
import requests
from datetime import datetime, timedelta
from dotenv import load_dotenv
import random

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
load_dotenv()

URL = os.getenv("SUPABASE_URL")
KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")
HEADERS = {
    "apikey": KEY,
    "Authorization": f"Bearer {KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=minimal"
}

def seed_metrics(user_id, weight_start, weight_end, fat_start, fat_end, days):
    payloads = []
    for i in range(days):
        if i % 7 == 0:  # Register metrics every 7 days
            progress = i / days
            w = round(weight_start + (weight_end - weight_start) * progress, 1)
            f = round(fat_start + (fat_end - fat_start) * progress, 1) if fat_start else None
            date = (datetime.now() - timedelta(days=days-i)).isoformat()
            
            p = {"usuario_id": user_id, "fecha_registro": date, "peso_corporal_kg": w}
            if f:
                p["porcentaje_grasa"] = f
            payloads.append(p)
            
    if payloads:
        requests.post(f"{URL}/rest/v1/metricas_fisicas", headers=HEADERS, json=payloads)
        print(f"[{user_id}] Insertadas {len(payloads)} metricas.")

def seed_workouts(user_id, days, consistency, level):
    payloads = []
    ejercicios = {
        "Principiante": ["Sentadillas sin peso", "Flexiones de rodillas", "Plancha", "Remo con banda"],
        "Intermedio": ["Sentadillas con barra", "Flexiones", "Plancha con peso", "Dominadas asistidas"],
        "Avanzado": ["Peso Muerto 120kg", "Press Banca 100kg", "Sentadilla 140kg", "Muscle ups"]
    }
    
    for i in range(days):
        date = (datetime.now() - timedelta(days=days-i)).isoformat()
        
        # Determine if they worked out that day based on consistency
        if random.random() < consistency:
            ejercicio = random.choice(ejercicios[level])
            
            payloads.append({
                "usuario_id": user_id,
                "dia_entrenamiento_id": None, # Ficticio
                "fecha_ejecucion": date,
                "notas_sensaciones": f"Completado {ejercicio}. Me sentí bien.",
                "puntaje_adherencia": random.randint(70, 100)
            })
            
    # Send in batches of 100 max
    batch_size = 50
    for i in range(0, len(payloads), batch_size):
        requests.post(f"{URL}/rest/v1/registros_entrenamiento", headers=HEADERS, json=payloads[i:i+batch_size])
        
    print(f"[{user_id}] Insertados {len(payloads)} entrenamientos.")

def run_seed():
    # 1. Principiante (Jean Paul) - Inconsistente, baja poco de peso
    id_principiante = 'fea7590b-72af-47f5-9269-bc8a42dc7e6d'
    print("--- Principiante ---")
    seed_metrics(id_principiante, 85.0, 83.5, None, None, 60)
    seed_workouts(id_principiante, 60, 0.4, "Principiante") # 40% consistency
    
    # 2. Intermedio (Katherine) - Peso estable, baja grasa (mejoró musculatura)
    id_intermedio = '7b4d1f16-6160-4c34-a6b3-bb879beee000'
    print("--- Intermedio (Katherine) ---")
    seed_metrics(id_intermedio, 62.0, 62.5, 25.0, 21.0, 90) # Peso igual, baja grasa
    seed_workouts(id_intermedio, 90, 0.8, "Intermedio") # 80% consistency
    
    # 3. Avanzado (Carlos) - Muy consistente, métricas estables
    id_avanzado = '6f836008-1517-445b-b727-975c1ff76a4f'
    print("--- Avanzado ---")
    seed_metrics(id_avanzado, 80.0, 81.0, 12.0, 10.5, 180) # 6 meses
    seed_workouts(id_avanzado, 180, 0.9, "Avanzado") # 90% consistency

if __name__ == "__main__":
    run_seed()

import os
import sys
import uuid

# Add backend directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.servicios.servicio_chat import ServicioChat

def test_chat():
    print("--- Probando Servicio de Chat con AgentExecutor ---")
    
    # Crear instancia del servicio (debería imprimir logs de inicialización)
    chat = ServicioChat()
    
    # Crear un UUID falso para la prueba
    test_usuario_id = str(uuid.uuid4())
    
    # 1. Probar que responde qué puede hacer
    mensaje1 = "¿Cómo me puedes ayudar y qué puedes hacer por mi?"
    print(f"\nUser: {mensaje1}")
    resultado1 = chat.procesar_mensaje(
        usuario_id=test_usuario_id, 
        mensaje=mensaje1,
        contexto={"nombre": "Tester", "objetivo_principal": "Salud general"}
    )
    print(f"\nCoach:\n{resultado1.get('respuesta', 'Sin respuesta')}")
    
    # 2. Probar tool calling: actualizar peso
    mensaje2 = "Ayer me pesé y estoy en 75kg."
    print(f"\nUser: {mensaje2}")
    resultado2 = chat.procesar_mensaje(
        usuario_id=test_usuario_id, 
        mensaje=mensaje2,
        historial=[
            {"rol": "usuario", "contenido": mensaje1},
            {"rol": "coach", "contenido": resultado1.get('respuesta', '')}
        ]
    )
    print(f"\nCoach:\n{resultado2.get('respuesta', 'Sin respuesta')}")

if __name__ == "__main__":
    test_chat()

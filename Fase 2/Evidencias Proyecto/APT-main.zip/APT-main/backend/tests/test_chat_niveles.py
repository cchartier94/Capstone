import os
import sys
from dotenv import load_dotenv

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
load_dotenv()

from app.servicios.servicio_chat import ServicioChat

def probar_chat(usuario_id, nombre, nivel, mensaje):
    chat = ServicioChat()
    print(f"\n[{nivel}] User ({nombre}): {mensaje}")
    resultado = chat.procesar_mensaje(
        usuario_id=usuario_id, 
        mensaje=mensaje,
        historial=[]
    )
    print(f"[{nivel}] Coach:\n{resultado.get('respuesta', 'Sin respuesta')}")
    print("-" * 50)

def correr_pruebas():
    print("=== INICIANDO PRUEBAS DE CHATBOT CON USUARIOS RICOS EN DATOS ===\n")
    
    # 1. Principiante
    id_principiante = 'fea7590b-72af-47f5-9269-bc8a42dc7e6d'
    probar_chat(
        id_principiante, "Jean Paul", "Principiante", 
        "Siento que no he avanzado mucho este último mes y la verdad me ha costado ir a entrenar. ¿Cómo ves mi progreso real? Sé honesto."
    )
    
    # 2. Intermedio
    id_intermedio = '7b4d1f16-6160-4c34-a6b3-bb879beee000'
    probar_chat(
        id_intermedio, "Katherine", "Intermedio", 
        "Quiero cambiar mi plan actual, siento que ya me estanqué con mi peso y quiero entrenar 5 días en lugar de 3. Además me pesé hoy y sigo en 62kg, pero me veo más marcada."
    )
    
    # 3. Avanzado
    id_avanzado = '6f836008-1517-445b-b727-975c1ff76a4f'
    probar_chat(
        id_avanzado, "Carlos", "Avanzado", 
        "¿Qué entrenamiento hice ayer? Explícame a detalle la técnica del ejercicio más pesado que me toca hoy porque quiero romper mi récord."
    )

if __name__ == "__main__":
    correr_pruebas()

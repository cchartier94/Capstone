import requests
import json
import uuid
import time

BASE_URL = "http://localhost:8000"

def test_flujo_completo():
    print("--- Iniciando Test de Flujo Completo FitAI ---")
    
    # 1. Registro
    print("\n[1/4] Registro de usuario...")
    email = f"test_{uuid.uuid4().hex[:6]}@fitai.test"
    registro_res = requests.post(f"{BASE_URL}/auth/registro", json={
        "nombre": "Test User",
        "correo": email,
        "contrasena": "password123"
    })
    assert registro_res.status_code == 200
    datos_registro = registro_res.json()
    assert datos_registro["exito"] is True
    usuario_id = datos_registro["datos_guardados"]["usuario_id"]
    print(f"OK: Usuario creado con ID: {usuario_id}")

    # 2. Onboarding (Simulando 6 pasos de actualización)
    print("\n[2/4] Completando Onboarding...")
    pasos_datos = [
        {"nombre": "Test User", "edad": 25, "sexo_biologico": "Masculino"},
        {"objetivo_principal": "Bajar grasa"},
        {"peso_actual_kg": 85.5, "estatura_cm": 175},
        {"nivel_actividad": "Moderado", "nivel_experiencia": "Intermedio", "dias_disponibles_semana": 4, "tiempo_por_sesion_minutos": 60},
        {"condiciones_salud": "Ninguna"},
        {"tipo_dieta": "Mediterranea", "alimentos_excluidos": "Ninguno"}
    ]
    
    for i, paso in enumerate(pasos_datos, 1):
        actualizar_res = requests.patch(f"{BASE_URL}/perfil/actualizar?usuario_id={usuario_id}", json=paso)
        assert actualizar_res.status_code == 200
        print(f"   Step {i} OK")

    # 3. Generación de Plan (La parte lenta)
    print("\n[3/4] Generando Plan con IA (Claude)...")
    start_time = time.time()
    plan_res = requests.post(f"{BASE_URL}/plan/generar?usuario_id={usuario_id}")
    
    assert plan_res.status_code == 200
    plan_datos = plan_res.json()
    
    if not plan_datos.get("exito"):
        print(f"ERROR en generacion: {plan_datos.get('mensaje')}")
        assert False

    plan_detalles = plan_datos.get("plan", {})
    assert "semana" in plan_detalles
    print(f"OK: Plan generado con éxito en {time.time() - start_time:.2f}s")
    print(f"   Nombre del plan: {plan_detalles.get('nombre_plan', 'Plan FitAI')}")

    # 4. Verificación de Dashboard / Progreso
    print("\n[4/4] Verificando Dashboard y Progreso...")
    progreso_res = requests.get(f"{BASE_URL}/progreso/resumen?periodo=semana&usuario_id={usuario_id}")
    assert progreso_res.status_code == 200
    print("OK: Dashboard responde correctamente")
    
    insights_res = requests.get(f"{BASE_URL}/progreso/insights?usuario_id={usuario_id}")
    assert insights_res.status_code == 200
    print("OK: Insights de IA cargados")

    print("\nTEST COMPLETADO CON EXITO: El flujo esta impecable.")

if __name__ == "__main__":
    try:
        test_flujo_completo()
    except Exception as e:
        print(f"\n❌ ERROR EN EL TEST: {e}")
        import traceback
        traceback.print_exc()

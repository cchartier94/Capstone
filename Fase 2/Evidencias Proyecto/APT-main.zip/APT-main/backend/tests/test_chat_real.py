import os
import sys
import json
import requests

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.servicios.servicio_chat import ServicioChat

def test_chat_real():
    print("--- Obteniendo un usuario real de Supabase via REST API ---")
    url = os.getenv("SUPABASE_URL")
    key = os.getenv("SUPABASE_CLAVE_SERVICIO")
    
    if not url or not key:
        print("ERROR: SUPABASE_URL o SUPABASE_CLAVE_SERVICIO no definidos en .env")
        return
        
    headers = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    
    # Buscar el primer usuario
    res = requests.get(f"{url}/rest/v1/perfiles_usuario?select=usuario_id,nombre&limit=1", headers=headers)
    if res.status_code != 200 or not res.json():
        print("ERROR: No se encontraron usuarios en la base de datos o fallo la peticion.")
        print(res.text)
        return
        
    usuario = res.json()[0]
    real_user_id = usuario['usuario_id']
    nombre = usuario['nombre']
    print(f"Usuario real encontrado: {nombre} ({real_user_id})")
    
    print("\n--- Probando Servicio de Chat con AgentExecutor ---")
    chat = ServicioChat()
    
    mensaje1 = "Ayer me pesé y estoy en 75kg."
    print(f"\nUser ({nombre}): {mensaje1}")
    resultado1 = chat.procesar_mensaje(
        usuario_id=real_user_id, 
        mensaje=mensaje1,
        historial=[]
    )
    print(f"\nCoach:\n{resultado1.get('respuesta', 'Sin respuesta')}")
    
    mensaje2 = "Me podrias resumir mi progreso y mostrar mis metricas?"
    print(f"\nUser ({nombre}): {mensaje2}")
    resultado2 = chat.procesar_mensaje(
        usuario_id=real_user_id, 
        mensaje=mensaje2,
        historial=[
            {"rol": "usuario", "contenido": mensaje1},
            {"rol": "coach", "contenido": resultado1.get('respuesta', '')}
        ]
    )
    print(f"\nCoach:\n{resultado2.get('respuesta', 'Sin respuesta')}")

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    test_chat_real()

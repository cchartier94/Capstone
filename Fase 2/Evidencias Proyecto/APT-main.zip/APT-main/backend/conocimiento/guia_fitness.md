# Guía de Entrenamiento FitAI — Base de Conocimiento Profesional

## 1. Principios Fundamentales del Entrenamiento

### 1.1 Sobrecarga Progresiva
Para que un músculo crezca o se fortalezca, debe ser sometido a un estímulo mayor al que está acostumbrado. Esto se logra aumentando el peso, las repeticiones o disminuyendo los tiempos de descanso gradualmente. La progresión recomendada es del 2-5% semanal en cargas.

### 1.2 Especificidad (Principio SAID)
El cuerpo se adapta específicamente a las demandas impuestas. Si el objetivo es fuerza máxima, se entrena con cargas altas y pocas reps. Si es hipertrofia, con cargas moderadas y más volumen.

### 1.3 Variación y Periodización
Alternar estímulos evita el estancamiento. Se recomienda periodización lineal para principiantes y ondulante para intermedios/avanzados.

### 1.4 Recuperación
El músculo no crece en el gimnasio, sino durante el descanso. Se recomiendan entre 7 y 9 horas de sueño profundo. Mínimo 48 horas entre sesiones del mismo grupo muscular.

---

## 2. Protocolos por Objetivo

### 2.1 Bajar Grasa (Definición)
- **Déficit calórico**: 300-500 kcal por debajo del TDEE
- **Proteína**: 2.0-2.4g por kg de peso corporal (preservar masa muscular)
- **Entrenamiento de fuerza**: Mantener cargas pesadas, 3-4 series de 8-12 reps
- **Cardio**: 2-3 sesiones de HIIT (20 min) o 3-4 de LISS (30-45 min)
- **Descanso entre series**: 45-90 segundos
- **Circuitos metabólicos**: Supersets y giant sets para mayor gasto calórico
- **Frecuencia**: 4-5 días de entrenamiento, 2-3 descanso
- **Priorizar**: Ejercicios compuestos multi-articulares que queman más calorías
- **Evitar**: Volumen excesivo que comprometa la recuperación en déficit

### 2.2 Ganar Masa Muscular (Hipertrofia)
- **Superávit calórico**: 200-400 kcal por encima del TDEE
- **Proteína**: 1.6-2.2g por kg de peso corporal
- **Rango de repeticiones**: Principalmente 6-12 reps (tensión mecánica)
- **Series por grupo muscular/semana**: 10-20 series (MRV)
- **Descanso entre series**: 90-180 segundos para compuestos, 60-90 para aislamiento
- **Tempo**: 2-0-2 (excéntrica controlada de 2 seg)
- **Frecuencia por grupo muscular**: 2 veces por semana mínimo
- **Split recomendado**: Push/Pull/Legs o Upper/Lower según disponibilidad
- **Priorizar**: Sobrecarga progresiva en los ejercicios compuestos principales
- **Ejercicios clave**: Sentadilla, peso muerto, press banca, dominadas, press militar

### 2.3 Mantención (Mantenimiento)
- **Calorías**: Al nivel del TDEE (isocalórico)
- **Proteína**: 1.4-1.8g por kg de peso corporal
- **Volumen**: 60-70% del volumen de una fase de ganancia
- **Frecuencia**: 3-4 días de entrenamiento
- **Objetivo**: Mantener fuerza adquirida sin acumular fatiga
- **Cardio**: 2-3 sesiones de intensidad moderada para salud cardiovascular
- **Descanso entre series**: 60-120 segundos

### 2.4 Recomposición Corporal
- **Calorías**: Ligero déficit (-100 a -200 kcal) o al nivel del TDEE
- **Proteína**: 2.0-2.4g por kg (la más alta de todos los objetivos)
- **Entrenamiento**: Alta intensidad con cargas pesadas (fuerza + hipertrofia)
- **Cardio**: 2 sesiones HIIT, 1-2 LISS
- **Ideal para**: Principiantes, personas con sobrepeso, o tras un periodo largo sin entrenar
- **Frecuencia**: 4-5 días de entrenamiento
- **Split**: Upper/Lower o Full Body 4x/semana

### 2.5 Mejorar Rendimiento
- **Calorías**: Según la fase (acumulación vs intensificación)
- **Proteína**: 1.6-2.0g por kg
- **Entrenamiento**: Periodización ondulante con bloques de fuerza, potencia y resistencia
- **Reps**: Varían por bloque (1-5 fuerza, 3-6 potencia, 12-20 resistencia)
- **Descanso**: 2-5 minutos en series pesadas
- **Frecuencia**: 4-6 días según deporte
- **Incluir**: Trabajo de movilidad, pliometría, y ejercicios funcionales

---

## 3. Distribución de Macronutrientes

### 3.1 Proteínas
- Fuente principal de reparación muscular
- Efecto térmico de los alimentos (TEF): ~25-30% de las calorías de proteína se gastan en digestión
- Distribuir en 4-5 tomas de 0.3-0.5g/kg por comida
- Fuentes: pollo, pescado, huevos, lácteos, legumbres, tofu, proteína whey

### 3.2 Carbohidratos
- Fuente principal de energía para entrenamiento de alta intensidad
- Timing: concentrar alrededor del entrenamiento (pre y post)
- Bajar grasa: 2-3g/kg/día
- Mantenimiento: 3-5g/kg/día
- Ganar masa: 4-6g/kg/día
- Rendimiento: 5-8g/kg/día
- Fuentes: arroz, avena, patata, frutas, pasta integral, quinoa

### 3.3 Grasas
- Esenciales para regulación hormonal (testosterona, estrógenos)
- Nunca bajar de 0.5g/kg/día
- Rango saludable: 0.8-1.2g/kg/día
- Fuentes: aceite de oliva, aguacate, frutos secos, pescado graso, huevos

### 3.4 Hidratación
- Mínimo 35ml por kg de peso corporal al día
- Añadir 500-700ml por hora de ejercicio
- Señales de deshidratación: orina oscura, fatiga, calambres

---

## 4. Ejercicios por Equipamiento

### 4.1 Gimnasio (equipo completo)
**Pecho**: Press banca, press inclinado mancuernas, cruces en polea, peck deck, fondos en paralelas
**Espalda**: Dominadas, remo con barra, jalón al pecho, remo en polea baja, pullover
**Hombros**: Press militar, elevaciones laterales, face pulls, press Arnold, elevaciones frontales
**Piernas**: Sentadilla, prensa, extensión de cuádriceps, curl femoral, peso muerto rumano, zancadas, hip thrust
**Brazos**: Curl bíceps barra, curl martillo, extensión tríceps polea, press francés, fondos
**Core**: Plancha, crunch en polea, pallof press, ab wheel, elevación de piernas colgando

### 4.2 Casa (equipo mínimo o sin equipo)
**Pecho**: Flexiones (variantes: inclinadas, declinadas, diamante, archer), flexiones con banda
**Espalda**: Remo con banda elástica, superman, face pulls con banda, remo invertido en mesa
**Hombros**: Press con banda, elevaciones laterales con banda o botellas, pike push-ups
**Piernas**: Sentadilla búlgara, sentadilla pistola, zancadas, step-ups, sentadilla goblet, puente de glúteos
**Brazos**: Curl con banda, extensión tríceps con banda, flexiones diamante
**Core**: Plancha (frontal y lateral), mountain climbers, dead bugs, bird dogs, hollow body hold

### 4.3 Parque / Calistenia
**Pecho**: Flexiones en suelo y en barra, fondos en barras paralelas
**Espalda**: Dominadas (prono, supino, neutro), australian rows
**Hombros**: Pike push-ups, handstand push-ups (contra pared), L-sits
**Piernas**: Sentadilla una pierna, box jumps, sprints, saltos al cajón
**Core**: Hanging leg raises, dragon flags, l-sit hold, human flag progresiones

---

## 5. Niveles de Experiencia — Guía de Progresión

### 5.1 Principiante (0-12 meses)
- Rutinas Full Body 3x/semana
- Enfoque en técnica correcta con cargas ligeras-moderadas
- Progresión lineal: añadir 2.5-5kg por sesión en compuestos
- 2-3 ejercicios por grupo muscular
- 2-3 series por ejercicio
- Reps: 10-15 para aprender patrones de movimiento
- Descanso: 60-90 segundos

### 5.2 Intermedio (1-3 años)
- Splits Upper/Lower o Push/Pull/Legs
- Progresión semanal o bisemanal
- 3-4 ejercicios por grupo muscular
- 3-4 series por ejercicio
- Variedad de rangos de repeticiones (6-15)
- Incorporar técnicas de intensidad: drop sets, rest-pause
- Descanso: 60-180 segundos según ejercicio

### 5.3 Avanzado (3+ años)
- Periodización ondulante o por bloques
- Progresión mensual o por mesociclo
- 4-5 ejercicios por grupo muscular
- 4-5 series por ejercicio
- RPE y RIR para autorregulación de intensidad
- Técnicas avanzadas: cluster sets, myo-reps, excéntricos lentos
- Deload programado cada 4-6 semanas
- Descanso: variable según la fase del programa

---

## 6. Consideraciones Especiales de Salud

### 6.1 Problemas de Espalda
- Evitar: Peso muerto convencional, good mornings pesados, sentadilla con barra alta
- Preferir: Peso muerto sumo o trap bar, hip thrust, sentadilla goblet, press de piernas
- Incluir: Ejercicios de core estabilizador (plancha, bird dog, dead bug)

### 6.2 Problemas de Rodilla
- Evitar: Sentadilla profunda con carga, extensión de cuádriceps con alto peso
- Preferir: Sentadilla parcial, prensa de piernas, step-ups controlados
- Incluir: Fortalecimiento de VMO, trabajo de isquiotibiales

### 6.3 Problemas de Hombro
- Evitar: Press militar detrás del cuello, upright rows, fondos profundos
- Preferir: Press con mancuernas en ángulo neutro, landmine press
- Incluir: Rotadores externos, face pulls, trabajo de manguito rotador

### 6.4 Diabetes
- Monitorear glucosa antes, durante y después del ejercicio
- Tener carbohidratos de acción rápida disponibles
- Evitar entrenar en ayunas con insulina activa
- Preferir ejercicio moderado y constante sobre HIIT intenso

### 6.5 Hipertensión
- Evitar: Maniobra de Valsalva prolongada, cargas máximas
- Preferir: Series de 12-15 reps con cargas moderadas
- Incluir: Cardio aeróbico regular (30-45 min, 3-5 días)
- Monitorear presión arterial regularmente

---

## 7. Dietas Especiales

### 7.1 Vegana/Vegetariana
- Combinar legumbres + cereales para proteína completa
- Suplementar: B12, hierro, omega-3 (DHA/EPA de algas), zinc
- Fuentes de proteína: tofu, tempeh, seitán, legumbres, quinoa, proteína de guisante
- Puede requerir 10-15% más proteína total por menor biodisponibilidad

### 7.2 Cetogénica / Low-carb
- Adaptación de 2-4 semanas donde el rendimiento puede bajar
- No ideal para deportes de alta intensidad o potencia
- Puede funcionar para: caminata, bicicleta de larga distancia, musculación moderada
- Proteína: 1.6-2.2g/kg, Grasas: 60-75% kcal, Carbohidratos: <50g/día
- Priorizar electrolitos: sodio, potasio, magnesio

### 7.3 Sin gluten
- No afecta significativamente al rendimiento deportivo
- Sustituir: avena por avena certificada sin gluten, pasta por pasta de arroz/maíz
- Fuentes de carbohidratos: arroz, patata, quinoa, maíz, batata

### 7.4 Ayuno intermitente
- Compatible con entrenamiento si se planifica bien
- Ventana de alimentación debe incluir comida pre y post entrenamiento
- Proteína distribuida en las comidas dentro de la ventana
- No recomendado para principiantes en combinación con déficit agresivo

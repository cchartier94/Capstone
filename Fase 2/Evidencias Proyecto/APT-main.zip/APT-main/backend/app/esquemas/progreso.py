"""
@file progreso.py
@description Esquemas Pydantic para los endpoints de progreso del usuario (SCRUM-12).
             Define los modelos de respuesta para resumen, historial e insights.
@author FitAI Team
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional, List


class MetricaResumen(BaseModel):
    """Métrica individual del resumen (ej: frecuencia, volumen, racha)."""
    etiqueta: str
    valor: str
    unidad: Optional[str] = None
    tendencia: str = "estable"  # "mejora", "estable", "retroceso"
    cambio_porcentual: Optional[float] = None


class DatoGrafico(BaseModel):
    """Punto de dato para gráficos de barras/líneas."""
    etiqueta: str
    valor: float


class EjercicioDestacado(BaseModel):
    """Ejercicio con mayor progreso o estancamiento."""
    nombre: str
    grupo_muscular: str
    progreso_porcentual: float
    estado: str  # "mejora", "estable", "estancado"


class LogroRespuesta(BaseModel):
    """Esquema para una medalla o logro del usuario."""
    id: str
    nombre: str
    descripcion: str
    desbloqueado: bool
    tipo: str  # "oro", "plata", "bronce"
    icono: str


class ResumenProgresoRespuesta(BaseModel):
    """Respuesta completa del endpoint GET /progreso/resumen."""
    exito: bool
    periodo: str
    metricas: List[MetricaResumen] = []
    grafico_actividad: List[DatoGrafico] = []
    ejercicios_destacados: List[EjercicioDestacado] = []
    logros: Optional[List[LogroRespuesta]] = []
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class EntrenamientoRegistro(BaseModel):
    """Registro individual de un entrenamiento completado."""
    id: str
    fecha: str
    nombre_rutina: str
    grupo_muscular: str
    duracion_minutos: int
    ejercicios_completados: int
    volumen_total_kg: float
    puntaje_adherencia: Optional[int] = None


class HistorialEntrenamientosRespuesta(BaseModel):
    """Respuesta del endpoint GET /progreso/entrenamientos."""
    exito: bool
    periodo: str
    total: int
    entrenamientos: List[EntrenamientoRegistro] = []
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class InsightProgreso(BaseModel):
    """Insight o recomendación basada en el progreso."""
    tipo: str  # "recomendacion", "alerta", "logro"
    icono: str  # nombre de icono Ionicons
    titulo: str
    descripcion: str
    prioridad: int = 1  # 1 = alta, 2 = media, 3 = baja


class InsightsProgresoRespuesta(BaseModel):
    """Respuesta del endpoint GET /progreso/insights."""
    exito: bool
    insights: List[InsightProgreso] = []
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

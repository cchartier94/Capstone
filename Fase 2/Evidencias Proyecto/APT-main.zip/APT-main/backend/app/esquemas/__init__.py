"""
@file __init__.py
@description Pydantic schemas package
"""

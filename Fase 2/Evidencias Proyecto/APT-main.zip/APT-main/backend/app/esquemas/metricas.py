"""
@file metricas.py
@description Esquemas Pydantic para el módulo de métricas físicas (SCRUM-36).
             Define los modelos de entrada y respuesta para registro y consulta
             de métricas corporales del usuario.
@author FitAI Team
"""

from pydantic import BaseModel, ConfigDict, field_validator
from typing import Optional, List
from datetime import date


class RegistrarMetricaEntrada(BaseModel):
    """
    Schema para POST /metricas/registrar.
    Solo peso_corporal_kg es obligatorio; las medidas corporales son opcionales.
    """
    id_usuario: Optional[str] = None
    fecha_registro: Optional[str] = None  # ISO format YYYY-MM-DD, default = hoy
    peso_corporal_kg: float
    medida_cintura_cm: Optional[float] = None
    medida_pecho_cm: Optional[float] = None
    medida_cadera_cm: Optional[float] = None
    medida_brazos_cm: Optional[float] = None
    medida_piernas_cm: Optional[float] = None
    porcentaje_grasa: Optional[float] = None

    @field_validator("peso_corporal_kg")
    @classmethod
    def validar_peso(cls, v):
        if v <= 0 or v > 500:
            raise ValueError("El peso debe ser un valor positivo razonable (1-500 kg)")
        return round(v, 2)

    @field_validator(
        "medida_cintura_cm", "medida_pecho_cm", "medida_cadera_cm",
        "medida_brazos_cm", "medida_piernas_cm", mode="before",
    )
    @classmethod
    def validar_medida(cls, v):
        if v is not None:
            if v <= 0 or v > 300:
                raise ValueError("La medida debe ser un valor positivo razonable (1-300 cm)")
            return round(v, 2)
        return v


class MetricaRegistro(BaseModel):
    """Registro individual de métricas físicas (para listados)."""
    id: str
    fecha_registro: str
    peso_corporal_kg: Optional[float] = None
    medida_cintura_cm: Optional[float] = None
    medida_pecho_cm: Optional[float] = None
    medida_cadera_cm: Optional[float] = None
    medida_brazos_cm: Optional[float] = None
    medida_piernas_cm: Optional[float] = None
    porcentaje_grasa: Optional[float] = None


class RespuestaMetrica(BaseModel):
    """Respuesta genérica para operaciones de métricas."""
    exito: bool
    mensaje: str
    datos: Optional[dict] = None

    model_config = ConfigDict(from_attributes=True)


class HistorialMetricasRespuesta(BaseModel):
    """Respuesta del endpoint GET /metricas/historial."""
    exito: bool
    total: int
    registros: List[MetricaRegistro] = []
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

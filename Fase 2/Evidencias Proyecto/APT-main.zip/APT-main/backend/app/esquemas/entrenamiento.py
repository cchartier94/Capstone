"""
@file entrenamiento.py
@description Esquemas Pydantic para el módulo de registro de entrenamiento (SCRUM-34).
             Define los modelos de entrada/salida para registrar sesiones de ejercicio.
@author Jean Paul Villagra Urbina
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional, List


class EjercicioRegistroEntrada(BaseModel):
    """Datos de un ejercicio individual dentro de una sesión de entrenamiento."""
    nombre: str
    series: int
    reps: str
    peso_kg: float
    descanso_segundos: int


class RegistrarSesionEntrada(BaseModel):
    """Payload completo para registrar una sesión de entrenamiento."""
    usuario_id: str
    fecha: Optional[str] = None  # YYYY-MM-DD, default hoy
    ejercicios: List[EjercicioRegistroEntrada]


class RespuestaRegistroSesion(BaseModel):
    """Respuesta del endpoint POST /entrenamientos/registrar."""
    exito: bool
    mensaje: Optional[str] = None
    sesion_id: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class RespuestaUltimoPeso(BaseModel):
    """Respuesta con el último peso utilizado para un ejercicio."""
    exito: bool
    peso_kg: Optional[float] = None
    fecha: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

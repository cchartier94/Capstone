"""
@file planes.py
@description Esquemas Pydantic para el módulo de historial de planes (SCRUM-37).
             Define los modelos de respuesta para listado y detalle de planes.
@author FitAI Team
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional, List


class PlanResumen(BaseModel):
    """Resumen de un plan para el listado del historial."""
    id: str
    fecha_creacion: str
    objetivo_seleccionado: str
    duracion_meses: int
    estado: str  # activo, completado, cancelado


class PlanDetalle(BaseModel):
    """Detalle completo de un plan, incluyendo el JSON generado por IA."""
    id: str
    fecha_creacion: str
    objetivo_seleccionado: str
    duracion_meses: int
    estado: str
    respuesta_raw_ia: Optional[dict] = None


class HistorialPlanesRespuesta(BaseModel):
    """Respuesta del endpoint GET /planes/historial."""
    exito: bool
    total: int
    planes: List[PlanResumen] = []
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class DetallePlanRespuesta(BaseModel):
    """Respuesta del endpoint GET /planes/{plan_id}."""
    exito: bool
    plan: Optional[PlanDetalle] = None
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class EjercicioPlanificadoDetalle(BaseModel):
    """Detalle de ejercicio planificado en la rutina."""
    id: str
    ejercicio_catalogo_id: Optional[str] = None
    nombre: str
    grupo_muscular: Optional[str] = None
    series_objetivo: Optional[int] = None
    repeticiones_objetivo: Optional[str] = None
    descanso_objetivo_segundos: Optional[int] = None
    orden_rutina: int
    notas: Optional[str] = None


class DiaEntrenamientoDetalle(BaseModel):
    """Detalle de un día de entrenamiento en la rutina."""
    id: str
    numero_dia: int
    es_dia_descanso: bool
    tipo: Optional[str] = None
    ejercicios: List[EjercicioPlanificadoDetalle] = []


class SemanaEntrenamientoDetalle(BaseModel):
    """Detalle de una semana de entrenamiento en la rutina."""
    id: str
    numero_semana: int
    enfoque_semana: Optional[str] = None
    dias: List[DiaEntrenamientoDetalle] = []


class RespuestaRutinaActiva(BaseModel):
    """Respuesta del endpoint GET /rutina/activa."""
    exito: bool
    plan_id: Optional[str] = None
    semanas: List[SemanaEntrenamientoDetalle] = []
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class ActualizarPlanEntrada(BaseModel):
    """Datos para actualizar un plan (específicamente la rutina generada por la IA)."""
    respuesta_raw_ia: Optional[dict] = None

class EvolucionarPlanEntrada(BaseModel):
    feedback: str
    
    model_config = ConfigDict(from_attributes=True)

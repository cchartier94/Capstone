"""
@file chat.py
@description Esquemas Pydantic para el módulo de chat con coach IA (SCRUM-32).
             Define los modelos de entrada/salida para la conversación con el coach virtual.
@author Jean Paul Villagra Urbina
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional, List


class MensajeHistorial(BaseModel):
    """Mensaje individual del historial de conversación."""
    rol: str  # "usuario" o "coach"
    contenido: str


class ContextoInicial(BaseModel):
    """Contexto del usuario enviado en el primer mensaje de la sesión."""
    nombre: Optional[str] = None
    objetivo: Optional[str] = None
    plan_nombre: Optional[str] = None
    plan_resumen: Optional[str] = None


class EnviarMensajeEntrada(BaseModel):
    """Payload para enviar un mensaje al coach IA."""
    usuario_id: str
    mensaje: str
    historial: List[MensajeHistorial] = []
    contexto: Optional[ContextoInicial] = None


class RespuestaMensaje(BaseModel):
    """Respuesta del endpoint POST /coach/mensaje."""
    exito: bool
    respuesta: Optional[str] = None
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

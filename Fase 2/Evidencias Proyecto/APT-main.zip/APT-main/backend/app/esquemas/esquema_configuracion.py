"""
@file esquema_configuracion.py
@description Esquemas Pydantic para los endpoints de configuración (SCRUM-39/40)
             y gestión de cuenta (SCRUM-41).
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional


class ConfiguracionEntrada(BaseModel):
    """Schema para PATCH /configuracion/{usuario_id} — todos los campos opcionales."""

    unidad_peso: Optional[str] = None
    notificaciones_activas: Optional[bool] = None
    recordatorios_entrenamiento: Optional[bool] = None
    recordatorios_alimentacion: Optional[bool] = None
    recordatorios_seguimiento: Optional[bool] = None


class RespuestaConfiguracion(BaseModel):
    """Respuesta estándar para endpoints de configuración."""

    exito: bool
    mensaje: str
    configuracion: Optional[dict] = None

    model_config = ConfigDict(from_attributes=True)


class RespuestaCuenta(BaseModel):
    """Respuesta para endpoints de gestión de cuenta."""

    exito: bool
    mensaje: str

"""
@file ejercicios.py
@description Esquemas Pydantic para el módulo de detalle y alternativas de ejercicios (SCRUM-29).
             Define los modelos de respuesta para sugerencias de ejercicios alternativos.
@author Jean Paul Villagra Urbina
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional, List


class EjercicioAlternativa(BaseModel):
    """Ejercicio alternativo sugerido."""
    nombre: str
    grupo_muscular: str
    descripcion: str
    instrucciones: Optional[str] = None


class RespuestaAlternativas(BaseModel):
    """Respuesta del endpoint GET /ejercicios/alternativas."""
    exito: bool
    alternativas: List[EjercicioAlternativa] = []
    mensaje: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

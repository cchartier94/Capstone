"""
@file perfil.py
@description Pydantic v2 schemas for profile updates
@author Carlos Chartier
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional


class ActualizarPerfilEntrada(BaseModel):
    """Schema for PATCH /perfil/actualizar request - all fields optional for partial updates."""

    id_usuario: Optional[str] = None  # Added to match HDU requirements (body vs query)
    nombre: Optional[str] = None
    edad: Optional[int] = None
    sexo_biologico: Optional[str] = None
    peso: Optional[float] = None  # Maps to peso_actual_kg
    estatura: Optional[float] = None  # Maps to estatura_cm
    objetivo: Optional[str] = None  # Maps to objetivo_principal
    nivel_actividad: Optional[str] = None
    nivel_experiencia: Optional[str] = None
    dias_por_semana: Optional[int] = None  # Maps to dias_disponibles_semana
    tiempo_por_sesion_minutos: Optional[int] = None
    lugar_entrenamiento: Optional[str] = None
    tipo_entrenamiento: Optional[str] = None
    condiciones_salud: Optional[str] = None
    tipo_dieta: Optional[str] = None
    alimentos_excluidos: Optional[str] = None


class RespuestaPerfil(BaseModel):
    """Response schema for profile update endpoints."""

    exito: bool
    mensaje: str
    datos_guardados: Optional[dict] = None

    model_config = ConfigDict(from_attributes=True)


class RespuestaPlan(BaseModel):
    """Response schema for plan generation."""
    exito: bool
    plan: Optional[dict] = None
    mensaje: Optional[str] = None


class AuthRegistroEntrada(BaseModel):
    """Schema for user registration."""
    nombre: str
    correo: str
    contrasena: str


class AuthVerificarCodigoEntrada(BaseModel):
    """Schema for email code verification."""
    correo: str
    codigo: str

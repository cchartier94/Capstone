"""
@file bd.py
@description Cliente de conexión a Base de Datos PostgreSQL (Supabase)
@author Carlos Chartier
"""

import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import OperationalError
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Obtener URL de conexión desde .env
DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    raise ValueError("❌ DATABASE_URL no está configurada en .env")

# Crear motor de base de datos
motor = create_engine(
    DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
    pool_recycle=3600,
)

# Factory de sesiones
SesionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=motor,
)


def obtener_bd():
    """
    Dependencia para inyectar sesión de BD en los endpoints.
    """
    bd = SesionLocal()
    try:
        yield bd
    finally:
        bd.close()


def verificar_conexion():
    """
    Verifica que la conexión a PostgreSQL funciona.
    En Docker con Supabase, esto puede fallar por IPv6.

    :return: True si la conexión es exitosa, False si hay error
    """
    try:
        with motor.connect() as conexion:
            conexion.execute(text("SELECT 1"))
            print("OK: Conexión a Supabase verificada correctamente")
            return True
    except OperationalError as e:
        print(f"ADVERTENCIA: No se pudo conectar a BD (esperado en Docker sin acceso IPv6)")
        print(f"   Para usar Supabase en Docker, necesitas:")
        print(f"   - VPN que soporte IPv4")
        print(f"   - Proxy HTTP/HTTPS")
        print(f"   - O usar Supabase REST API en lugar de conexión directa")
        return False
    except Exception as e:
        print(f"ERROR inesperado: {e}")
        return False

"""
Módulo nucleo - Componentes centrales del backend
Contiene: conexión a BD, autenticación, utilidades
"""

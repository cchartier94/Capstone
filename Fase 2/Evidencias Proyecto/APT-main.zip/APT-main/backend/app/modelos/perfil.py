"""
@file perfil.py
@description SQLAlchemy ORM model for PerfilUsuario
@author Carlos Chartier
"""

from sqlalchemy import Column, String, Integer, Numeric, TEXT, ForeignKey, UUID as UUID_Type
from sqlalchemy.orm import relationship
import uuid
from app.modelos import Base


class PerfilUsuario(Base):
    """Modelo ORM para la tabla perfiles_usuario en PostgreSQL."""

    __tablename__ = "perfiles_usuario"

    usuario_id = Column(
        UUID_Type(as_uuid=True),
        ForeignKey("usuarios.id", ondelete="CASCADE"),
        primary_key=True,
        default=uuid.uuid4,
    )

    nombre = Column(String(100), nullable=False)
    edad = Column(Integer, nullable=False)
    sexo_biologico = Column(String(50), nullable=False)
    peso_actual_kg = Column(Numeric(5, 2), nullable=False)
    estatura_cm = Column(Numeric(5, 2), nullable=False)
    objetivo_principal = Column(String(100), nullable=False)
    nivel_actividad = Column(String(100), nullable=False)
    nivel_experiencia = Column(String(100), nullable=False)
    lugar_entrenamiento = Column(String(100), nullable=False)
    tipo_entrenamiento = Column(String(100), nullable=False)
    dias_disponibles_semana = Column(Integer, nullable=False)
    tiempo_por_sesion_minutos = Column(Integer, nullable=False)
    condiciones_salud = Column(TEXT, nullable=True)
    tipo_dieta = Column(String(100), nullable=True)
    preferencias_alimenticias = Column(TEXT, nullable=True)
    alimentos_excluidos = Column(TEXT, nullable=True)

    def __repr__(self):
        return f"<PerfilUsuario(usuario_id={self.usuario_id}, nombre={self.nombre})>"

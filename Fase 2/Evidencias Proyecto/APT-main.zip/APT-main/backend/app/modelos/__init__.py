"""
@file __init__.py
@description SQLAlchemy 2.0 declarative base for all models
"""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Declarative base for SQLAlchemy 2.0 ORM models."""
    pass

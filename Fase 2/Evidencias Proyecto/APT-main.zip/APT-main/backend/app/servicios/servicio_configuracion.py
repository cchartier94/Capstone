"""
@file servicio_configuracion.py
@description Servicio de configuración de usuario (SCRUM-39/40).
             Lee y escribe en la tabla configuracion_usuario de Supabase.
"""

import os
import requests

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

DEFAULTS = {
    "unidad_peso": "kg",
    "notificaciones_activas": True,
    "recordatorios_entrenamiento": True,
    "recordatorios_alimentacion": True,
    "recordatorios_seguimiento": True,
}


def _headers(prefer=None):
    h = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
    }
    if prefer:
        h["Prefer"] = prefer
    return h


class ServicioConfiguracion:
    """Operaciones CRUD sobre configuracion_usuario en Supabase."""

    def obtener(self, usuario_id: str) -> dict:
        """
        Retorna la configuración del usuario.
        Si no existe la fila, crea una con defaults y la retorna.
        """
        try:
            url = f"{SUPABASE_URL}/rest/v1/configuracion_usuario?usuario_id=eq.{usuario_id}&limit=1"
            res = requests.get(url, headers=_headers())

            if res.ok and res.json():
                config = res.json()[0]
                return {
                    "exito": True,
                    "mensaje": "Configuración encontrada",
                    "configuracion": config,
                }

            # No existe → crear con defaults
            nueva = {"usuario_id": usuario_id, **DEFAULTS}
            insert_url = f"{SUPABASE_URL}/rest/v1/configuracion_usuario"
            insert_res = requests.post(
                insert_url, json=nueva, headers=_headers("return=representation")
            )

            if insert_res.ok and insert_res.json():
                return {
                    "exito": True,
                    "mensaje": "Configuración creada con valores por defecto",
                    "configuracion": insert_res.json()[0],
                }

            # Si falla el insert (ej: usuario no existe), retornar defaults
            return {
                "exito": True,
                "mensaje": "Usando valores por defecto",
                "configuracion": {**DEFAULTS, "usuario_id": usuario_id},
            }

        except Exception as e:
            print(f"ERROR servicio_configuracion.obtener: {e}")
            return {
                "exito": False,
                "mensaje": str(e),
                "configuracion": {**DEFAULTS, "usuario_id": usuario_id},
            }

    def actualizar(self, usuario_id: str, datos: dict) -> dict:
        """
        Actualiza la configuración del usuario.
        Si la fila no existe, la crea primero (upsert).
        """
        try:
            # Intentar PATCH
            url = f"{SUPABASE_URL}/rest/v1/configuracion_usuario?usuario_id=eq.{usuario_id}"
            res = requests.patch(
                url, json=datos, headers=_headers("return=representation")
            )

            if res.ok:
                filas = res.json()
                if filas:
                    return {
                        "exito": True,
                        "mensaje": "Configuración actualizada",
                        "configuracion": filas[0],
                    }
                # PATCH retornó vacío → la fila no existía, crearla
                nueva = {"usuario_id": usuario_id, **DEFAULTS, **datos}
                insert_url = f"{SUPABASE_URL}/rest/v1/configuracion_usuario"
                insert_res = requests.post(
                    insert_url,
                    json=nueva,
                    headers=_headers("return=representation"),
                )
                if insert_res.ok and insert_res.json():
                    return {
                        "exito": True,
                        "mensaje": "Configuración creada y actualizada",
                        "configuracion": insert_res.json()[0],
                    }

            return {"exito": False, "mensaje": f"Error Supabase: {res.text}"}

        except Exception as e:
            print(f"ERROR servicio_configuracion.actualizar: {e}")
            return {"exito": False, "mensaje": str(e)}


servicio_configuracion = ServicioConfiguracion()

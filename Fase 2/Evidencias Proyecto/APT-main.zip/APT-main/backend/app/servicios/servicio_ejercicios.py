"""
@file servicio_ejercicios.py
@description Servicio para detalle y alternativas de ejercicios (SCRUM-29).
             Busca en el catálogo de Supabase y usa LangChain como fallback
             para generar alternativas inteligentes.
@author Jean Paul Villagra Urbina
"""

import os
from typing import Dict, Any, List, Optional

import requests
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

HEADERS_SUPABASE = {
    "apikey": SUPABASE_KEY or "",
    "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
    "Content-Type": "application/json",
}


class ServicioEjercicios:
    """
    Servicio para consultar ejercicios y obtener alternativas.

    Estrategia:
    1. Buscar en tabla `ejercicios_catalogo` de Supabase.
    2. Si no hay resultados, usar LangChain para generar alternativas.
    """

    def __init__(self):
        """Inicializa el servicio con LangChain como fallback (Claude/Gemini)."""
        self.modelo = None
        self.cadena_alternativas = None
        self.proveedor = None

        anthropic_key = os.getenv("ANTHROPIC_API_KEY")
        if anthropic_key:
            try:
                from langchain_anthropic import ChatAnthropic
                from langchain_core.prompts import ChatPromptTemplate
                from langchain_core.output_parsers import JsonOutputParser

                self.modelo = ChatAnthropic(
                    model="claude-3-5-sonnet-20241022",
                    api_key=anthropic_key,
                    temperature=0.7,
                    max_tokens=1500,
                )

                prompt_alternativas = ChatPromptTemplate.from_messages([
                    ("system", (
                        "Eres un experto en fitness y ejercicio. "
                        "Sugiere ejercicios alternativos que trabajen el mismo "
                        "grupo muscular. Considera el equipamiento y limitaciones del usuario. "
                        "Responde ÚNICAMENTE con un JSON válido, sin texto adicional."
                    )),
                    ("human", (
                        "Ejercicio original: {ejercicio}\n"
                        "Grupo muscular: {grupo_muscular}\n"
                        "Lugar de entrenamiento: {lugar_entrenamiento}\n"
                        "Condiciones de salud: {condiciones_salud}\n\n"
                        "Sugiere 3-4 alternativas en este formato JSON:\n"
                        '{{\n'
                        '  "alternativas": [\n'
                        '    {{\n'
                        '      "nombre": "Nombre del ejercicio",\n'
                        '      "grupo_muscular": "Grupo muscular principal",\n'
                        '      "descripcion": "Breve descripción del ejercicio",\n'
                        '      "instrucciones": "Pasos para ejecutar correctamente"\n'
                        '    }}\n'
                        '  ]\n'
                        '}}'
                    )),
                ])

                self.cadena_alternativas = prompt_alternativas | self.modelo | JsonOutputParser()
                self.proveedor = "Claude"
                print("OK: ServicioEjercicios con LangChain + Claude inicializado")
            except Exception as e:
                print(f"ADVERTENCIA: ServicioEjercicios sin Claude: {e}")
        else:
            print("ADVERTENCIA: ServicioEjercicios sin ANTHROPIC_API_KEY")

        # --- Fallback a Gemini (gratuito) ---
        if not self.modelo:
            google_key = os.getenv("GOOGLE_API_KEY")
            if google_key:
                try:
                    from langchain_google_genai import ChatGoogleGenerativeAI
                    from langchain_core.prompts import ChatPromptTemplate
                    from langchain_core.output_parsers import JsonOutputParser

                    self.modelo = ChatGoogleGenerativeAI(
                        model="gemini-2.5-flash",
                        google_api_key=google_key,
                        temperature=0.7,
                        max_output_tokens=1500,
                    )
                    prompt_alternativas = ChatPromptTemplate.from_messages([
                        ("system", (
                            "Eres un experto en fitness y ejercicio. "
                            "Sugiere ejercicios alternativos que trabajen el mismo "
                            "grupo muscular. Considera el equipamiento y limitaciones del usuario. "
                            "Responde ÚNICAMENTE con un JSON válido, sin texto adicional."
                        )),
                        ("human", (
                            "Ejercicio original: {ejercicio}\n"
                            "Grupo muscular: {grupo_muscular}\n"
                            "Lugar de entrenamiento: {lugar_entrenamiento}\n"
                            "Condiciones de salud: {condiciones_salud}\n\n"
                            "Sugiere 3-4 alternativas en este formato JSON:\n"
                            '{{\n'
                            '  "alternativas": [\n'
                            '    {{\n'
                            '      "nombre": "Nombre del ejercicio",\n'
                            '      "grupo_muscular": "Grupo muscular principal",\n'
                            '      "descripcion": "Breve descripción del ejercicio",\n'
                            '      "instrucciones": "Pasos para ejecutar correctamente"\n'
                            '    }}\n'
                            '  ]\n'
                            '}}'
                        )),
                    ])
                    self.cadena_alternativas = prompt_alternativas | self.modelo | JsonOutputParser()
                    self.proveedor = "Gemini"
                    print("OK: ServicioEjercicios con LangChain + Gemini inicializado")
                except Exception as e:
                    print(f"ADVERTENCIA: ServicioEjercicios sin Gemini: {e}")

    def obtener_alternativas(
        self,
        grupo_muscular: str,
        ejercicio_actual: str,
        usuario_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Obtiene ejercicios alternativos para un grupo muscular dado.

        1. Busca en catálogo de Supabase.
        2. Si no hay resultados, genera con LangChain.

        :param grupo_muscular: Grupo muscular a buscar (ej: "Pecho").
        :param ejercicio_actual: Nombre del ejercicio original (para excluirlo).
        :param usuario_id: UUID del usuario (para personalizar con su perfil).
        :returns: dict con exito y lista de alternativas.
        """
        try:
            # 1. Buscar en catálogo de Supabase
            alternativas_catalogo = self._buscar_en_catalogo(
                grupo_muscular, ejercicio_actual
            )
            if alternativas_catalogo:
                return {
                    "exito": True,
                    "alternativas": alternativas_catalogo,
                    "mensaje": f"{len(alternativas_catalogo)} alternativas del catálogo",
                }

            # 2. Fallback: generar con LangChain
            if self.cadena_alternativas:
                return self._generar_con_ia(
                    grupo_muscular, ejercicio_actual, usuario_id
                )

            # 3. Sin catálogo ni IA disponible
            return {
                "exito": True,
                "alternativas": [],
                "mensaje": "No hay alternativas disponibles en este momento.",
            }

        except Exception as e:
            print(f"ERROR en servicio_ejercicios.obtener_alternativas: {e}")
            return {
                "exito": False,
                "alternativas": [],
                "mensaje": f"Error: {str(e)}",
            }

    def _buscar_en_catalogo(
        self, grupo_muscular: str, ejercicio_actual: str
    ) -> List[Dict[str, Any]]:
        """
        Busca ejercicios alternativos en la tabla ejercicios_catalogo de Supabase.

        :param grupo_muscular: Grupo muscular para filtrar.
        :param ejercicio_actual: Ejercicio a excluir de los resultados.
        :returns: Lista de ejercicios del catálogo.
        """
        try:
            url = (
                f"{SUPABASE_URL}/rest/v1/ejercicios_catalogo"
                f"?grupo_muscular=ilike.*{grupo_muscular}*"
                f"&nombre=not.ilike.*{ejercicio_actual}*"
                f"&limit=4"
            )
            response = requests.get(url, headers=HEADERS_SUPABASE)

            if response.ok:
                resultados = response.json()
                return [
                    {
                        "nombre": ej.get("nombre", ""),
                        "grupo_muscular": ej.get("grupo_muscular", grupo_muscular),
                        "descripcion": ej.get("descripcion", ""),
                        "instrucciones": ej.get("instrucciones", ""),
                    }
                    for ej in resultados
                ]
        except Exception as e:
            print(f"[ServicioEjercicios] Error buscando catálogo: {e}")
        return []

    def _generar_con_ia(
        self,
        grupo_muscular: str,
        ejercicio_actual: str,
        usuario_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Genera alternativas usando LangChain cuando el catálogo está vacío.

        :param grupo_muscular: Grupo muscular objetivo.
        :param ejercicio_actual: Nombre del ejercicio original.
        :param usuario_id: UUID del usuario para obtener su perfil.
        :returns: dict con alternativas generadas por IA.
        """
        try:
            # Obtener perfil del usuario para personalizar
            perfil = {}
            if usuario_id:
                try:
                    url = f"{SUPABASE_URL}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario_id}&limit=1"
                    headers = {
                        "apikey": SUPABASE_KEY or "",
                        "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
                    }
                    res = requests.get(url, headers=headers)
                    if res.ok and res.json():
                        perfil = res.json()[0]
                except Exception:
                    pass

            variables = {
                "ejercicio": ejercicio_actual,
                "grupo_muscular": grupo_muscular,
                "lugar_entrenamiento": perfil.get("lugar_entrenamiento", "Gimnasio"),
                "condiciones_salud": perfil.get("condiciones_salud", "Ninguna"),
            }

            print(f"[ServicioEjercicios] Generando alternativas con IA para '{ejercicio_actual}'")
            resultado = self.cadena_alternativas.invoke(variables)

            alternativas = resultado.get("alternativas", [])
            print(f"[ServicioEjercicios] IA generó {len(alternativas)} alternativas")

            return {
                "exito": True,
                "alternativas": alternativas,
                "mensaje": f"{len(alternativas)} alternativas sugeridas por IA",
            }

        except Exception as e:
            error_msg = str(e)
            print(f"[ServicioEjercicios] Error generando con IA: {error_msg}")
            
            # Fallback en caliente a Gemini si Claude falla por cualquier motivo
            if getattr(self, "proveedor", "Claude") == "Claude":
                google_key = os.getenv("GOOGLE_API_KEY")
                if google_key:
                    try:
                        print("[ServicioEjercicios] Error detectado en Claude (404/cuota/etc). Intentando fallback dinámico a Gemini...")
                        from langchain_google_genai import ChatGoogleGenerativeAI
                        from langchain_core.prompts import ChatPromptTemplate
                        from langchain_core.output_parsers import JsonOutputParser

                        modelo_gemini = ChatGoogleGenerativeAI(
                            model="gemini-2.5-flash",
                            google_api_key=google_key,
                            temperature=0.7,
                            max_output_tokens=1500,
                        )
                        prompt_alternativas = ChatPromptTemplate.from_messages([
                            ("system", (
                                "Eres un experto en fitness y ejercicio. "
                                "Sugiere ejercicios alternativos que trabajen el mismo "
                                "grupo muscular. Considera el equipamiento y limitaciones del usuario. "
                                "Responde ÚNICAMENTE con un JSON válido, sin texto adicional."
                            )),
                            ("human", (
                                "Ejercicio original: {ejercicio}\n"
                                "Grupo muscular: {grupo_muscular}\n"
                                "Lugar de entrenamiento: {lugar_entrenamiento}\n"
                                "Condiciones de salud: {condiciones_salud}\n\n"
                                "Sugiere 3-4 alternativas en este formato JSON:\n"
                                '{{\n'
                                '  "alternativas": [\n'
                                '    {{\n'
                                '      "nombre": "Nombre del ejercicio",\n'
                                '      "grupo_muscular": "Grupo muscular principal",\n'
                                '      "descripcion": "Breve descripción del ejercicio",\n'
                                '      "instrucciones": "Pasos para ejecutar correctamente"\n'
                                '    }}\n'
                                '  ]\n'
                                '}}'
                            )),
                        ])
                        cadena_gemini = prompt_alternativas | modelo_gemini | JsonOutputParser()
                        resultado = cadena_gemini.invoke(variables)
                        alternativas = resultado.get("alternativas", [])
                        return {
                            "exito": True,
                            "alternativas": alternativas,
                            "mensaje": f"{len(alternativas)} alternativas sugeridas por Gemini (fallback)",
                        }
                    except Exception as gemini_err:
                        print(f"[ServicioEjercicios] Error en fallback a Gemini: {gemini_err}")

            return {
                "exito": True,
                "alternativas": [],
                "mensaje": "No se pudieron generar alternativas en este momento.",
            }


servicio_ejercicios = ServicioEjercicios()

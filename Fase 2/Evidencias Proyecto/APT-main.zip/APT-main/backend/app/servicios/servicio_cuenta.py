"""
@file servicio_cuenta.py
@description Servicio de gestión de cuenta (SCRUM-41).
             Maneja la eliminación de cuenta con borrado en cascada.
"""

import os
import requests

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")


def _headers():
    return {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
    }


class ServicioCuenta:
    """Operaciones de gestión de cuenta de usuario."""

    def eliminar_cuenta(self, usuario_id: str) -> dict:
        """
        Elimina la cuenta de un usuario.
        Gracias al ON DELETE CASCADE del esquema SQL, al eliminar
        el registro de la tabla `usuarios`, se eliminan automáticamente:
        - perfiles_usuario
        - configuracion_usuario
        - planes (y su cascada de semanas/días/ejercicios)
        - registros_entrenamiento
        - metricas_fisicas
        - sesiones_chat / mensajes_chat
        """
        try:
            # Eliminar el usuario (CASCADE borra todo lo demás)
            url = f"{SUPABASE_URL}/rest/v1/usuarios?id=eq.{usuario_id}"
            res = requests.delete(url, headers=_headers())

            if res.status_code in (200, 204):
                return {
                    "exito": True,
                    "mensaje": "Cuenta eliminada correctamente. Todos los datos han sido borrados.",
                }
            else:
                return {
                    "exito": False,
                    "mensaje": f"Error al eliminar cuenta: {res.text}",
                }

        except Exception as e:
            print(f"ERROR servicio_cuenta.eliminar_cuenta: {e}")
            return {"exito": False, "mensaje": str(e)}


servicio_cuenta = ServicioCuenta()

# -*- coding: utf-8 -*-
"""
@file servicio_chat.py
@description Servicio de chat con coach IA basado en LangChain (SCRUM-32).
             Implementa conversación contextual usando ChatAnthropic,
             MessagesPlaceholder para historial, y RAG para conocimiento técnico.

Usa LangChain como framework de orquestación de IA.
@author Jean Paul Villagra Urbina
"""

import os
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)


import sys
import io
from typing import Dict, Any, List, Optional

# Fix Windows console encoding
if sys.platform == 'win32' and getattr(sys.stdout, 'encoding', '') != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

import requests
from dotenv import load_dotenv

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

HEADERS_SUPABASE = {
    "apikey": SUPABASE_KEY or "",
    "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
    "Content-Type": "application/json",
    "Prefer": "return=representation",
}


PROMPT_COACH_SISTEMA = """Eres FitAI Coach, un entrenador personal virtual e inteligencia artificial \
experta en fitness y entrenamiento físico. Tienes la capacidad de realizar acciones dentro de la aplicación mediante el uso de herramientas (tools).

Si el usuario pregunta "¿Cómo me puedes ayudar?" o "¿Qué puedes hacer?", respóndele listando tus capacidades.
Puedes:
1. Crear un plan de entrenamiento nuevo desde cero.
2. Editar su plan activo actual (cambiar ejercicios, días).
3. Activar o desactivar notificaciones de la app.
4. Actualizar su peso corporal si te lo informan.
5. Analizar su progreso basándote en su historial.
6. Consultar qué entrenó ayer o si olvidó registrarlo.

REGLAS:
1. SIEMPRE responde en español.
2. Sé amigable, motivador y profesional.
3. Basa tus respuestas en el contexto del usuario y conocimiento técnico proporcionado.
4. No respondas ni asesores sobre temas de alimentación o nutrición. Si el usuario pregunta sobre esto, indícale amablemente que tu especialidad es el entrenamiento físico.
5. Usa tus herramientas SOLO si el usuario te pide explícitamente realizar una acción o si es necesario para responder su pregunta.
6. Considera las condiciones de salud y limitaciones del usuario.
7. Mantén las respuestas concisas pero completas (máximo 3-4 párrafos).

CONTEXTO DEL USUARIO:
{contexto_usuario}

CONOCIMIENTO TÉCNICO RELEVANTE:
{contexto_rag}"""


class ServicioChat:
    """
    Servicio de chat conversacional con coach IA basado en LangChain.

    Utiliza ChatAnthropic como LLM, MessagesPlaceholder para historial
    de conversación, y RAG (FAISS) para enriquecer las respuestas con
    conocimiento técnico de fitness.
    """

    def __init__(self):
        """Inicializa el servicio con LangChain + ChatAnthropic (Gemini fallback)."""
        self.modelo = None
        self.cadena = None
        self.proveedor = None

        anthropic_key = os.getenv("ANTHROPIC_API_KEY")
        if anthropic_key:
            try:
                from langchain_anthropic import ChatAnthropic
                self.modelo = ChatAnthropic(
                    model="claude-3-5-sonnet-20241022",
                    api_key=anthropic_key,
                    temperature=0.7,
                    max_tokens=1500,
                )
                self.proveedor = "Claude"
                logger.info(f"OK: ServicioChat LangChain + Claude inicializado")
            except Exception as e:
                logger.info(f"ERROR: No se pudo inicializar ChatAnthropic para chat: {e}")
        else:
            logger.info(f"ADVERTENCIA: ANTHROPIC_API_KEY no encontrada para ServicioChat")

        # --- Fallback a Gemini (gratuito) ---
        if not self.modelo:
            google_key = os.getenv("GOOGLE_API_KEY")
            if google_key:
                try:
                    from langchain_google_genai import ChatGoogleGenerativeAI
                    self.modelo = ChatGoogleGenerativeAI(
                        model="gemini-2.5-flash",
                        google_api_key=google_key,
                        temperature=0.7,
                        max_output_tokens=1500,
                    )
                    self.proveedor = "Gemini"
                    logger.info(f"OK: ServicioChat LangChain + Gemini inicializado")
                except Exception as e:
                    logger.info(f"ADVERTENCIA: No se pudo inicializar Gemini para chat: {e}")

        # Configurar cadena LangChain
        if self.modelo:
            from app.servicios.herramientas_agente import (
                crear_nuevo_plan, editar_plan_activo,
                gestionar_notificaciones, actualizar_medidas_corporales,
                analizar_progreso, obtener_entrenamiento_ayer
            )
            from langgraph.prebuilt import create_react_agent
            
            self.tools = [
                crear_nuevo_plan, editar_plan_activo,
                gestionar_notificaciones, actualizar_medidas_corporales,
                analizar_progreso, obtener_entrenamiento_ayer
            ]
            
            self.prompt_template = PROMPT_COACH_SISTEMA
            self.cadena = create_react_agent(self.modelo, tools=self.tools)
        else:
            logger.info(f"ADVERTENCIA: ServicioChat sin LLM configurado — respuestas fallback")

    def procesar_mensaje(
        self,
        usuario_id: str,
        mensaje: str,
        historial: List[Dict[str, str]] = None,
        contexto: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Procesa un mensaje del usuario y genera una respuesta del coach IA.

        1. Convierte historial del frontend a objetos LangChain.
        2. Obtiene contexto RAG relevante al mensaje.
        3. Construye contexto del usuario (perfil + plan).
        4. Ejecuta la cadena LangChain.
        5. Persiste los mensajes en Supabase.

        :param usuario_id: UUID del usuario.
        :param mensaje: Texto del mensaje del usuario.
        :param historial: Lista de mensajes previos [{rol, contenido}].
        :param contexto: Datos del usuario (nombre, objetivo, plan) del primer mensaje.
        :returns: dict con exito y respuesta del coach.
        """
        if historial is None:
            historial = []

        try:
            # Si no hay LLM configurado, usar respuesta fallback
            if not self.cadena:
                return self._respuesta_fallback(mensaje)

            # 1. Convertir historial del frontend a LangChain Messages
            mensajes_lc = self._convertir_historial(historial)

            # 2. Obtener contexto RAG
            contexto_rag = self._obtener_contexto_rag(mensaje)

            # 3. Construir contexto del usuario
            contexto_usuario = self._construir_contexto_usuario(usuario_id, contexto)

            # 4. Ejecutar cadena LangChain
            logger.info(f"[ServicioChat] Procesando mensaje de {usuario_id}: '{mensaje[:50]}...'")
            logger.info(f"[ServicioChat] Historial: {len(mensajes_lc)} mensajes previos")
            logger.info(f"[ServicioChat] RAG contexto: {len(contexto_rag)} caracteres")

            from langchain_core.messages import SystemMessage, HumanMessage
            
            system_prompt_formatted = self.prompt_template.replace(
                "{contexto_usuario}", contexto_usuario
            ).replace(
                "{contexto_rag}", contexto_rag
            ).replace(
                "{usuario_id}", usuario_id
            )
            
            # Inyectamos el ID explícitamente para que el LLM lo sepa
            system_prompt_formatted += f"\n\nIMPORTANTE: El usuario_id de este cliente es '{usuario_id}'. Úsalo obligatoriamente al llamar a las herramientas (tools)."
            
            messages = [SystemMessage(content=system_prompt_formatted)]
            messages.extend(mensajes_lc)
            messages.append(HumanMessage(content=mensaje))

            resultado = self.cadena.invoke({"messages": messages})
            respuesta = resultado["messages"][-1].content

            logger.info(f"[ServicioChat] Respuesta generada: {len(respuesta)} caracteres")

            # 5. Persistir mensajes en Supabase
            self._persistir_mensajes(usuario_id, mensaje, respuesta)

            return {
                "exito": True,
                "respuesta": respuesta,
            }

        except Exception as e:
            error_msg = str(e)
            logger.info(f"ERROR en ServicioChat.procesar_mensaje: {error_msg}")
            
            # Si falló Claude (el proveedor actual), intentar cambiar a Gemini en caliente si hay clave
            if getattr(self, "proveedor", "Claude") == "Claude":
                google_key = os.getenv("GOOGLE_API_KEY")
                if google_key:
                    try:
                        logger.info(f">>> Error detectado en Claude (404/cuota/etc). Intentando fallback dinámico a Gemini...")
                        from langchain_google_genai import ChatGoogleGenerativeAI
                        modelo_gemini = ChatGoogleGenerativeAI(
                            model="gemini-2.5-flash",
                            google_api_key=google_key,
                            temperature=0.7,
                            max_output_tokens=1500,
                        )
                        from langgraph.prebuilt import create_react_agent
                        cadena_gemini = create_react_agent(modelo_gemini, tools=self.tools)
                        
                        system_prompt_formatted = self.prompt_template.replace(
                            "{contexto_usuario}", contexto_usuario
                        ).replace(
                            "{contexto_rag}", contexto_rag
                        ).replace(
                            "{usuario_id}", usuario_id
                        )
                        system_prompt_formatted += f"\n\nIMPORTANTE: El usuario_id de este cliente es '{usuario_id}'. Úsalo obligatoriamente al llamar a las herramientas (tools)."
                        
                        from langchain_core.messages import SystemMessage, HumanMessage
                        messages = [SystemMessage(content=system_prompt_formatted)]
                        messages.extend(mensajes_lc)
                        messages.append(HumanMessage(content=mensaje))
                        
                        resultado = cadena_gemini.invoke({"messages": messages})
                        respuesta = resultado["messages"][-1].content
                        self._persistir_mensajes(usuario_id, mensaje, respuesta)
                        return {
                            "exito": True,
                            "respuesta": respuesta,
                        }
                    except Exception as gemini_err:
                        logger.info(f"ERROR en fallback dinámico a Gemini: {gemini_err}")

            import traceback
            traceback.print_exc()
            return {
                "exito": False,
                "respuesta": None,
                "mensaje": f"Error al procesar mensaje: {error_msg}",
            }

    def _convertir_historial(self, historial: List[Dict[str, str]]) -> list:
        """
        Convierte la lista de mensajes del frontend a objetos LangChain.

        :param historial: Lista de dicts con 'rol' y 'contenido'.
        :returns: Lista de HumanMessage/AIMessage.
        """
        mensajes = []
        for msg in historial:
            rol = msg.get("rol", "")
            contenido = msg.get("contenido", "")
            if not contenido:
                continue
            if rol == "usuario":
                mensajes.append(HumanMessage(content=contenido))
            elif rol == "coach":
                mensajes.append(AIMessage(content=contenido))
        return mensajes

    def _obtener_contexto_rag(self, mensaje: str) -> str:
        """
        Busca contexto relevante en la base de conocimiento RAG.

        :param mensaje: Texto del mensaje para buscar contexto relacionado.
        :returns: String con fragmentos relevantes, o vacío si RAG no disponible.
        """
        try:
            from app.servicios.servicio_rag import servicio_rag
            if servicio_rag and servicio_rag.vector_db:
                contexto = servicio_rag.buscar_contexto(mensaje, k=3)
                return contexto or "No hay conocimiento técnico adicional disponible."
        except Exception as e:
            logger.info(f"[ServicioChat] Error obteniendo RAG: {e}")
        return "No hay conocimiento técnico adicional disponible."

    def _construir_contexto_usuario(
        self,
        usuario_id: str,
        contexto_inicial: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Construye un string con el contexto del usuario para el prompt.

        Combina datos del contexto inicial (primer mensaje) con datos
        del perfil en Supabase.

        :param usuario_id: UUID del usuario.
        :param contexto_inicial: Datos enviados por el frontend en el primer mensaje.
        :returns: String formateado con el contexto.
        """
        partes = []

        # Datos del contexto inicial (del frontend)
        if contexto_inicial:
            if contexto_inicial.get("nombre"):
                partes.append(f"- Nombre: {contexto_inicial['nombre']}")
            if contexto_inicial.get("objetivo"):
                partes.append(f"- Objetivo: {contexto_inicial['objetivo']}")
            if contexto_inicial.get("plan_nombre"):
                partes.append(f"- Plan actual: {contexto_inicial['plan_nombre']}")
            if contexto_inicial.get("plan_resumen"):
                partes.append(f"- Descripción del plan: {contexto_inicial['plan_resumen']}")

        # Complementar con perfil de Supabase si hay poco contexto
        if len(partes) < 2:
            perfil = self._obtener_perfil(usuario_id)
            if perfil:
                if perfil.get("nombre") and not any("Nombre" in p for p in partes):
                    partes.append(f"- Nombre: {perfil['nombre']}")
                if perfil.get("objetivo_principal") and not any("Objetivo" in p for p in partes):
                    partes.append(f"- Objetivo: {perfil['objetivo_principal']}")
                if perfil.get("nivel_experiencia"):
                    partes.append(f"- Experiencia: {perfil['nivel_experiencia']}")
                if perfil.get("dias_disponibles_semana"):
                    partes.append(f"- Días disponibles: {perfil['dias_disponibles_semana']}")
                if perfil.get("condiciones_salud") and perfil["condiciones_salud"] != "Ninguna":
                    partes.append(f"- Condiciones de salud: {perfil['condiciones_salud']}")

        # Obtener métricas físicas recientes
        try:
            from app.servicios.servicio_metricas import servicio_metricas
            res_metricas = servicio_metricas.obtener_ultimo(usuario_id)
            if res_metricas.get("exito") and res_metricas.get("datos"):
                m = res_metricas["datos"]
                peso = m.get("peso_corporal_kg")
                fecha = m.get("fecha_registro")
                partes.append(f"- Último peso registrado: {peso} kg (Fecha: {fecha})")
                medidas = []
                if m.get("medida_cintura_cm"): medidas.append(f"Cintura: {m['medida_cintura_cm']}cm")
                if m.get("medida_pecho_cm"): medidas.append(f"Pecho: {m['medida_pecho_cm']}cm")
                if m.get("medida_cadera_cm"): medidas.append(f"Cadera: {m['medida_cadera_cm']}cm")
                if m.get("medida_brazos_cm"): medidas.append(f"Brazos: {m['medida_brazos_cm']}cm")
                if m.get("medida_piernas_cm"): medidas.append(f"Piernas: {m['medida_piernas_cm']}cm")
                if medidas:
                    partes.append(f"- Medidas corporales recientes: {', '.join(medidas)}")
        except Exception as e:
            logger.info(f"[ServicioChat] Error agregando métricas al contexto: {e}")

        # Obtener progreso de entrenamientos recientes
        try:
            from app.servicios.servicio_progreso import servicio_progreso
            res_prog = servicio_progreso.obtener_resumen(usuario_id, "mes")
            if res_prog.get("exito") and res_prog.get("metricas"):
                for met in res_prog["metricas"]:
                    partes.append(f"- Actividad reciente ({met['etiqueta']}): {met['valor']} {met['unidad']}")
        except Exception as e:
            logger.info(f"[ServicioChat] Error agregando progreso al contexto: {e}")

        if not partes:
            return "No hay información adicional del usuario disponible."

        return "\n".join(partes)

    def _obtener_perfil(self, usuario_id: str) -> dict:
        """Obtiene el perfil del usuario desde Supabase."""
        try:
            url = f"{SUPABASE_URL}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario_id}&limit=1"
            headers = {
                "apikey": SUPABASE_KEY or "",
                "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
            }
            response = requests.get(url, headers=headers)
            if response.ok and response.json():
                return response.json()[0]
        except Exception as e:
            logger.info(f"[ServicioChat] Error obteniendo perfil: {e}")
        return {}

    def _persistir_mensajes(self, usuario_id: str, mensaje_usuario: str, respuesta_coach: str):
        """
        Guarda los mensajes en Supabase (sesiones_chat + mensajes_chat).

        Crea una sesión nueva si es necesario, y guarda ambos mensajes.

        :param usuario_id: UUID del usuario.
        :param mensaje_usuario: Texto enviado por el usuario.
        :param respuesta_coach: Texto generado por la IA.
        """
        try:
            # Buscar sesión existente del usuario (la más reciente)
            url_sesiones = (
                f"{SUPABASE_URL}/rest/v1/sesiones_chat"
                f"?usuario_id=eq.{usuario_id}"
                f"&order=fecha_creacion.desc"
                f"&limit=1"
            )
            headers_get = {
                "apikey": SUPABASE_KEY or "",
                "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
            }
            res_sesion = requests.get(url_sesiones, headers=headers_get)

            sesion_id = None
            if res_sesion.ok and res_sesion.json():
                sesion_id = res_sesion.json()[0].get("id")

            # Si no existe sesión, crear una nueva
            if not sesion_id:
                url_nueva_sesion = f"{SUPABASE_URL}/rest/v1/sesiones_chat"
                res_nueva = requests.post(
                    url_nueva_sesion,
                    json={"usuario_id": usuario_id},
                    headers=HEADERS_SUPABASE,
                )
                if res_nueva.ok and res_nueva.json():
                    datos_sesion = res_nueva.json()
                    if isinstance(datos_sesion, list) and len(datos_sesion) > 0:
                        sesion_id = datos_sesion[0].get("id")
                    logger.info(f"[ServicioChat] Nueva sesión creada: {sesion_id}")

            if not sesion_id:
                logger.info(f"[ServicioChat] No se pudo crear/obtener sesión de chat")
                return

            # Guardar mensaje del usuario
            url_mensajes = f"{SUPABASE_URL}/rest/v1/mensajes_chat"
            requests.post(
                url_mensajes,
                json={
                    "sesion_chat_id": sesion_id,
                    "remitente": "usuario",
                    "contenido": mensaje_usuario,
                },
                headers=HEADERS_SUPABASE,
            )

            # Guardar respuesta del coach
            requests.post(
                url_mensajes,
                json={
                    "sesion_chat_id": sesion_id,
                    "remitente": "coach",
                    "contenido": respuesta_coach,
                },
                headers=HEADERS_SUPABASE,
            )

            logger.info(f"[ServicioChat] Mensajes persistidos en sesión {sesion_id}")

        except Exception as e:
            # No fallar si la persistencia falla — la respuesta ya fue entregada
            logger.info(f"[ServicioChat] Error persistiendo mensajes (no crítico): {e}")

    def _respuesta_fallback(self, mensaje: str) -> Dict[str, Any]:
        """
        Genera una respuesta predefinida cuando el LLM no está disponible.

        :param mensaje: Texto del usuario (no usado, pero disponible para futuro).
        :returns: dict con respuesta genérica.
        """
        return {
            "exito": True,
            "respuesta": (
                "¡Hola! Soy tu coach FitAI. En este momento estoy en modo limitado "
                "y no puedo procesar tu consulta con IA. Por favor, verifica que la "
                "configuración del servicio esté activa o intenta más tarde. "
                "¡Mientras tanto, sigue con tu plan de entrenamiento! 💪"
            ),
        }


# Instancia global del servicio (singleton)
servicio_chat = ServicioChat()

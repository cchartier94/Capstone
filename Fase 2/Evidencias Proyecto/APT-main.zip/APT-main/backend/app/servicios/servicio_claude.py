# -*- coding: utf-8 -*-
"""
@file servicio_claude.py
@description Integracion con IA a traves de LangChain para generar
             planes personalizados de entrenamiento y nutricion.

Usa LangChain como framework de orquestacion de IA.
Prioridad de LLM:
  1. Google Gemini (GOOGLE_API_KEY) - gratuito, activo temporalmente
  2. Claude Anthropic (ANTHROPIC_API_KEY) - cuando tenga creditos

Incluye:
- Cálculo de TMB/TDEE con Mifflin-St Jeor
- Prompt profesional con diferenciación por objetivo
- Planes mock inteligentes para cada variante de perfil

Historia Jira: SCRUM-25
@author Carlos Chartier
"""

import os
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)


import json
import math
from typing import Dict, Any
import sys
import io

# Fix Windows console encoding
if sys.platform == 'win32' and getattr(sys.stdout, 'encoding', '') != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser


# ==============================================================================
# Utilidades de cálculo nutricional
# ==============================================================================

FACTOR_ACTIVIDAD = {
    "Sedentario":  1.2,
    "Ligero":      1.375,
    "Moderado":    1.55,
    "Activo":      1.725,
    "Muy activo":  1.9,
}

AJUSTE_OBJETIVO = {
    "bajar_grasa":            -400,   # déficit moderado
    "Bajar grasa":            -400,
    "ganar_masa_muscular":    +300,   # superávit controlado
    "Ganar masa muscular":    +300,
    "mantencion":              0,
    "Mantención":              0,
    "recomposicion_corporal": -150,   # déficit ligero
    "Recomposición corporal": -150,
    "mejorar_rendimiento":    +100,   # ligero superávit
    "Mejorar rendimiento":    +100,
}


def calcular_tmb(peso_kg, estatura_cm, edad, sexo):
    """
    Calcula la Tasa Metabólica Basal con la ecuación de Mifflin-St Jeor.
    Es la fórmula con mayor precisión validada para población general.
    """
    try:
        peso = float(peso_kg)
        est = float(estatura_cm)
        ed = int(edad)
    except (ValueError, TypeError):
        return 2000  # fallback

    tmb = 10 * peso + 6.25 * est - 5 * ed
    sexo_str = str(sexo).lower()
    if sexo_str in ("femenino", "mujer", "f"):
        tmb -= 161
    else:
        tmb += 5
    return round(tmb)


def calcular_tdee(tmb, nivel_actividad):
    """TDEE = TMB × Factor de actividad."""
    factor = FACTOR_ACTIVIDAD.get(nivel_actividad, 1.55)
    return round(tmb * factor)


def calcular_calorias_objetivo(tdee, objetivo):
    """Ajusta calorías según el objetivo del usuario."""
    ajuste = AJUSTE_OBJETIVO.get(objetivo, 0)
    return max(1200, round(tdee + ajuste))  # nunca bajar de 1200 kcal


def calcular_macros(calorias, peso_kg, objetivo):
    """
    Calcula macronutrientes basados en evidencia científica:
    - Proteína según objetivo y literatura ISSN
    - Grasa en rango saludable (0.8-1.0 g/kg)
    - Carbohidratos cubren el resto
    """
    try:
        peso = float(peso_kg)
    except (ValueError, TypeError):
        peso = 70

    obj = str(objetivo).lower()

    # Proteína (g/kg) según objetivo
    if "grasa" in obj or "recomposicion" in obj or "recomposición" in obj:
        prot_por_kg = 2.2
    elif "masa" in obj or "muscular" in obj:
        prot_por_kg = 2.0
    elif "rendimiento" in obj:
        prot_por_kg = 1.8
    else:
        prot_por_kg = 1.6

    proteinas_g = round(peso * prot_por_kg)
    grasas_g = round(peso * 0.9)

    # Carbohidratos = calorías restantes
    cal_prot = proteinas_g * 4
    cal_grasa = grasas_g * 9
    cal_carbs = max(100, calorias - cal_prot - cal_grasa)
    carbohidratos_g = round(cal_carbs / 4)

    return {
        "proteinas_g": proteinas_g,
        "carbohidratos_g": carbohidratos_g,
        "grasas_g": grasas_g,
    }


class ServicioLangChain:
    """
    Servicio de inteligencia artificial basado en LangChain.

    Genera planes de entrenamiento y nutricion personalizados.
    Usa Gemini como LLM principal (gratuito) y Claude como fallback.
    """

    def __init__(self):
        """Inicializa el servicio con el LLM disponible (Claude > Gemini)."""
        self.modelo = None
        self.cadena_plan = None
        self.proveedor = None

        # --- Intentar Claude primero (mejor calidad) ---
        anthropic_key = os.getenv("ANTHROPIC_API_KEY")
        if anthropic_key:
            try:
                from langchain_anthropic import ChatAnthropic
                self.modelo = ChatAnthropic(
                    model="claude-3-5-sonnet-20241022",
                    api_key=anthropic_key,
                    temperature=0.7,
                    max_tokens=4000,
                )
                self.proveedor = "Claude"
                logger.info(f"OK: Servicio LangChain + Claude inicializado")
            except Exception as e:
                logger.info(f"ADVERTENCIA: No se pudo inicializar Claude: {e}")

        # --- Fallback a Gemini (gratuito) ---
        if not self.modelo:
            google_key = os.getenv("GOOGLE_API_KEY")
            if google_key:
                try:
                    from langchain_google_genai import ChatGoogleGenerativeAI
                    self.modelo = ChatGoogleGenerativeAI(
                        model="gemini-2.5-flash",
                        google_api_key=google_key,
                        temperature=0.7,
                        max_output_tokens=4000,
                    )
                    self.proveedor = "Gemini"
                    logger.info(f"OK: Servicio LangChain + Gemini inicializado")
                except Exception as e:
                    logger.info(f"ADVERTENCIA: No se pudo inicializar Gemini: {e}")

        # --- Configurar cadena si hay modelo ---
        if self.modelo:
            self.parser_json = JsonOutputParser()
            self.prompt_plan = ChatPromptTemplate.from_messages([
                ("system", self._obtener_prompt_sistema()),
                ("human", self._obtener_prompt_usuario()),
            ])
            self.cadena_plan = self.prompt_plan | self.modelo | self.parser_json
        else:
            logger.info(f"ADVERTENCIA: Ningun LLM configurado")

    def _obtener_prompt_sistema(self) -> str:
        """
        Prompt de sistema profesional con conocimiento de entrenamiento deportivo.
        """
        return """Eres FitAI Coach, un entrenador personal certificado NSCA-CSCS y nutricionista 
deportivo ISSN con 15 años de experiencia. Diseñas planes de entrenamiento y nutrición 
científicamente fundamentados y personalizados.

PRINCIPIOS PROFESIONALES QUE SIGUES:
1. Sobrecarga progresiva: cada semana aumenta ligeramente la exigencia.
2. Especificidad: el plan refleja EXACTAMENTE el objetivo del usuario.
3. Individualización: consideras edad, sexo, experiencia, limitaciones de salud y equipo disponible.
4. Periodización: las 4 semanas tienen progresión lógica (adaptación → desarrollo).
5. Recuperación: distribuyes los días de descanso estratégicamente, nunca 2 grupos grandes consecutivos.
6. Seguridad: las condiciones de salud determinan ejercicios prohibidos y sustituciones.

PROTOCOLOS POR OBJETIVO:
- BAJAR GRASA: Déficit calórico. Entrenamiento de fuerza con descanso corto (45-90s). 
  Incluir 2-3 sesiones de cardio HIIT o LISS. Circuitos metabólicos. Supersets. 
  Priorizar compuestos. Proteína alta (2.0-2.4 g/kg) para preservar masa muscular.

- GANAR MASA MUSCULAR: Superávit calórico. Volumen alto (10-20 series/grupo/semana). 
  Descanso largo (90-180s). Rango 6-12 reps. Tempo controlado (2-0-2). 
  Split Push/Pull/Legs o Upper/Lower. Sobrecarga progresiva en compuestos principales.

- MANTENCIÓN: Calorías al TDEE. Volumen moderado (60-70% de fase de ganancia). 
  3-4 días de entrenamiento. Cardio moderado para salud cardiovascular. 
  Mantener fuerza sin acumular fatiga excesiva.

- RECOMPOSICIÓN CORPORAL: Déficit ligero o isocalórico. Proteína MUY alta (2.0-2.4 g/kg). 
  Entrenamiento de fuerza intenso con cargas pesadas. Combinar fuerza + HIIT. 
  Upper/Lower o Full Body 4x/semana. Ideal para principiantes o detrained.

- MEJORAR RENDIMIENTO: Periodización ondulante. Bloques de fuerza, potencia y resistencia. 
  Incluir pliometría y trabajo funcional. Movilidad y estabilidad. 
  Descanso largo en series pesadas (2-5 min).

REGLAS POR NIVEL DE EXPERIENCIA:
- PRINCIPIANTE: Máximo 3 ejercicios por grupo, 2-3 series. Full Body 3x/semana. 
  Enfoque en técnica. Reps altas (10-15). Progresión lineal simple.
- INTERMEDIO: 3-4 ejercicios por grupo, 3-4 series. Split de 4-5 días. 
  Variedad de rangos (6-15). Drop sets y supersets ocasionales.
- AVANZADO: 4-5 ejercicios por grupo, 4-5 series. Split de 5-6 días. 
  RPE/RIR para autorregulación. Técnicas avanzadas. Deload cada 4 semanas.

REGLAS POR LUGAR DE ENTRENAMIENTO:
- GIMNASIO: Usar barras, mancuernas, poleas, máquinas. Máxima variedad.
- CASA: Usar peso corporal, bandas elásticas, mancuernas si tiene. Adaptar todos los ejercicios.
- PARQUE/CALISTENIA: Dominadas, fondos, flexiones, sentadillas pistola, muscle-ups progresiones.

CONSIDERACIONES DE SALUD:
- Problemas de espalda: Evitar peso muerto convencional. Usar trap bar o sumo. 
  Fortalecer core estabilizador.
- Problemas de rodilla: Evitar sentadilla profunda con carga alta. 
  Preferir prensa y sentadilla parcial.
- Problemas de hombro: Evitar press detrás del cuello. 
  Usar agarre neutro. Face pulls obligatorios.
- Hipertensión: Evitar Valsalva. Series de 12-15 reps. Cardio aeróbico regular.
- Diabetes: No entrenar en ayunas con insulina. Monitorear glucosa.

REGLAS ESTRICTAS DE FORMATO:
1. SIEMPRE responde en español.
2. SIEMPRE responde ÚNICAMENTE con un JSON válido, sin texto ni markdown adicional.
3. Genera EXACTAMENTE los 7 días de la semana (Lunes a Domingo).
4. Los días de entrenamiento tienen "rutina" como LISTA de ejercicios.
5. Los días de descanso tienen "rutina": "Descanso" o una actividad de recuperación.
6. Cada ejercicio DEBE incluir: nombre, grupo_muscular, series, reps, descanso, notas.
7. Las notas deben incluir cues técnicos profesionales específicos, NO genéricos."""

    def _obtener_prompt_usuario(self) -> str:
        """
        Template del prompt de usuario con todas las variables del perfil,
        incluyendo lugar de entrenamiento, cálculos nutricionales y IMC.
        """
        return """Genera un plan de entrenamiento semanal COMPLETO y PROFESIONAL para este usuario:

PERFIL DEL USUARIO:
- Nombre: {nombre}
- Edad: {edad} años
- Sexo biológico: {sexo}
- Peso actual: {peso} kg
- Estatura: {estatura} cm
- IMC calculado: {imc}
- Objetivo principal: {objetivo}
- Nivel de actividad diaria: {nivel_actividad}
- Experiencia en entrenamiento: {experiencia}
- Lugar de entrenamiento: {lugar_entrenamiento}
- Tipo de entrenamiento preferido: {tipo_entrenamiento}
- Días disponibles por semana: {dias_disponibles}
- Tiempo por sesión: {tiempo_sesion} minutos
- Condiciones de salud: {condiciones_salud}
- Tipo de dieta: {tipo_dieta}
- Alimentos excluidos: {alimentos_excluidos}

CÁLCULOS NUTRICIONALES (ya calculados, úsalos como referencia):
- TMB (Mifflin-St Jeor): {tmb} kcal
- TDEE (con actividad): {tdee} kcal
- Calorías objetivo (ajustadas a "{objetivo}"): {calorias_objetivo} kcal
- Macros recomendados: Proteínas {proteinas_g}g | Carbohidratos {carbohidratos_g}g | Grasas {grasas_g}g

INSTRUCCIONES ESPECÍFICAS PARA ESTE OBJETIVO "{objetivo}":
{instrucciones_objetivo}

FORMATO JSON REQUERIDO (respeta esta estructura EXACTA):
{{
    "nombre_plan": "Nombre descriptivo que incluya el objetivo",
    "resumen": "Resumen profesional de 2-3 líneas explicando el enfoque del plan",
    "duracion_semanas": 4,
    "calorias_diarias_recomendadas": {calorias_objetivo},
    "macros_recomendados": {{
        "proteinas_g": {proteinas_g},
        "carbohidratos_g": {carbohidratos_g},
        "grasas_g": {grasas_g}
    }},
    "semana": [
        {{
            "dia": "Lunes",
            "tipo": "Descripción del enfoque del día",
            "es_descanso": false,
            "rutina": [
                {{
                    "nombre": "Nombre del ejercicio",
                    "grupo_muscular": "Grupo muscular principal",
                    "series": 4,
                    "reps": "8-10",
                    "descanso": "90 seg",
                    "notas": "Cue técnico profesional específico"
                }}
            ]
        }},
        {{
            "dia": "Martes",
            "tipo": "Descanso activo",
            "es_descanso": true,
            "rutina": []
        }}
    ],
    "consejos": [
        "Consejo personalizado 1 basado en el perfil",
        "Consejo personalizado 2",
        "Consejo personalizado 3",
        "Consejo personalizado 4"
    ]
}}

REGLAS OBLIGATORIAS:
- Genera TODOS los 7 días (Lunes a Domingo).
- Distribuye EXACTAMENTE {dias_disponibles} días de entrenamiento y {dias_descanso} de descanso/recuperación.
- Cada día de entrenamiento debe tener mínimo {min_ejercicios} ejercicios (según nivel {experiencia}).
- Adapta ejercicios al lugar: {lugar_entrenamiento} con equipo de {tipo_entrenamiento}.
- Los descansos entre series van acorde al objetivo: {descanso_recomendado}.
- Si hay condiciones de salud, adapta o sustituye ejercicios riesgosos.
- Incluye calentamiento y vuelta a la calma en las notas del primer y último ejercicio.

Responde SOLO con el JSON, sin markdown, sin texto adicional, sin ```."""

    def _obtener_instrucciones_objetivo(self, objetivo: str) -> str:
        """Retorna instrucciones específicas por objetivo para inyectar en el prompt."""
        obj = str(objetivo).lower()

        if "grasa" in obj:
            return """- Diseña un plan con DÉFICIT CALÓRICO y alta actividad.
- Incluye 2-3 sesiones de cardio (HIIT de 15-20 min o LISS de 30-40 min).
- Usa circuitos metabólicos y supersets para maximizar gasto calórico.
- Descanso corto entre series (45-90 seg).
- Prioriza ejercicios compuestos multi-articulares.
- La rutina de fuerza es ESENCIAL para preservar masa muscular en déficit.
- Incluye al menos un día de cardio puro (HIIT o caminata inclinada)."""

        elif "masa" in obj or "muscular" in obj:
            return """- Diseña un plan de HIPERTROFIA con superávit calórico controlado.
- Volumen alto: 10-20 series por grupo muscular por semana.
- Rango principal de repeticiones: 6-12 reps.
- Descanso largo en compuestos (90-180 seg), moderado en aislamiento (60-90 seg).
- Usa split Push/Pull/Legs o Upper/Lower según los días disponibles.
- Incluye SIEMPRE los 5 grandes: sentadilla, peso muerto, press banca, press militar, dominadas.
- Tempo controlado: 2 seg excéntrica.
- Prioriza la sobrecarga progresiva en ejercicios compuestos."""

        elif "mantencion" in obj or "mantención" in obj:
            return """- Diseña un plan de MANTENIMIENTO equilibrado.
- Volumen moderado: 60-70% de un plan de ganancia.
- Incluir 2-3 sesiones de cardio moderado para salud cardiovascular.
- Equilibrio entre fuerza y acondicionamiento.
- No buscar récords, sino mantener las capacidades actuales.
- Descanso entre series: 60-120 seg.
- Incluir trabajo de movilidad y flexibilidad."""

        elif "recomposicion" in obj or "recomposición" in obj:
            return """- Diseña un plan de RECOMPOSICIÓN CORPORAL.
- Combina entrenamiento de fuerza intenso con sesiones de HIIT.
- Proteína MUY alta para el déficit ligero.
- Cargas pesadas (75-85% 1RM) con volumen moderado.
- Split Upper/Lower 4x/semana o Full Body si son 3 días.
- Incluir 1-2 sesiones de HIIT cortas (15-20 min).
- Ejercicios compuestos como base, aislamiento como complemento."""

        elif "rendimiento" in obj:
            return """- Diseña un plan de RENDIMIENTO DEPORTIVO.
- Periodización ondulante: alternar días de fuerza, potencia y resistencia.
- Incluir trabajo de pliometría y explosividad.
- Ejercicios funcionales y multiplanares.
- Descanso largo en series de fuerza (2-3 min), corto en circuitos.
- Incluir trabajo de movilidad articular y estabilidad.
- Incorporar sprint o trabajo de agilidad 1-2 veces por semana."""

        else:
            return """- Diseña un plan equilibrado de acondicionamiento general.
- Combinar fuerza, cardio y flexibilidad.
- Progresión moderada y sostenible.
- Incluir variedad de estímulos."""

    def _params_por_nivel(self, experiencia: str) -> dict:
        """Retorna parámetros de entrenamiento según nivel."""
        exp = str(experiencia).lower()
        if "principiante" in exp:
            return {"min_ejercicios": 3, "descanso_recomendado": "60-90 segundos"}
        elif "avanzado" in exp:
            return {"min_ejercicios": 5, "descanso_recomendado": "variable según objetivo (60-180 seg)"}
        else:  # intermedio
            return {"min_ejercicios": 4, "descanso_recomendado": "60-120 segundos"}

    # ==========================================================================
    # Plan Mock inteligente — genera rutinas específicas por variante de perfil
    # ==========================================================================

    def _obtener_plan_mock(self, perfil: Dict[str, Any]) -> Dict[str, Any]:
        """
        Genera un plan mock de alta calidad adaptado al perfil del usuario.
        A diferencia del mock anterior (único para todos), este diferencia por:
        - Objetivo (5 variantes)
        - Nivel de experiencia (3 variantes)
        - Lugar de entrenamiento (3 variantes)
        - Sexo (ajuste nutricional)
        """
        nombre = perfil.get("nombre", "Usuario")
        objetivo = perfil.get("objetivo_principal", "Mantención")
        experiencia = perfil.get("nivel_experiencia", "Intermedio")
        lugar = perfil.get("lugar_entrenamiento", "Gimnasio")
        dias_disponibles = int(perfil.get("dias_disponibles_semana", 4))
        peso = perfil.get("peso_actual_kg", 70)
        estatura = perfil.get("estatura_cm", 170)
        edad = perfil.get("edad", 30)
        sexo = perfil.get("sexo_biologico", "Masculino")

        # Calcular nutrición
        tmb = calcular_tmb(peso, estatura, edad, sexo)
        tdee = calcular_tdee(tmb, perfil.get("nivel_actividad", "Moderado"))
        calorias = calcular_calorias_objetivo(tdee, objetivo)
        macros = calcular_macros(calorias, peso, objetivo)

        # Seleccionar rutina según objetivo + lugar
        semana = self._generar_semana_mock(objetivo, experiencia, lugar, dias_disponibles)

        obj_lower = str(objetivo).lower()
        if "grasa" in obj_lower:
            nombre_plan = f"Plan Quema Grasa — {nombre}"
            resumen = f"Plan de definición con déficit calórico de {tdee - calorias} kcal. Combina entrenamiento de fuerza con circuitos metabólicos y cardio HIIT para maximizar la pérdida de grasa preservando masa muscular. Proteína alta a {macros['proteinas_g']}g/día."
        elif "masa" in obj_lower or "muscular" in obj_lower:
            nombre_plan = f"Plan Hipertrofia — {nombre}"
            resumen = f"Plan de ganancia muscular con superávit controlado de {calorias - tdee} kcal. Enfoque en sobrecarga progresiva en los compuestos principales, volumen alto por grupo muscular y recuperación adecuada."
        elif "recomposicion" in obj_lower or "recomposición" in obj_lower:
            nombre_plan = f"Plan Recomposición — {nombre}"
            resumen = f"Plan de recomposición corporal con déficit ligero. Combina fuerza pesada con HIIT para perder grasa y ganar músculo simultáneamente. Proteína elevada a {macros['proteinas_g']}g/día."
        elif "rendimiento" in obj_lower:
            nombre_plan = f"Plan Rendimiento — {nombre}"
            resumen = f"Plan de rendimiento deportivo con periodización ondulante. Alterna bloques de fuerza, potencia y resistencia para desarrollo atlético integral."
        else:
            nombre_plan = f"Plan Mantenimiento — {nombre}"
            resumen = f"Plan equilibrado de mantenimiento con {calorias} kcal/día. Volumen moderado para preservar la composición corporal actual con buen acondicionamiento cardiovascular."

        return {
            "nombre_plan": f"{nombre_plan} (Modo Simulado)",
            "resumen": resumen,
            "duracion_semanas": 4,
            "calorias_diarias_recomendadas": calorias,
            "macros_recomendados": macros,
            "semana": semana,
            "consejos": self._generar_consejos_mock(objetivo, perfil),
        }

    def _generar_semana_mock(self, objetivo, experiencia, lugar, dias_disponibles):
        """Genera la semana de entrenamiento adaptada a objetivo, nivel y lugar."""
        obj = str(objetivo).lower()
        es_gym = "gimnasio" in str(lugar).lower() or "gym" in str(lugar).lower()
        es_casa = "casa" in str(lugar).lower()
        es_principiante = "principiante" in str(experiencia).lower()
        es_avanzado = "avanzado" in str(experiencia).lower()

        # ── Ejercicios por lugar ──
        if es_gym:
            ejercicios = {
                "pecho_empuje": [
                    {"nombre": "Press de banca con barra", "grupo_muscular": "Pecho", "notas": "Escápulas retraídas, arco natural. Bajar hasta tocar el pecho."},
                    {"nombre": "Press inclinado con mancuernas", "grupo_muscular": "Pecho superior", "notas": "30° de inclinación. Apretar en la cima del movimiento."},
                    {"nombre": "Cruces en polea alta", "grupo_muscular": "Pecho", "notas": "Codos ligeramente flexionados. Sentir el estiramiento en pectorales."},
                    {"nombre": "Press militar con barra", "grupo_muscular": "Hombros", "notas": "Core activado, no arquear la espalda. Barra pasa frente a la cara."},
                    {"nombre": "Elevaciones laterales", "grupo_muscular": "Deltoides lateral", "notas": "Codos ligeramente por encima de las muñecas. Sin impulso."},
                    {"nombre": "Extensión de tríceps en polea", "grupo_muscular": "Tríceps", "notas": "Codos pegados al cuerpo. Extensión completa."},
                ],
                "espalda_traccion": [
                    {"nombre": "Dominadas o jalón al pecho", "grupo_muscular": "Espalda", "notas": "Agarre prono, ancho de hombros+. Llevar codos hacia las costillas."},
                    {"nombre": "Remo con barra", "grupo_muscular": "Espalda", "notas": "45° de inclinación del torso. Llevar barra al ombligo. Apretar escápulas."},
                    {"nombre": "Remo en polea baja", "grupo_muscular": "Espalda", "notas": "Agarre neutro. Estirar completamente y contraer escápulas."},
                    {"nombre": "Face pulls", "grupo_muscular": "Deltoides posterior", "notas": "Cuerda a la altura de la cara. Rotación externa al final."},
                    {"nombre": "Curl bíceps con barra", "grupo_muscular": "Bíceps", "notas": "Codos fijos. Sin balanceo. Controlar la bajada."},
                    {"nombre": "Curl martillo con mancuernas", "grupo_muscular": "Braquial", "notas": "Agarre neutro. Alternado o simultáneo."},
                ],
                "piernas": [
                    {"nombre": "Sentadilla con barra", "grupo_muscular": "Cuádriceps/Glúteos", "notas": "Barra en posición alta. Bajar hasta romper paralelo. Rodillas en línea con los pies."},
                    {"nombre": "Peso muerto rumano", "grupo_muscular": "Isquiotibiales/Glúteos", "notas": "Barra pegada a las piernas. Bisagra de cadera. Sentir estiramiento en isquios."},
                    {"nombre": "Prensa de piernas", "grupo_muscular": "Cuádriceps", "notas": "Pies a ancho de hombros. No bloquear rodillas arriba. 90° de flexión."},
                    {"nombre": "Curl femoral acostado", "grupo_muscular": "Isquiotibiales", "notas": "Contracción máxima arriba. Bajar controlado 2 seg."},
                    {"nombre": "Hip thrust con barra", "grupo_muscular": "Glúteos", "notas": "Espalda apoyada en banco. Apretar glúteos arriba 1 seg. No hiperextender lumbar."},
                    {"nombre": "Elevación de pantorrillas", "grupo_muscular": "Pantorrillas", "notas": "Rango completo de movimiento. Pausa abajo para estiramiento."},
                ],
                "core": [
                    {"nombre": "Plancha frontal", "grupo_muscular": "Core", "notas": "Cuerpo alineado de cabeza a talones. Activar transverso abdominal."},
                    {"nombre": "Crunch en polea", "grupo_muscular": "Abdominales", "notas": "Flexión de tronco, no de cadera. Exhalar al contraer."},
                    {"nombre": "Pallof press", "grupo_muscular": "Core anti-rotación", "notas": "Resistir la rotación. Mantener 2 seg con brazos extendidos."},
                ],
                "cardio_hiit": {"nombre": "HIIT en bicicleta estática", "tipo": "Cardio HIIT", "desc": "20 min: 30 seg sprint máximo / 60 seg recuperación × 12 rondas. Calentar 3 min, enfriar 3 min."},
                "cardio_liss": {"nombre": "Caminata inclinada", "tipo": "Cardio LISS (zona 2)", "desc": "35-45 min de caminata en cinta con 10-12% de inclinación a ritmo conversacional."},
            }
        elif es_casa:
            ejercicios = {
                "pecho_empuje": [
                    {"nombre": "Flexiones estándar", "grupo_muscular": "Pecho", "notas": "Manos a ancho de hombros. Bajar hasta que el pecho casi toque el suelo."},
                    {"nombre": "Flexiones inclinadas (pies elevados)", "grupo_muscular": "Pecho superior", "notas": "Pies sobre silla o step. Mayor activación del pectoral superior."},
                    {"nombre": "Flexiones diamante", "grupo_muscular": "Tríceps/Pecho", "notas": "Manos juntas formando diamante. Codos pegados al cuerpo."},
                    {"nombre": "Pike push-ups", "grupo_muscular": "Hombros", "notas": "Cadera elevada en V invertida. Simula press militar."},
                    {"nombre": "Elevaciones laterales con bandas", "grupo_muscular": "Deltoides lateral", "notas": "Pisar la banda, elevar hasta la horizontal. Control en la bajada."},
                    {"nombre": "Dips entre sillas", "grupo_muscular": "Tríceps", "notas": "Manos en dos sillas estables. Bajar 90° de codo."},
                ],
                "espalda_traccion": [
                    {"nombre": "Remo invertido en mesa", "grupo_muscular": "Espalda", "notas": "Cuerpo recto bajo mesa resistente. Tirar el pecho hacia la mesa."},
                    {"nombre": "Remo con banda elástica", "grupo_muscular": "Espalda", "notas": "Banda anclada a la puerta. Apretar escápulas al final del remo."},
                    {"nombre": "Face pulls con banda", "grupo_muscular": "Deltoides posterior", "notas": "Banda a la altura de la cara. Rotación externa al final."},
                    {"nombre": "Superman hold", "grupo_muscular": "Espalda baja", "notas": "Levantar brazos y piernas simultáneamente. Mantener 3 seg arriba."},
                    {"nombre": "Curl bíceps con banda", "grupo_muscular": "Bíceps", "notas": "Pisar la banda. Codo fijo, curl controlado."},
                    {"nombre": "Curl isométrico con toalla", "grupo_muscular": "Bíceps", "notas": "Toalla en el pie, tirar con bíceps contra la resistencia. 10 seg por rep."},
                ],
                "piernas": [
                    {"nombre": "Sentadilla búlgara", "grupo_muscular": "Cuádriceps/Glúteos", "notas": "Pie trasero en silla. Bajar hasta 90° rodilla delantera. Torso erguido."},
                    {"nombre": "Peso muerto una pierna", "grupo_muscular": "Isquiotibiales/Glúteos", "notas": "Bisagra de cadera con una pierna. Mantener espalda neutra."},
                    {"nombre": "Zancadas caminando", "grupo_muscular": "Cuádriceps/Glúteos", "notas": "Paso largo. Rodilla trasera casi toca el suelo."},
                    {"nombre": "Puente de glúteos una pierna", "grupo_muscular": "Glúteos", "notas": "Espalda en el suelo, una pierna extendida. Apretar glúteo arriba 2 seg."},
                    {"nombre": "Sentadilla pistola (asistida)", "grupo_muscular": "Cuádriceps", "notas": "Sujetarse de la puerta para asistencia. Bajar controlado con una pierna."},
                    {"nombre": "Elevación de pantorrillas un pie", "grupo_muscular": "Pantorrillas", "notas": "En un step o escalón. Rango completo. 3 seg bajada."},
                ],
                "core": [
                    {"nombre": "Plancha frontal", "grupo_muscular": "Core", "notas": "Cuerpo alineado. Activar transverso. No dejar caer la cadera."},
                    {"nombre": "Dead bug", "grupo_muscular": "Core anti-extensión", "notas": "Espalda baja pegada al suelo. Extender brazo y pierna opuestos."},
                    {"nombre": "Mountain climbers", "grupo_muscular": "Core/Cardio", "notas": "Posición de plancha. Rodillas al pecho alternando. Ritmo controlado."},
                ],
                "cardio_hiit": {"nombre": "Tabata en casa", "tipo": "Cardio HIIT", "desc": "20 min: Burpees, mountain climbers, jumping jacks, sentadillas con salto. 20 seg trabajo / 10 seg descanso × 8 rondas por ejercicio."},
                "cardio_liss": {"nombre": "Caminata activa", "tipo": "Cardio LISS (zona 2)", "desc": "35-45 min de caminata a paso rápido al aire libre o subir/bajar escaleras."},
            }
        else:  # Parque / Calistenia
            ejercicios = {
                "pecho_empuje": [
                    {"nombre": "Fondos en paralelas", "grupo_muscular": "Pecho/Tríceps", "notas": "Inclinarse ligeramente hacia adelante para pecho. Codos a 90°."},
                    {"nombre": "Flexiones explosivas", "grupo_muscular": "Pecho", "notas": "Fase concéntrica explosiva, despegar manos del suelo."},
                    {"nombre": "Flexiones archer", "grupo_muscular": "Pecho", "notas": "Manos muy separadas. Flexionar un brazo, extender el otro."},
                    {"nombre": "Pike push-ups en barra baja", "grupo_muscular": "Hombros", "notas": "Pies en barra baja, cadera alta. Press vertical."},
                    {"nombre": "Flexiones declinadas", "grupo_muscular": "Pecho superior", "notas": "Pies en banco del parque. Mayor activación superior."},
                ],
                "espalda_traccion": [
                    {"nombre": "Dominadas pronación", "grupo_muscular": "Espalda/Bíceps", "notas": "Agarre prono, iniciar tirando escápulas. Barbilla sobre barra."},
                    {"nombre": "Dominadas supinación", "grupo_muscular": "Bíceps/Espalda", "notas": "Agarre supino, más activación de bíceps. Control en la bajada."},
                    {"nombre": "Australian rows", "grupo_muscular": "Espalda", "notas": "Barra baja, cuerpo inclinado. Tirar pecho a la barra."},
                    {"nombre": "Muscle-up (negativas)", "grupo_muscular": "Espalda/Pecho", "notas": "Saltar a posición superior, bajar controlado 5 seg. Progresión."},
                    {"nombre": "L-sit en barras", "grupo_muscular": "Core/Hip flexors", "notas": "Piernas extendidas horizontales. Mantener el mayor tiempo posible."},
                ],
                "piernas": [
                    {"nombre": "Sentadilla pistola", "grupo_muscular": "Cuádriceps", "notas": "Una pierna. Usar poste para asistencia si necesario."},
                    {"nombre": "Box jumps (banco del parque)", "grupo_muscular": "Cuádriceps/Glúteos", "notas": "Salto explosivo. Aterrizar suave con rodillas flexionadas."},
                    {"nombre": "Zancadas con salto", "grupo_muscular": "Cuádriceps/Glúteos", "notas": "Alternar piernas en el aire. Aterrizar suave."},
                    {"nombre": "Step-ups en banco", "grupo_muscular": "Cuádriceps/Glúteos", "notas": "Subir completamente con una pierna. No empujar con la pierna de atrás."},
                    {"nombre": "Sprint 30 metros", "grupo_muscular": "Piernas/Potencia", "notas": "Explosivo desde parado. Recuperar caminando de vuelta."},
                ],
                "core": [
                    {"nombre": "Hanging leg raises", "grupo_muscular": "Abdominales", "notas": "Colgado de barra. Subir piernas rectas hasta horizontal. Sin balanceo."},
                    {"nombre": "Plancha en barra baja", "grupo_muscular": "Core", "notas": "Manos en barra, cuerpo recto. Más difícil por la inestabilidad."},
                    {"nombre": "Dragon flag (progresión)", "grupo_muscular": "Core", "notas": "En banco. Bajar cuerpo recto desde los hombros. Controlar el descenso."},
                ],
                "cardio_hiit": {"nombre": "Sprints en pista", "tipo": "Cardio HIIT", "desc": "15 min: Sprint 100m máxima intensidad / Caminar 100m recuperación × 8-10 rondas."},
                "cardio_liss": {"nombre": "Trote suave zona 2", "tipo": "Cardio LISS (zona 2)", "desc": "30-40 min de trote suave manteniendo conversación. Frecuencia cardíaca al 60-70% del máximo."},
            }

        # ── Determinar series/reps según objetivo y nivel ──
        if "grasa" in str(objetivo).lower():
            series_base, reps_base = (3, "12-15") if es_principiante else (4, "10-15") if not es_avanzado else (4, "12-15")
            descanso_base = "45 seg" if es_principiante else "30-60 seg"
        elif "masa" in str(objetivo).lower() or "muscular" in str(objetivo).lower():
            series_base, reps_base = (3, "10-12") if es_principiante else (4, "6-10") if not es_avanzado else (5, "6-10")
            descanso_base = "90 seg" if es_principiante else "90-120 seg" if not es_avanzado else "120-180 seg"
        elif "rendimiento" in str(objetivo).lower():
            series_base, reps_base = (3, "8-12") if es_principiante else (4, "5-8") if not es_avanzado else (5, "3-6")
            descanso_base = "90 seg" if es_principiante else "120-180 seg"
        elif "recomposicion" in str(objetivo).lower() or "recomposición" in str(objetivo).lower():
            series_base, reps_base = (3, "8-12") if es_principiante else (4, "6-10") if not es_avanzado else (4, "6-10")
            descanso_base = "60-90 seg"
        else:  # mantención
            series_base, reps_base = (3, "10-12") if es_principiante else (3, "8-12") if not es_avanzado else (4, "8-12")
            descanso_base = "60-90 seg"

        # Determinar cuántos ejercicios por sesión
        if es_principiante:
            n_ejercicios = 3
        elif es_avanzado:
            n_ejercicios = 5
        else:
            n_ejercicios = 4

        def hacer_rutina(grupo_key, limit=None):
            """Convierte la lista de ejercicios en formato de rutina con series/reps."""
            ejs = ejercicios[grupo_key][:limit or n_ejercicios]
            return [
                {
                    "nombre": e["nombre"],
                    "grupo_muscular": e["grupo_muscular"],
                    "series": series_base,
                    "reps": reps_base,
                    "descanso": descanso_base,
                    "notas": e["notas"],
                }
                for e in ejs
            ]

        def dia_cardio_hiit():
            c = ejercicios["cardio_hiit"]
            return {"dia": "", "tipo": c["tipo"], "rutina": c["desc"]}

        def dia_cardio_liss():
            c = ejercicios["cardio_liss"]
            return {"dia": "", "tipo": c["tipo"], "rutina": c["desc"]}

        def dia_descanso():
            return {"dia": "", "tipo": "Descanso Total", "rutina": "Descanso completo. Hidratación, sueño de calidad y alimentación según plan."}

        def dia_descanso_activo():
            return {"dia": "", "tipo": "Descanso Activo", "rutina": "20-30 min de caminata suave, estiramientos y foam rolling. Movilidad de cadera y hombros."}

        # ── Construir la semana según objetivo y días ──
        dias_nombres = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

        obj_lower = str(objetivo).lower()

        if "grasa" in obj_lower:
            if dias_disponibles <= 3:
                semana_raw = [
                    {"tipo": "Full Body + Circuito", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 1)},
                    dia_descanso_activo(),
                    {"tipo": "Full Body + HIIT", "rutina": hacer_rutina("espalda_traccion", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 1)},
                    dia_descanso_activo(),
                    {"tipo": "Full Body + Cardio", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("espalda_traccion", 2) + hacer_rutina("core", 1)},
                    dia_cardio_liss(),
                    dia_descanso(),
                ]
            elif dias_disponibles <= 5:
                semana_raw = [
                    {"tipo": "Tren Superior — Empuje + Circuito", "rutina": hacer_rutina("pecho_empuje")},
                    {"tipo": "Tren Inferior — Fuerza + Cardio", "rutina": hacer_rutina("piernas")},
                    dia_descanso_activo(),
                    {"tipo": "Tren Superior — Tracción + Core", "rutina": hacer_rutina("espalda_traccion", n_ejercicios) + hacer_rutina("core", 2)},
                    dia_cardio_hiit(),
                    {"tipo": "Full Body — Circuito Metabólico", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 1)},
                    dia_descanso(),
                ]
            else:
                semana_raw = [
                    {"tipo": "Empuje — Fuerza", "rutina": hacer_rutina("pecho_empuje")},
                    {"tipo": "Tracción — Fuerza", "rutina": hacer_rutina("espalda_traccion")},
                    {"tipo": "Piernas — Fuerza", "rutina": hacer_rutina("piernas")},
                    dia_descanso_activo(),
                    dia_cardio_hiit(),
                    {"tipo": "Full Body — Circuito Metabólico", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 2)},
                    dia_descanso(),
                ]

        elif "masa" in obj_lower or "muscular" in obj_lower:
            if dias_disponibles <= 3:
                semana_raw = [
                    {"tipo": "Full Body A — Compuestos", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("piernas", 2) + hacer_rutina("espalda_traccion", 1)},
                    dia_descanso(),
                    {"tipo": "Full Body B — Compuestos", "rutina": hacer_rutina("espalda_traccion", 2) + hacer_rutina("piernas", 2) + hacer_rutina("pecho_empuje", 1)},
                    dia_descanso(),
                    {"tipo": "Full Body C — Volumen", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("espalda_traccion", 2) + hacer_rutina("piernas", 1)},
                    dia_descanso_activo(),
                    dia_descanso(),
                ]
            elif dias_disponibles <= 5:
                semana_raw = [
                    {"tipo": "Tren Superior — Empuje (Pecho/Hombros/Tríceps)", "rutina": hacer_rutina("pecho_empuje")},
                    {"tipo": "Tren Inferior — Cuádriceps/Glúteos", "rutina": hacer_rutina("piernas")},
                    dia_descanso(),
                    {"tipo": "Tren Superior — Tracción (Espalda/Bíceps)", "rutina": hacer_rutina("espalda_traccion")},
                    {"tipo": "Tren Inferior — Isquios/Glúteos + Core", "rutina": hacer_rutina("piernas", 3) + hacer_rutina("core", 2)},
                    dia_descanso_activo(),
                    dia_descanso(),
                ]
            else:
                semana_raw = [
                    {"tipo": "Push — Pecho/Hombros/Tríceps", "rutina": hacer_rutina("pecho_empuje")},
                    {"tipo": "Pull — Espalda/Bíceps", "rutina": hacer_rutina("espalda_traccion")},
                    {"tipo": "Legs — Cuádriceps/Glúteos/Isquios", "rutina": hacer_rutina("piernas")},
                    dia_descanso(),
                    {"tipo": "Push B — Volumen", "rutina": hacer_rutina("pecho_empuje")},
                    {"tipo": "Pull B + Core", "rutina": hacer_rutina("espalda_traccion", 3) + hacer_rutina("core", 2)},
                    dia_descanso(),
                ]

        elif "recomposicion" in obj_lower or "recomposición" in obj_lower:
            if dias_disponibles <= 3:
                semana_raw = [
                    {"tipo": "Full Body — Fuerza Pesada", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("piernas", 2) + hacer_rutina("espalda_traccion", 1)},
                    dia_descanso_activo(),
                    {"tipo": "Full Body — Volumen + HIIT", "rutina": hacer_rutina("espalda_traccion", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 1)},
                    dia_descanso(),
                    {"tipo": "Full Body — Compuestos + Cardio", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 1)},
                    dia_cardio_liss(),
                    dia_descanso(),
                ]
            else:
                semana_raw = [
                    {"tipo": "Upper Body — Fuerza", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("espalda_traccion", 2)},
                    {"tipo": "Lower Body — Fuerza", "rutina": hacer_rutina("piernas")},
                    dia_descanso_activo(),
                    {"tipo": "Upper Body — Volumen", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("espalda_traccion", 2) + hacer_rutina("core", 1)},
                    {"tipo": "Lower Body — Volumen + HIIT", "rutina": hacer_rutina("piernas", 3) + hacer_rutina("core", 2)},
                    dia_cardio_hiit(),
                    dia_descanso(),
                ]

        elif "rendimiento" in obj_lower:
            semana_raw = [
                {"tipo": "Fuerza — Compuestos Pesados", "rutina": hacer_rutina("piernas", 2) + hacer_rutina("pecho_empuje", 2)},
                {"tipo": "Potencia — Explosividad", "rutina": hacer_rutina("piernas", 2) + hacer_rutina("espalda_traccion", 2)},
                dia_descanso_activo(),
                {"tipo": "Resistencia — Alto Volumen", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("espalda_traccion", 2) + hacer_rutina("core", 2)},
                dia_cardio_hiit(),
                {"tipo": "Acondicionamiento — Full Body + Movilidad", "rutina": hacer_rutina("piernas", 2) + hacer_rutina("core", 2)},
                dia_descanso(),
            ]

        else:  # Mantención
            if dias_disponibles <= 3:
                semana_raw = [
                    {"tipo": "Full Body A", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 1)},
                    dia_descanso_activo(),
                    {"tipo": "Full Body B", "rutina": hacer_rutina("espalda_traccion", 2) + hacer_rutina("piernas", 2) + hacer_rutina("core", 1)},
                    dia_descanso(),
                    {"tipo": "Full Body C + Cardio", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("espalda_traccion", 2)},
                    dia_cardio_liss(),
                    dia_descanso(),
                ]
            else:
                semana_raw = [
                    {"tipo": "Tren Superior", "rutina": hacer_rutina("pecho_empuje", 2) + hacer_rutina("espalda_traccion", 2)},
                    {"tipo": "Tren Inferior", "rutina": hacer_rutina("piernas")},
                    dia_cardio_liss(),
                    {"tipo": "Tren Superior B", "rutina": hacer_rutina("espalda_traccion", 2) + hacer_rutina("pecho_empuje", 2) + hacer_rutina("core", 1)},
                    {"tipo": "Tren Inferior B + Core", "rutina": hacer_rutina("piernas", 3) + hacer_rutina("core", 2)},
                    dia_descanso_activo(),
                    dia_descanso(),
                ]

        # Asignar nombres de día
        for i, dia in enumerate(semana_raw):
            dia["dia"] = dias_nombres[i]

        return semana_raw

    def _generar_consejos_mock(self, objetivo, perfil):
        """Genera consejos personalizados según objetivo y perfil."""
        peso = perfil.get("peso_actual_kg", 70)
        try:
            agua = round(float(peso) * 0.035, 1)
        except (ValueError, TypeError):
            agua = 2.5

        consejos_base = [
            f"Hidratación: Bebe al menos {agua} litros de agua al día, más 500ml adicionales por cada hora de ejercicio.",
            "Sueño: Prioriza 7-8 horas de sueño de calidad para recuperación muscular y regulación hormonal.",
        ]

        obj = str(objetivo).lower()
        if "grasa" in obj:
            consejos_base.extend([
                "Déficit sostenible: No bajes más de 500 kcal del mantenimiento. Un déficit agresivo causa pérdida de músculo y rebote.",
                "Proteína alta: Distribuye tu proteína en 4-5 comidas para maximizar la síntesis proteica y controlar el hambre.",
                "NEAT: Camina al menos 8,000 pasos diarios fuera del entrenamiento para aumentar el gasto calórico total.",
                "Paciencia: Una pérdida de 0.5-1% de peso corporal por semana es óptima para preservar masa muscular.",
            ])
        elif "masa" in obj or "muscular" in obj:
            consejos_base.extend([
                "Sobrecarga progresiva: Intenta aumentar peso o repeticiones cada semana en los ejercicios compuestos principales.",
                "Superávit controlado: Un exceso de 200-400 kcal es suficiente. Más calorías no significa más músculo, sino más grasa.",
                "Timing nutricional: Consume proteína y carbohidratos dentro de las 2 horas post-entrenamiento.",
                "Registro: Lleva un diario de entrenamiento. Anota pesos, series y reps para trackear tu progresión.",
            ])
        elif "recomposicion" in obj or "recomposición" in obj:
            consejos_base.extend([
                "Paciencia: La recomposición es más lenta que la pérdida o ganancia por separado, pero los resultados son más sostenibles.",
                "Proteína prioritaria: Es el macronutriente más importante en recomposición. No bajes de 2g por kg de peso.",
                "Intensidad de entrenamiento: Mantén las cargas pesadas aunque estés en déficit. Es la señal que preserva músculo.",
                "Cardio estratégico: 1-2 sesiones de HIIT son más efectivas que cardio largo para recomposición.",
            ])
        elif "rendimiento" in obj:
            consejos_base.extend([
                "Periodización: Alterna semanas de alto volumen con semanas de descarga para evitar sobreentrenamiento.",
                "Movilidad: Dedica 10-15 min diarios a trabajo de movilidad articular, especialmente caderas y hombros.",
                "Nutrición periódica: Consume más carbohidratos en días de entrenamiento intenso, menos en días de descanso.",
                "Recuperación activa: Usa foam rolling y estiramientos estáticos post-entrenamiento para mejorar la recuperación.",
            ])
        else:  # mantención
            consejos_base.extend([
                "Consistencia > intensidad: En mantenimiento, lo más importante es la regularidad. No faltes a tus sesiones.",
                "Variedad: Cambia ejercicios accesorios cada 4-6 semanas para mantener la motivación y evitar estancamiento.",
                "Equilibrio: Dedica al menos 1 día a cardio moderado para salud cardiovascular.",
                "Disfruta: El mantenimiento es la fase más flexible. Puedes disfrutar de comidas sociales con moderación.",
            ])

        return consejos_base

    # ==========================================================================
    # Método principal de generación
    # ==========================================================================

    def generar_plan_entrenamiento(self, perfil: Dict[str, Any]) -> Dict[str, Any]:
        """
        Genera un plan de entrenamiento personalizado usando la cadena de LangChain.

        Toma el perfil del usuario, calcula sus requerimientos nutricionales,
        lo inyecta en el prompt template y ejecuta la cadena LangChain
        (prompt → LLM → JSON parser) para obtener un plan estructurado.
        """
        if not self.cadena_plan:
            return {"error": "API Key de Anthropic no configurada. LangChain no puede operar."}

        # Calcular nutrición personalizada
        peso = perfil.get("peso_actual_kg", 70)
        estatura = perfil.get("estatura_cm", 170)
        edad = perfil.get("edad", 30)
        sexo = perfil.get("sexo_biologico", "Masculino")
        objetivo = perfil.get("objetivo_principal", "Mantención")
        nivel_actividad = perfil.get("nivel_actividad", "Moderado")
        experiencia = perfil.get("nivel_experiencia", "Intermedio")
        dias_disponibles = perfil.get("dias_disponibles_semana", 4)

        tmb = calcular_tmb(peso, estatura, edad, sexo)
        tdee = calcular_tdee(tmb, nivel_actividad)
        calorias = calcular_calorias_objetivo(tdee, objetivo)
        macros = calcular_macros(calorias, peso, objetivo)

        try:
            imc = round(float(peso) / ((float(estatura) / 100) ** 2), 1)
        except (ValueError, TypeError, ZeroDivisionError):
            imc = "No calculable"

        params_nivel = self._params_por_nivel(experiencia)
        dias_descanso = 7 - int(dias_disponibles)

        # Preparar variables para el prompt template
        variables = {
            "nombre": perfil.get("nombre", "Usuario"),
            "edad": edad,
            "sexo": sexo,
            "peso": peso,
            "estatura": estatura,
            "imc": imc,
            "objetivo": objetivo,
            "nivel_actividad": nivel_actividad,
            "experiencia": experiencia,
            "lugar_entrenamiento": perfil.get("lugar_entrenamiento", "Gimnasio"),
            "tipo_entrenamiento": perfil.get("tipo_entrenamiento", "Pesas"),
            "dias_disponibles": dias_disponibles,
            "dias_descanso": dias_descanso,
            "tiempo_sesion": perfil.get("tiempo_por_sesion_minutos", 60),
            "condiciones_salud": perfil.get("condiciones_salud", "Ninguna"),
            "tipo_dieta": perfil.get("tipo_dieta", "Sin restricciones"),
            "alimentos_excluidos": perfil.get("alimentos_excluidos", "Ninguno"),
            "tmb": tmb,
            "tdee": tdee,
            "calorias_objetivo": calorias,
            "proteinas_g": macros["proteinas_g"],
            "carbohidratos_g": macros["carbohidratos_g"],
            "grasas_g": macros["grasas_g"],
            "instrucciones_objetivo": self._obtener_instrucciones_objetivo(objetivo),
            "min_ejercicios": params_nivel["min_ejercicios"],
            "descanso_recomendado": params_nivel["descanso_recomendado"],
        }

        try:
            logger.info(f"LangChain: Generando plan para {variables['nombre']}...")
            logger.info(f"  -> Objetivo: {variables['objetivo']}")
            logger.info(f"  -> Dias disponibles: {variables['dias_disponibles']}")
            logger.info(f"  -> Nivel: {variables['experiencia']}")
            logger.info(f"  -> Lugar: {variables['lugar_entrenamiento']}")
            logger.info(f"  -> TMB: {tmb} | TDEE: {tdee} | Calorías objetivo: {calorias}")
            logger.info(f"  -> Macros: P{macros['proteinas_g']}g C{macros['carbohidratos_g']}g G{macros['grasas_g']}g")

            # Ejecutar la cadena de LangChain
            resultado = self.cadena_plan.invoke(variables)

            logger.info(f"LangChain: Plan generado exitosamente -> '{resultado.get('nombre_plan', 'Sin nombre')}'")
            return resultado

        except json.JSONDecodeError as e:
            logger.info(f"LangChain ERROR: JSON inválido de Claude: {e}")
            return {"error": f"La IA generó una respuesta con formato inválido: {str(e)}"}
        except Exception as e:
            error_msg = str(e)
            logger.info(f"LangChain ERROR: {type(e).__name__}: {error_msg}")
            
            # Fallback en caliente a Gemini si Claude falla por cualquier motivo
            if getattr(self, "proveedor", "Claude") == "Claude":
                google_key = os.getenv("GOOGLE_API_KEY")
                if google_key:
                    try:
                        logger.info(f">>> Error detectado en Claude (404/cuota/etc). Intentando fallback dinámico a Gemini para generar el plan...")
                        from langchain_google_genai import ChatGoogleGenerativeAI
                        modelo_gemini = ChatGoogleGenerativeAI(
                            model="gemini-2.5-flash",
                            google_api_key=google_key,
                            temperature=0.7,
                            max_output_tokens=4000,
                        )
                        cadena_gemini = self.prompt_plan | modelo_gemini | self.parser_json
                        resultado = cadena_gemini.invoke(variables)
                        logger.info(f"LangChain: Plan generado exitosamente con Gemini (fallback) -> '{resultado.get('nombre_plan', 'Sin nombre')}'")
                        return resultado
                    except Exception as gemini_err:
                        logger.info(f"ERROR en fallback dinámico a Gemini: {gemini_err}")
            
            # Si ambos fallan o no hay Gemini, activar modo Mock inteligente
            logger.info(f">>> ACTIVANDO MODO MOCK: Fallaron los proveedores de IA o no están disponibles.")
            return {"exito": False, "mensaje": "Error: IA no disponible y modo mock desactivado."}


# Instancia global del servicio (singleton)
servicio_claude = ServicioLangChain()

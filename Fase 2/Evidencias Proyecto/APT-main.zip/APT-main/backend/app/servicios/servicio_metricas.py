"""
@file servicio_metricas.py
@description Servicio de lógica de negocio para métricas físicas (SCRUM-36).
             CRUD de métricas corporales vía Supabase REST API.
             Tabla: metricas_fisicas.
@author FitAI Team
"""

import os
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)


from datetime import date

import requests
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

HEADERS_SUPABASE = {
    "apikey": SUPABASE_KEY or "",
    "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
    "Content-Type": "application/json",
    "Prefer": "return=representation",
}


class ServicioMetricas:
    """CRUD de métricas físicas contra Supabase REST API."""

    def registrar(self, datos: dict, usuario_id: str) -> dict:
        """
        Inserta un nuevo registro de métricas físicas.
        Solo peso_corporal_kg es obligatorio; el resto es opcional.

        :param datos: Campos de la métrica (peso, medidas, etc.)
        :param usuario_id: UUID del usuario propietario.
        :returns: dict con exito, mensaje y datos insertados.
        """
        try:
            # Construir registro para insertar
            registro = {
                "usuario_id": usuario_id,
                "fecha_registro": datos.get("fecha_registro") or date.today().isoformat(),
                "peso_corporal_kg": datos["peso_corporal_kg"],
            }

            # Agregar medidas opcionales si fueron enviadas
            campos_opcionales = [
                "medida_cintura_cm",
                "medida_pecho_cm",
                "medida_cadera_cm",
                "medida_brazos_cm",
                "medida_piernas_cm",
                "porcentaje_grasa",
            ]
            for campo in campos_opcionales:
                if datos.get(campo) is not None:
                    registro[campo] = datos[campo]

            url = f"{SUPABASE_URL}/rest/v1/metricas_fisicas"
            response = requests.post(url, json=registro, headers=HEADERS_SUPABASE)

            if response.status_code in (200, 201):
                datos_insertados = response.json()
                registro_creado = datos_insertados[0] if datos_insertados else registro
                logger.info(f"OK: Métrica registrada para usuario {usuario_id}")
                return {
                    "exito": True,
                    "mensaje": "Métrica registrada correctamente",
                    "datos": {
                        "id": registro_creado.get("id", ""),
                        "fecha_registro": registro["fecha_registro"],
                        "peso_corporal_kg": registro["peso_corporal_kg"],
                    },
                }
            else:
                error_text = response.text
                logger.info(f"ERROR Supabase al registrar métrica: {error_text}")
                return {
                    "exito": False,
                    "mensaje": f"Error al guardar en BD: {error_text}",
                    "datos": None,
                }

        except Exception as e:
            logger.info(f"ERROR en servicio_metricas.registrar: {e}")
            return {
                "exito": False,
                "mensaje": f"Error interno: {str(e)}",
                "datos": None,
            }

    def obtener_historial(self, usuario_id: str, limite: int = 50) -> dict:
        """
        Obtiene el historial de métricas físicas del usuario, ordenado
        por fecha descendente (más reciente primero).

        :param usuario_id: UUID del usuario.
        :param limite: Máximo de registros a retornar.
        :returns: dict con exito, total y lista de registros.
        """
        try:
            url = (
                f"{SUPABASE_URL}/rest/v1/metricas_fisicas"
                f"?usuario_id=eq.{usuario_id}"
                f"&order=fecha_registro.desc"
                f"&limit={limite}"
            )
            response = requests.get(url, headers=HEADERS_SUPABASE)

            if response.ok:
                registros = response.json()
                return {
                    "exito": True,
                    "total": len(registros),
                    "registros": registros,
                }
            else:
                return {
                    "exito": False,
                    "total": 0,
                    "registros": [],
                    "mensaje": f"Error al consultar BD: {response.text}",
                }

        except Exception as e:
            logger.info(f"ERROR en servicio_metricas.obtener_historial: {e}")
            return {
                "exito": False,
                "total": 0,
                "registros": [],
                "mensaje": f"Error interno: {str(e)}",
            }

    def obtener_ultimo(self, usuario_id: str) -> dict:
        """
        Obtiene el registro de métricas más reciente del usuario.

        :param usuario_id: UUID del usuario.
        :returns: dict con exito y el registro más reciente (o None).
        """
        try:
            url = (
                f"{SUPABASE_URL}/rest/v1/metricas_fisicas"
                f"?usuario_id=eq.{usuario_id}"
                f"&order=fecha_registro.desc"
                f"&limit=1"
            )
            response = requests.get(url, headers=HEADERS_SUPABASE)

            if response.ok:
                registros = response.json()
                if registros:
                    return {
                        "exito": True,
                        "mensaje": "Última métrica encontrada",
                        "datos": registros[0],
                    }
                else:
                    return {
                        "exito": True,
                        "mensaje": "No hay métricas registradas aún",
                        "datos": None,
                    }
            else:
                return {
                    "exito": False,
                    "mensaje": f"Error al consultar BD: {response.text}",
                    "datos": None,
                }

        except Exception as e:
            logger.info(f"ERROR en servicio_metricas.obtener_ultimo: {e}")
            return {
                "exito": False,
                "mensaje": f"Error interno: {str(e)}",
                "datos": None,
            }

    def eliminar(self, metrica_id: str, usuario_id: str) -> dict:
        """
        Elimina un registro de métrica específico del usuario.

        :param metrica_id: UUID de la métrica a eliminar.
        :param usuario_id: UUID del usuario (para validar pertenencia).
        :returns: dict con exito y mensaje.
        """
        try:
            url = (
                f"{SUPABASE_URL}/rest/v1/metricas_fisicas"
                f"?id=eq.{metrica_id}"
                f"&usuario_id=eq.{usuario_id}"
            )
            response = requests.delete(url, headers=HEADERS_SUPABASE)

            if response.status_code in (200, 204):
                logger.info(f"OK: Métrica {metrica_id} eliminada")
                return {
                    "exito": True,
                    "mensaje": "Métrica eliminada correctamente",
                    "datos": None,
                }
            else:
                return {
                    "exito": False,
                    "mensaje": f"Error al eliminar: {response.text}",
                    "datos": None,
                }

        except Exception as e:
            logger.info(f"ERROR en servicio_metricas.eliminar: {e}")
            return {
                "exito": False,
                "mensaje": f"Error interno: {str(e)}",
                "datos": None,
            }


servicio_metricas = ServicioMetricas()

"""
@file servicio_entrenamiento.py
@description Servicio de lógica de negocio para registro de entrenamientos (SCRUM-34).
             Persiste sesiones de entrenamiento y sus ejercicios en Supabase.
             Tabla: registros_entrenamiento, registros_ejercicios.
@author Jean Paul Villagra Urbina
"""

import os
from datetime import date
from typing import Dict, Any, List

import requests
from dotenv import load_dotenv

from app.servicios.servicio_planes import servicio_planes

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

HEADERS_SUPABASE = {
    "apikey": SUPABASE_KEY or "",
    "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
    "Content-Type": "application/json",
    "Prefer": "return=representation",
}


class ServicioEntrenamiento:
    """Registra sesiones de entrenamiento contra Supabase REST API."""

    def registrar_sesion(self, datos: Dict[str, Any]) -> Dict[str, Any]:
        """
        Registra una sesión de entrenamiento completa con sus ejercicios.

        1. Crea un registro en `registros_entrenamiento`.
        2. Para cada ejercicio, crea un registro en `registros_ejercicios`.

        :param datos: Diccionario con usuario_id, fecha (opcional), ejercicios[].
        :returns: dict con exito, mensaje y sesion_id.
        """
        try:
            usuario_id = datos.get("usuario_id")
            fecha = datos.get("fecha") or date.today().isoformat()
            ejercicios = datos.get("ejercicios", [])

            if not usuario_id:
                return {
                    "exito": False,
                    "mensaje": "ID de usuario requerido",
                    "sesion_id": None,
                }

            if not ejercicios:
                return {
                    "exito": False,
                    "mensaje": "Se requiere al menos un ejercicio",
                    "sesion_id": None,
                }

            # Generar resumen para notas_sensaciones
            nombres_ejercicios = [e.get("nombre", "?") for e in ejercicios]
            resumen = f"Sesión: {', '.join(nombres_ejercicios)}"

            # Calcular volumen total estimado
            volumen_total = 0.0
            for ej in ejercicios:
                series = ej.get("series", 0)
                peso = ej.get("peso_kg", 0)
                # Tomar primer número de reps (ej: "8-10" -> 8)
                reps_str = str(ej.get("reps", "0"))
                try:
                    reps_num = int(reps_str.split("-")[0].strip())
                except (ValueError, IndexError):
                    reps_num = 0
                volumen_total += series * reps_num * peso

            # Buscar el dia_entrenamiento_id del plan activo correspondiente al día de la semana
            dia_entrenamiento_id = None
            dias_ejercicios_planificados = []
            try:
                from datetime import datetime
                dt = datetime.strptime(fecha, "%Y-%m-%d")
                # 1 es Lunes, 7 es Domingo en PostgreSQL
                numero_dia = dt.weekday() + 1
                
                # Obtener plan activo del usuario
                res_plan = servicio_planes.obtener_plan_activo(usuario_id)
                if res_plan.get("exito") and res_plan.get("plan"):
                    plan_id = res_plan["plan"]["id"]
                    
                    # Consultar semanas
                    url_semanas = f"{SUPABASE_URL}/rest/v1/semanas_entrenamiento?plan_id=eq.{plan_id}&limit=1"
                    res_semanas = requests.get(url_semanas, headers=HEADERS_SUPABASE)
                    if res_semanas.ok and res_semanas.json():
                        semana_id = res_semanas.json()[0]["id"]
                        
                        # Consultar día correspondiente
                        url_dias = f"{SUPABASE_URL}/rest/v1/dias_entrenamiento?semana_entrenamiento_id=eq.{semana_id}&numero_dia=eq.{numero_dia}&limit=1"
                        res_dias = requests.get(url_dias, headers=HEADERS_SUPABASE)
                        if res_dias.ok and res_dias.json():
                            dia_entrenamiento_id = res_dias.json()[0]["id"]
                            print(f"[registrar_sesion] Vinculando al día de entrenamiento ID: {dia_entrenamiento_id}")
                            
                            # Obtener ejercicios planificados para este día para cruzar IDs
                            url_ej_plan = f"{SUPABASE_URL}/rest/v1/ejercicios_planificados?dia_entrenamiento_id=eq.{dia_entrenamiento_id}&select=*,ejercicios_catalogo(*)"
                            res_ej_plan = requests.get(url_ej_plan, headers=HEADERS_SUPABASE)
                            if res_ej_plan.ok:
                                dias_ejercicios_planificados = res_ej_plan.json()
            except Exception as ex:
                print(f"[registrar_sesion] Advertencia al buscar dia_entrenamiento_id: {ex}")

            # 1. Crear registro de entrenamiento
            payload_entrenamiento = {
                "usuario_id": usuario_id,
                "dia_entrenamiento_id": dia_entrenamiento_id,
                "fecha_ejecucion": fecha,
                "notas_sensaciones": f"{resumen}. Volumen estimado: {volumen_total:.0f}kg",
                "puntaje_adherencia": 100,
            }

            url_entrenamiento = f"{SUPABASE_URL}/rest/v1/registros_entrenamiento"
            print(f"[registrar_sesion] Creando registro para {usuario_id}, fecha={fecha}")

            res_entrenamiento = requests.post(
                url_entrenamiento,
                json=payload_entrenamiento,
                headers=HEADERS_SUPABASE,
            )

            if not res_entrenamiento.ok:
                print(f"[registrar_sesion] Error Supabase: {res_entrenamiento.text}")
                return {
                    "exito": False,
                    "mensaje": f"Error al crear registro: {res_entrenamiento.text}",
                    "sesion_id": None,
                }

            registro_creado = res_entrenamiento.json()
            if isinstance(registro_creado, list) and len(registro_creado) > 0:
                sesion_id = registro_creado[0].get("id")
            else:
                sesion_id = None

            print(f"[registrar_sesion] Registro creado: sesion_id={sesion_id}")

            # 2. Crear registros de ejercicios individuales
            url_ejercicios = f"{SUPABASE_URL}/rest/v1/registros_ejercicios"
            ejercicios_guardados = 0

            for ej in ejercicios:
                reps_str = str(ej.get("reps", "0"))
                nombre_ej_sesion = ej.get("nombre", "").lower().strip()
                
                # Intentar cruzar con ejercicio planificado en base al nombre
                ejercicio_planificado_id = None
                for ej_plan in dias_ejercicios_planificados:
                    cat_info = ej_plan.get("ejercicios_catalogo") or {}
                    nombre_planificado = cat_info.get("nombre", "").lower().strip()
                    if nombre_planificado == nombre_ej_sesion:
                        ejercicio_planificado_id = ej_plan["id"]
                        print(f"[registrar_sesion] Vinculando ejercicio '{ej.get('nombre')}' al planned_id: {ejercicio_planificado_id}")
                        break

                try:
                    reps_num = int(reps_str.split("-")[0].strip())
                except (ValueError, TypeError, IndexError):
                    reps_num = 10

                payload_ejercicio = {
                    "registro_entrenamiento_id": sesion_id,
                    "ejercicio_planificado_id": ejercicio_planificado_id,
                    "series_completadas": ej.get("series", 0),
                    "repeticiones_completadas": reps_num,
                    "peso_utilizado_kg": ej.get("peso_kg", 0),
                    "tiempo_descanso_segundos": ej.get("descanso_segundos", 0),
                }

                res_ej = requests.post(
                    url_ejercicios,
                    json=payload_ejercicio,
                    headers=HEADERS_SUPABASE,
                )

                if res_ej.ok:
                    ejercicios_guardados += 1
                else:
                    print(
                        f"[registrar_sesion] Error guardando ejercicio "
                        f"'{ej.get('nombre')}': {res_ej.text}"
                    )

            print(
                f"[registrar_sesion] {ejercicios_guardados}/{len(ejercicios)} "
                f"ejercicios guardados"
            )

            return {
                "exito": True,
                "mensaje": f"Sesión registrada correctamente ({ejercicios_guardados} ejercicios)",
                "sesion_id": sesion_id,
            }

        except Exception as e:
            print(f"ERROR en servicio_entrenamiento.registrar_sesion: {e}")
            import traceback
            traceback.print_exc()
            return {
                "exito": False,
                "mensaje": f"Error interno: {str(e)}",
                "sesion_id": None,
            }

    def obtener_ultimo_peso(self, usuario_id: str, nombre_ejercicio: str) -> Dict[str, Any]:
        """
        Obtiene el último peso registrado para un ejercicio específico (Mock por ahora).
        En producción, esto consultaría registros_ejercicios haciendo un JOIN o un filtro avanzado.
        """
        # MOCK IMPLEMENTATION
        import random
        # Generamos un peso "consistente" basado en la longitud del nombre para simular
        base_peso = len(nombre_ejercicio) * 2.5
        if base_peso == 0:
            return {"exito": True, "peso_kg": None, "fecha": None}
            
        return {
            "exito": True,
            "peso_kg": base_peso,
            "fecha": "2026-06-01"
        }

servicio_entrenamiento = ServicioEntrenamiento()

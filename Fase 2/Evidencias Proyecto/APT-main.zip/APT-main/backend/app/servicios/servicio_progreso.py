"""
@file servicio_progreso.py
@description Servicio de lógica de negocio para el módulo de progreso (SCRUM-12).
             Genera datos mock realistas y heurísticas de insights mientras no haya
             registros reales en la BD. Cuando los haya, se reemplaza la fuente de datos.
@author FitAI Team
"""

import os
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)


import random
from datetime import datetime, timedelta
from typing import List, Optional

import requests
from dotenv import load_dotenv

from app.servicios.servicio_claude import servicio_claude
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

HEADERS_SUPABASE = {
    "apikey": SUPABASE_KEY or "",
    "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
    "Content-Type": "application/json",
}


def _calcular_metricas(entrenamientos: list, periodo: str) -> list:
    """Calcula métricas agregadas a partir de los entrenamientos."""
    total_sesiones = len(entrenamientos)
    volumen_total = sum(e["volumen_total_kg"] for e in entrenamientos)
    duracion_promedio = (
        round(sum(e["duracion_minutos"] for e in entrenamientos) / total_sesiones)
        if total_sesiones > 0
        else 0
    )
    adherencia_promedio = (
        round(sum(e.get("puntaje_adherencia", 80) for e in entrenamientos) / total_sesiones)
        if total_sesiones > 0
        else 0
    )

    # Calcular racha (días consecutivos — simulado)
    racha = random.randint(3, 12)

    metricas = [
        {
            "etiqueta": "Sesiones",
            "valor": str(total_sesiones),
            "unidad": "entrenamientos",
            "tendencia": "mejora" if total_sesiones >= 4 else "estable",
            "cambio_porcentual": round(random.uniform(5, 20), 1),
        },
        {
            "etiqueta": "Volumen Total",
            "valor": f"{volumen_total:,.0f}",
            "unidad": "kg",
            "tendencia": "mejora",
            "cambio_porcentual": round(random.uniform(3, 15), 1),
        },
        {
            "etiqueta": "Racha",
            "valor": str(racha),
            "unidad": "días",
            "tendencia": "mejora" if racha >= 5 else "estable",
            "cambio_porcentual": None,
        },
    ]

    return metricas


def _generar_grafico_actividad(entrenamientos: list, periodo: str) -> list:
    """Genera datos para el gráfico de barras según el período."""
    if periodo == "dia":
        # Horas del día
        return [
            {"etiqueta": f"{h}:00", "valor": random.choice([0, 0, 1, 0])}
            for h in range(6, 23, 2)
        ]
    elif periodo == "semana":
        dias = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
        actividad = [0] * 7
        for e in entrenamientos:
            try:
                fecha = datetime.strptime(e["fecha"], "%Y-%m-%d")
                idx = fecha.weekday()
                actividad[idx] += 1
            except (ValueError, IndexError):
                pass
        # Si no hay datos reales, generar patrón realista
        
        return [{"etiqueta": d, "valor": v} for d, v in zip(dias, actividad)]
    else:
        # Semanas del mes
        semanas = ["Sem 1", "Sem 2", "Sem 3", "Sem 4"]
        return [
            {"etiqueta": s, "valor": random.randint(3, 5)}
            for s in semanas
        ]


def _generar_insights(entrenamientos: list, perfil: dict = None) -> list:
    """
    Genera insights heurísticos basados en el historial.
    Cuando Claude esté integrado, esta función delegará a la IA.
    """
    insights = []
    total_sesiones = len(entrenamientos)
    objetivo = perfil.get("objetivo_principal", "Ganar masa muscular") if perfil else "Ganar masa muscular"

    # Insight 1: Frecuencia
    if total_sesiones >= 4:
        insights.append({
            "tipo": "logro",
            "icono": "trophy",
            "titulo": "¡Gran consistencia!",
            "descripcion": f"Has completado {total_sesiones} sesiones. Mantener una frecuencia alta es clave para {objetivo.lower()}.",
            "prioridad": 1,
        })
    elif total_sesiones >= 2:
        insights.append({
            "tipo": "recomendacion",
            "icono": "calendar-outline",
            "titulo": "Aumenta tu frecuencia",
            "descripcion": "Intenta agregar 1-2 sesiones más por semana para acelerar tus resultados.",
            "prioridad": 1,
        })
    else:
        insights.append({
            "tipo": "alerta",
            "icono": "alert-circle-outline",
            "titulo": "Baja actividad detectada",
            "descripcion": "Tu frecuencia de entrenamiento ha bajado. Recuerda que la consistencia es más importante que la intensidad.",
            "prioridad": 1,
        })

    # Insight 2: Volumen
    volumen_promedio = (
        sum(e["volumen_total_kg"] for e in entrenamientos) / total_sesiones
        if total_sesiones > 0
        else 0
    )
    if volumen_promedio > 3000:
        insights.append({
            "tipo": "logro",
            "icono": "barbell-outline",
            "titulo": "Volumen excelente",
            "descripcion": f"Tu volumen promedio es de {volumen_promedio:,.0f} kg por sesión. Estás en buen camino.",
            "prioridad": 2,
        })
    elif volumen_promedio > 0:
        insights.append({
            "tipo": "recomendacion",
            "icono": "trending-up-outline",
            "titulo": "Progresión de cargas",
            "descripcion": "Intenta aumentar el peso un 2-5% cuando logres completar todas las repeticiones cómodamente.",
            "prioridad": 2,
        })

    # Insight 3: Variedad
    grupos_entrenados = set(e["grupo_muscular"] for e in entrenamientos)
    if len(grupos_entrenados) < 3 and total_sesiones >= 3:
        insights.append({
            "tipo": "recomendacion",
            "icono": "shuffle-outline",
            "titulo": "Varía tus entrenamientos",
            "descripcion": "Estás enfocándote en pocos grupos musculares. Agregar variedad previene desbalances y estancamientos.",
            "prioridad": 2,
        })

    # Insight 4: Basado en objetivo
    if "masa muscular" in objetivo.lower() or "ganar" in objetivo.lower():
        insights.append({
            "tipo": "recomendacion",
            "icono": "nutrition-outline",
            "titulo": "Nutrición para hipertrofia",
            "descripcion": "Asegúrate de consumir 1.6-2.2g de proteína por kg de peso corporal para maximizar la ganancia muscular.",
            "prioridad": 3,
        })
    elif "grasa" in objetivo.lower() or "bajar" in objetivo.lower():
        insights.append({
            "tipo": "recomendacion",
            "icono": "flame-outline",
            "titulo": "Déficit calórico",
            "descripcion": "Combina tu entrenamiento con un déficit calórico moderado (300-500 kcal) para perder grasa sin perder músculo.",
            "prioridad": 3,
        })

    # Ordenar por prioridad
    insights.sort(key=lambda x: x["prioridad"])
    return insights


class ServicioProgreso:
    """Servicio de lógica de negocio para el módulo de progreso."""

    def obtener_perfil_usuario(self, usuario_id: str) -> dict:
        """Obtiene el perfil del usuario desde Supabase."""
        try:
            url = f"{SUPABASE_URL}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario_id}"
            response = requests.get(url, headers=HEADERS_SUPABASE)
            if response.ok and response.json():
                return response.json()[0]
        except Exception as e:
            logger.info(f"Error obteniendo perfil: {e}")
        return {}

    def obtener_resumen(self, usuario_id: str, periodo: str = "semana") -> dict:
        """
        Obtiene el resumen de progreso del usuario.
        Consulta datos reales en Supabase. Si no hay, retorna valores en cero con logros bloqueados.
        """
        try:
            # 1. Intentar obtener entrenamientos reales de Supabase
            url = f"{SUPABASE_URL}/rest/v1/registros_entrenamiento?usuario_id=eq.{usuario_id}"
            response = requests.get(url, headers=HEADERS_SUPABASE)
            
            entrenamientos_reales = []
            if response.ok:
                entrenamientos_reales = response.json()
            
            total_sesiones = len(entrenamientos_reales)
            
            logros = [
                {
                    "id": "primer_paso",
                    "nombre": "Primer Paso",
                    "descripcion": "Registra tu primer entrenamiento en la app.",
                    "desbloqueado": total_sesiones >= 1,
                    "tipo": "bronce",
                    "icono": "flame"
                },
                {
                    "id": "consistencia",
                    "nombre": "Consistencia",
                    "descripcion": "Completa 3 entrenamientos en total.",
                    "desbloqueado": total_sesiones >= 3,
                    "tipo": "plata",
                    "icono": "fitness"
                },
                {
                    "id": "imparable",
                    "nombre": "Imparable",
                    "descripcion": "Completa 5 entrenamientos en total.",
                    "desbloqueado": total_sesiones >= 5,
                    "tipo": "oro",
                    "icono": "trophy"
                }
            ]
            
            # 2. Si no hay datos reales, devolver estado inicial vacío
            if not entrenamientos_reales:
                logger.info(f"Progreso: Usuario {usuario_id} no tiene registros reales. Devolviendo ceros.")
                return {
                    "exito": True,
                    "periodo": periodo,
                    "metricas": [
                        {"etiqueta": "Sesiones", "valor": "0", "unidad": "sesiones", "tendencia": "estable", "cambio_porcentual": 0.0},
                        {"etiqueta": "Volumen Total", "valor": "0", "unidad": "kg", "tendencia": "estable", "cambio_porcentual": 0.0},
                        {"etiqueta": "Racha", "valor": "0", "unidad": "días", "tendencia": "estable", "cambio_porcentual": 0.0},
                    ],
                    "grafico_actividad": [],
                    "ejercicios_destacados": [],
                    "logros": logros,
                    "mensaje": "Aún no tienes entrenamientos registrados. ¡Comienza hoy!"
                }

            # 3. Si hay datos reales, calcular métricas reales de volumen y racha
            volumen_total = 0.0
            sesion_ids = [e["id"] for e in entrenamientos_reales]
            if sesion_ids:
                ids_str = ",".join(f"{sid}" for sid in sesion_ids)
                url_ej = f"{SUPABASE_URL}/rest/v1/registros_ejercicios?registro_entrenamiento_id=in.({ids_str})"
                res_ej = requests.get(url_ej, headers=HEADERS_SUPABASE)
                if res_ej.ok:
                    registros_ej = res_ej.json()
                    for re in registros_ej:
                        series = re.get("series_completadas") or 0
                        peso = float(re.get("peso_utilizado_kg") or 0.0)
                        reps_val = re.get("repeticiones_completadas") or 0
                        try:
                            reps = int(reps_val)
                        except (ValueError, TypeError):
                            try:
                                reps = int(str(reps_val).split("-")[0].strip())
                            except Exception:
                                reps = 0
                        volumen_total += series * reps * peso

            # Calcular racha (simulada basada en entrenamientos reales)
            racha = min(total_sesiones * 2, 10)  # Simulado proporcional para la demo

            metricas = [
                {
                    "etiqueta": "Sesiones",
                    "valor": str(total_sesiones),
                    "unidad": "entrenamientos",
                    "tendencia": "mejora" if total_sesiones >= 3 else "estable",
                    "cambio_porcentual": 15.0 if total_sesiones >= 2 else 0.0,
                },
                {
                    "etiqueta": "Volumen Total",
                    "valor": f"{volumen_total:,.0f}",
                    "unidad": "kg",
                    "tendencia": "mejora" if volumen_total > 0 else "estable",
                    "cambio_porcentual": 10.0 if volumen_total > 0 else 0.0,
                },
                {
                    "etiqueta": "Racha",
                    "valor": str(racha),
                    "unidad": "días",
                    "tendencia": "mejora" if racha >= 3 else "estable",
                    "cambio_porcentual": None,
                },
            ]

            # Generar gráfico de actividad real agrupado por día de la semana
            dias_nombre = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
            actividad_map = {d: 0 for d in dias_nombre}
            
            for ent in entrenamientos_reales:
                fecha_str = ent.get("fecha_ejecucion")
                if fecha_str:
                    try:
                        # Si tiene formato ISO completo o solo fecha
                        if "T" in fecha_str:
                            fecha_str = fecha_str.split("T")[0]
                        dt = datetime.strptime(fecha_str, "%Y-%m-%d")
                        nombre_dia = dias_nombre[dt.weekday()]
                        actividad_map[nombre_dia] += 1
                    except Exception as ex:
                        logger.info(f"Error parsing date {fecha_str}: {ex}")
            
            grafico = [{"etiqueta": d, "valor": float(v)} for d, v in actividad_map.items()]

            # Ejercicios destacados (obtener del catálogo real si es posible)
            ejercicios_destacados = [
                {
                    "nombre": "Press de Banca plano",
                    "grupo_muscular": "Pecho",
                    "progreso_porcentual": 5.0,
                    "estado": "mejora"
                },
                {
                    "nombre": "Sentadilla libre",
                    "grupo_muscular": "Piernas",
                    "progreso_porcentual": 8.0,
                    "estado": "mejora"
                }
            ] if total_sesiones >= 1 else []

            return {
                "exito": True,
                "periodo": periodo,
                "metricas": metricas,
                "grafico_actividad": grafico,
                "ejercicios_destacados": ejercicios_destacados,
                "logros": logros
            }
        except Exception as e:
            logger.info(f"Error en obtener_resumen: {e}")
            import traceback
            traceback.print_exc()
            return {"exito": False, "mensaje": str(e)}

    def obtener_entrenamientos(self, usuario_id: str, periodo: str = "semana") -> dict:
        """
        Obtiene el historial de entrenamientos del usuario.
        Por ahora usa datos mock.
        """
        entrenamientos = []

        return {
            "exito": True,
            "periodo": periodo,
            "total": len(entrenamientos),
            "entrenamientos": entrenamientos,
        }

    def obtener_insights(self, usuario_id: str) -> dict:
        """
        Genera insights conversacionales e inteligentes basados en el progreso real del usuario,
        utilizando LangChain (Claude/Gemini) con un prompt estructurado de análisis.
        Si la IA falla o no está disponible, cae de forma segura en las heurísticas locales.
        """
        perfil = self.obtener_perfil_usuario(usuario_id)
        # Buscar entrenamientos del último mes para el análisis
        entrenamientos = _generar_entrenamientos_mock("mes")
        
        # Intentar generar con LangChain si hay un modelo configurado
        if servicio_claude and servicio_claude.modelo:
            try:
                # 1. Resumir entrenamientos para el prompt de la IA
                total_sesiones = len(entrenamientos)
                volumen_total = sum(e["volumen_total_kg"] for e in entrenamientos)
                duracion_total = sum(e["duracion_minutos"] for e in entrenamientos)
                grupos = list(set(e["grupo_muscular"] for e in entrenamientos))
                
                # Datos de perfil resumidos
                datos_perfil = {
                    "nombre": perfil.get("nombre", "Usuario"),
                    "objetivo": perfil.get("objetivo_principal", "Ganar masa muscular"),
                    "experiencia": perfil.get("nivel_experiencia", "Principiante"),
                    "peso": perfil.get("peso_actual_kg", "No especificado"),
                }
                
                # Resumen de actividad
                resumen_actividad = {
                    "total_sesiones_mes": total_sesiones,
                    "volumen_total_kg_mes": volumen_total,
                    "duracion_total_minutos_mes": duracion_total,
                    "grupos_musculares_entrenados": grupos,
                }

                PROMPT_INSIGHTS_SISTEMA = """Eres FitAI Coach, una inteligencia artificial experta en fitness, entrenamiento de fuerza y analítica deportiva.
Tu rol es analizar el progreso de entrenamiento del usuario y generar insights motivadores, profesionales y altamente personalizados en formato JSON.

REGLAS ESTRICTAS:
1. Genera exactamente 3 insights interesantes basados en el perfil y entrenamientos del usuario.
2. Cada insight debe tener los campos: "tipo", "icono", "titulo", "descripcion" y "prioridad" (donde prioridad debe ser un número entero: 1 para alta, 2 para media, 3 para baja).
3. "tipo" debe ser uno de: "logro" (color de éxito), "recomendacion" (color info), o "alerta" (color preventivo).
4. "icono" debe ser uno de: "trophy", "calendar-outline", "alert-circle-outline", "barbell-outline", "trending-up-outline", "shuffle-outline", "flame-outline".
5. Adapta los insights a los datos provistos: si hay aumento de volumen o consistencia alta, crea un "logro"; si entrena poco o desbalanceado, crea una "recomendacion" o "alerta".
6. Responde ÚNICAMENTE con un JSON válido que sea una lista con los 3 objetos de insight, sin ningún texto adicional ni markdown.
7. Responde siempre en español.
"""
                prompt = ChatPromptTemplate.from_messages([
                    ("system", PROMPT_INSIGHTS_SISTEMA),
                    ("human", "Perfil del usuario: {perfil}\nResumen de actividad reciente del mes: {resumen_actividad}")
                ])
                
                cadena_insights = prompt | servicio_claude.modelo | JsonOutputParser()
                
                logger.info(f"[servicio_progreso.obtener_insights] Generando insights de progreso con LangChain...")
                insights_ia = cadena_insights.invoke({
                    "perfil": str(datos_perfil),
                    "resumen_actividad": str(resumen_actividad)
                })
                
                if isinstance(insights_ia, list) and len(insights_ia) > 0:
                    prioridad_map = {"alta": 1, "media": 2, "baja": 3, "high": 1, "medium": 2, "low": 3}
                    for ins in insights_ia:
                        p = ins.get("prioridad")
                        if isinstance(p, str):
                            ins["prioridad"] = prioridad_map.get(p.lower().strip(), 1)
                        elif not isinstance(p, int):
                            ins["prioridad"] = 1
                    logger.info(f"[servicio_progreso.obtener_insights] Insights generados por IA con éxito ({len(insights_ia)}).")
                    return {
                        "exito": True,
                        "insights": insights_ia,
                    }
            except Exception as e:
                logger.info(f"[servicio_progreso.obtener_insights] Advertencia al generar insights con IA: {e}. Cayendo en heurísticas locales.")

        # Fallback a heurísticas locales tradicionales si falla la IA
        logger.info(f"[servicio_progreso.obtener_insights] Usando fallback de heurísticas locales.")
        insights = _generar_insights(entrenamientos, perfil)
        return {
            "exito": True,
            "insights": insights,
        }


servicio_progreso = ServicioProgreso()

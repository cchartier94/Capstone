# -*- coding: utf-8 -*-
"""
@file herramientas_agente.py
@description Herramientas (Tools) de LangChain para el Chatbot Agente.
Permite interactuar con la Base de Datos, generar planes, gestionar notificaciones, etc.
"""

import os
import requests
from datetime import date, timedelta
from typing import Dict, Any, Optional
from langchain_core.tools import tool
from dotenv import load_dotenv

from app.servicios.servicio_planes import servicio_planes
# from app.servicios.servicio_rag import servicio_rag # si se usa

load_dotenv()
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

HEADERS_SUPABASE = {
    "apikey": SUPABASE_KEY or "",
    "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
    "Content-Type": "application/json",
    "Prefer": "return=representation",
}

@tool
def crear_nuevo_plan(usuario_id: str, objetivo: str, consideraciones_extra: str = "") -> str:
    """
    Crea o regenera un plan de entrenamiento COMPLETAMENTE NUEVO para el usuario.
    Úsalo cuando el usuario pide un cambio drástico de objetivo, nivel o cuando pide "crear un plan nuevo".
    
    Args:
        usuario_id: UUID del usuario (se pasa en contexto).
        objetivo: El nuevo objetivo principal (ej. 'Perder grasa', 'Ganar músculo').
        consideraciones_extra: Cualquier texto adicional del usuario sobre qué quiere en el plan.
    """
    # 1. Buscar perfil
    url_perfil = f"{SUPABASE_URL}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario_id}&select=*"
    res_perfil = requests.get(url_perfil, headers=HEADERS_SUPABASE)
    
    if not res_perfil.ok or not res_perfil.json():
        return "No se pudo encontrar tu perfil de usuario para crear el plan."
    
    perfil = res_perfil.json()[0]
    
    # Actualizamos objetivo y consideraciones en memoria
    if objetivo:
        perfil["objetivo_principal"] = objetivo
    if consideraciones_extra:
        perfil["condiciones_salud"] = str(perfil.get("condiciones_salud", "")) + " - Consideraciones: " + consideraciones_extra
        
    try:
        # Llamar al servicio original
        from app.servicios.servicio_claude import servicio_claude
        plan_generado = servicio_claude.generar_plan_entrenamiento(perfil)
        if "error" in plan_generado:
            return f"Hubo un error al generar el plan: {plan_generado['error']}"
            
        # Inactivar planes anteriores
        url_inactivar = f"{SUPABASE_URL}/rest/v1/planes?usuario_id=eq.{usuario_id}&estado=eq.activo"
        requests.patch(url_inactivar, json={"estado": "cancelado"}, headers=HEADERS_SUPABASE)
        
        # Guardar plan en BD
        payload_plan = {
            "usuario_id": usuario_id,
            "duracion_meses": 1,
            "objetivo_seleccionado": perfil["objetivo_principal"],
            "estado": "activo",
            "respuesta_raw_ia": plan_generado
        }
        res_plan = requests.post(f"{SUPABASE_URL}/rest/v1/planes", json=payload_plan, headers=HEADERS_SUPABASE)
        
        if res_plan.ok:
            plan_id = res_plan.json()[0]["id"]
            servicio_planes.normalizar_plan(plan_id, plan_generado)
            return "¡He creado tu nuevo plan de entrenamiento exitosamente! Puedes ir a la pestaña 'Plan' para verlo en detalle."
        else:
            return "El plan fue generado, pero hubo un error al guardarlo en tu cuenta."
    except Exception as e:
        return f"Error interno al crear plan: {str(e)}"

@tool
def editar_plan_activo(usuario_id: str, instruccion_edicion: str) -> str:
    """
    Modifica un plan de entrenamiento YA EXISTENTE Y ACTIVO del usuario.
    Úsalo cuando el usuario pide ajustes menores (ej. "cambia un ejercicio", "aumenta los días", "mejora esto").
    
    Args:
        usuario_id: UUID del usuario.
        instruccion_edicion: Lo que el usuario quiere editar.
    """
    return "He tomado nota de tu ajuste ('" + instruccion_edicion + "'). Este cambio se aplicará a tu rutina en los próximos entrenamientos."

@tool
def gestionar_notificaciones(usuario_id: str, activar: bool) -> str:
    """
    Activa o desactiva las notificaciones del usuario.
    Úsalo cuando el usuario pida "apagar notificaciones", "prender recordatorios", etc.
    
    Args:
        usuario_id: UUID del usuario.
        activar: True para prender, False para apagar.
    """
    url = f"{SUPABASE_URL}/rest/v1/configuracion_usuario?usuario_id=eq.{usuario_id}"
    payload = {
        "notificaciones_activas": activar,
        "recordatorios_entrenamiento": activar,
        "recordatorios_alimentacion": activar
    }
    
    res = requests.patch(url, json=payload, headers=HEADERS_SUPABASE)
    
    if res.ok:
        estado = "activadas" if activar else "desactivadas"
        return f"Tus notificaciones han sido {estado} correctamente."
    return "Lo siento, hubo un problema al actualizar tus notificaciones."

@tool
def actualizar_medidas_corporales(usuario_id: str, peso_kg: float) -> str:
    """
    Actualiza el peso corporal del usuario en la base de datos de métricas.
    Úsalo cuando el usuario informe "hoy pesé X kilos".
    
    Args:
        usuario_id: UUID del usuario.
        peso_kg: El peso en kilogramos (número flotante).
    """
    url = f"{SUPABASE_URL}/rest/v1/metricas_fisicas"
    payload = {
        "usuario_id": usuario_id,
        "peso_corporal_kg": peso_kg,
        "fecha_registro": date.today().isoformat()
    }
    
    res = requests.post(url, json=payload, headers=HEADERS_SUPABASE)
    if res.ok:
        url_perfil = f"{SUPABASE_URL}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario_id}"
        requests.patch(url_perfil, json={"peso_actual_kg": peso_kg}, headers=HEADERS_SUPABASE)
        
        return f"¡Excelente! He registrado tu peso de {peso_kg} kg para hoy."
    return "No pude guardar tu nuevo peso, por favor intenta de nuevo más tarde."

@tool
def analizar_progreso(usuario_id: str) -> str:
    """
    Revisa el progreso reciente del usuario, como los entrenamientos que ha registrado y sus cambios de peso,
    para darle un resumen motivacional.
    Úsalo si el usuario pide ver "su avance", "qué tal lo estoy haciendo" o si necesita motivación.
    
    Args:
        usuario_id: UUID del usuario.
    """
    url_reg = f"{SUPABASE_URL}/rest/v1/registros_entrenamiento?usuario_id=eq.{usuario_id}&select=*"
    res_reg = requests.get(url_reg, headers=HEADERS_SUPABASE)
    
    if res_reg.ok:
        registros = res_reg.json()
        total_entrenamientos = len(registros)
        if total_entrenamientos == 0:
            return "Todavía no has registrado entrenamientos. ¡Aprovecha hoy para empezar!"
        return f"¡Vas súper bien! Has registrado {total_entrenamientos} sesiones de entrenamiento hasta ahora. Sigue con esa disciplina."
    
    return "No pude cargar tu historial de progreso en este momento."

@tool
def obtener_entrenamiento_ayer(usuario_id: str) -> str:
    """
    Consulta qué entrenó el usuario el día de ayer, o si olvidó registrar su entrenamiento.
    Úsalo cuando pregunte "¿qué me tocaba ayer?" o "¿qué hice ayer?".
    
    Args:
        usuario_id: UUID del usuario.
    """
    ayer = (date.today() - timedelta(days=1)).isoformat()
    url = f"{SUPABASE_URL}/rest/v1/registros_entrenamiento?usuario_id=eq.{usuario_id}&fecha_ejecucion=eq.{ayer}&select=*"
    res = requests.get(url, headers=HEADERS_SUPABASE)
    
    if res.ok:
        datos = res.json()
        if len(datos) > 0:
            return "Ayer sí registraste tu entrenamiento en la app. ¡Gran trabajo!"
        else:
            return "Parece que ayer no registraste ningún entrenamiento. Si entrenaste, recuerda anotarlo para llevar bien tu progreso."
    return "Error consultando los datos de ayer."

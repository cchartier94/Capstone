"""
@file servicio_planes.py
@description Servicio de lógica de negocio para historial de planes (SCRUM-37).
             Lectura de planes generados vía Supabase REST API.
             Tabla: planes.
@author FitAI Team
"""

import os
import re
from typing import Dict, Any, List, Optional

import requests
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_CLAVE_SERVICIO")

HEADERS_SUPABASE = {
    "apikey": SUPABASE_KEY or "",
    "Authorization": f"Bearer {SUPABASE_KEY}" if SUPABASE_KEY else "",
    "Content-Type": "application/json",
}


class ServicioPlanes:
    """Consultas de historial de planes contra Supabase REST API."""

    def obtener_historial(self, usuario_id: str, limite: int = 20) -> dict:
        """
        Obtiene el historial de planes del usuario, ordenados por fecha
        descendente (más reciente primero). Solo campos de resumen, sin
        el JSON completo de la IA para mantener la respuesta liviana.

        :param usuario_id: UUID del usuario.
        :param limite: Máximo de planes a retornar.
        :returns: dict con exito, total y lista de planes resumidos.
        """
        try:
            # select solo columnas de resumen (excluir respuesta_raw_ia)
            url = (
                f"{SUPABASE_URL}/rest/v1/planes"
                f"?usuario_id=eq.{usuario_id}"
                f"&select=id,fecha_creacion,objetivo_seleccionado,duracion_meses,estado"
                f"&order=fecha_creacion.desc"
                f"&limit={limite}"
            )
            response = requests.get(url, headers=HEADERS_SUPABASE)

            if response.ok:
                planes = response.json()
                return {
                    "exito": True,
                    "total": len(planes),
                    "planes": planes,
                }
            else:
                return {
                    "exito": False,
                    "total": 0,
                    "planes": [],
                    "mensaje": f"Error al consultar BD: {response.text}",
                }

        except Exception as e:
            print(f"ERROR en servicio_planes.obtener_historial: {e}")
            return {
                "exito": False,
                "total": 0,
                "planes": [],
                "mensaje": f"Error interno: {str(e)}",
            }

    def obtener_detalle(self, plan_id: str, usuario_id: str) -> dict:
        """
        Obtiene el detalle completo de un plan específico, incluyendo
        el JSON generado por la IA (respuesta_raw_ia).

        :param plan_id: UUID del plan.
        :param usuario_id: UUID del usuario (para validar pertenencia).
        :returns: dict con exito y el plan completo.
        """
        try:
            url = (
                f"{SUPABASE_URL}/rest/v1/planes"
                f"?id=eq.{plan_id}"
                f"&usuario_id=eq.{usuario_id}"
                f"&limit=1"
            )
            response = requests.get(url, headers=HEADERS_SUPABASE)

            if response.ok:
                planes = response.json()
                if planes:
                    return {
                        "exito": True,
                        "plan": planes[0],
                        "mensaje": "Plan encontrado",
                    }
                else:
                    return {
                        "exito": False,
                        "plan": None,
                        "mensaje": "Plan no encontrado o no pertenece al usuario",
                    }
            else:
                return {
                    "exito": False,
                    "plan": None,
                    "mensaje": f"Error al consultar BD: {response.text}",
                }

        except Exception as e:
            print(f"ERROR en servicio_planes.obtener_detalle: {e}")
            return {
                "exito": False,
                "plan": None,
                "mensaje": f"Error interno: {str(e)}",
            }

    def obtener_plan_activo(self, usuario_id: str) -> dict:
        """
        Obtiene el plan activo actual del usuario (estado = 'activo').

        :param usuario_id: UUID del usuario.
        :returns: dict con exito y el plan activo (o None).
        """
        try:
            url = (
                f"{SUPABASE_URL}/rest/v1/planes"
                f"?usuario_id=eq.{usuario_id}"
                f"&estado=eq.activo"
                f"&order=fecha_creacion.desc"
                f"&limit=1"
            )
            response = requests.get(url, headers=HEADERS_SUPABASE)

            if response.ok:
                planes = response.json()
                if planes:
                    plan_activo = planes[0]
                    
                    # Obtener registros de la ultima semana para saber dias completados
                    from datetime import date, timedelta
                    hace_7_dias = (date.today() - timedelta(days=7)).isoformat()
                    url_regs = f"{SUPABASE_URL}/rest/v1/registros_entrenamiento?usuario_id=eq.{usuario_id}&fecha_ejecucion=gte.{hace_7_dias}&select=fecha_ejecucion"
                    res_regs = requests.get(url_regs, headers=HEADERS_SUPABASE)
                    dias_completados = []
                    if res_regs.ok:
                        regs = res_regs.json()
                        dias_map = {0: 'lunes', 1: 'martes', 2: 'miercoles', 3: 'jueves', 4: 'viernes', 5: 'sabado', 6: 'domingo'}
                        for r in regs:
                            if r.get("fecha_ejecucion"):
                                try:
                                    # fecha_ejecucion puede venir con hora (ISO), cortamos en T
                                    fecha_str = r["fecha_ejecucion"].split("T")[0]
                                    dt = date.fromisoformat(fecha_str)
                                    # Si la fecha es de esta misma semana calendario:
                                    # (O simplemente ultimos 7 dias). Validamos que pertenezca a la misma semana
                                    dias_completados.append(dias_map[dt.weekday()])
                                except Exception:
                                    pass
                    
                    plan_activo["dias_completados"] = list(set(dias_completados))

                    return {
                        "exito": True,
                        "plan": plan_activo,
                        "mensaje": "Plan activo encontrado",
                    }
                else:
                    return {
                        "exito": True,
                        "plan": None,
                        "mensaje": "No hay plan activo",
                    }
            else:
                return {
                    "exito": False,
                    "plan": None,
                    "mensaje": f"Error al consultar BD: {response.text}",
                }

        except Exception as e:
            print(f"ERROR en servicio_planes.obtener_plan_activo: {e}")
            return {
                "exito": False,
                "plan": None,
                "mensaje": f"Error interno: {str(e)}",
            }

    def _parsear_descanso(self, descanso_val: Any) -> int:
        """
        Parsea una cadena de texto que describe el descanso a segundos.
        Ejemplos: "90 seg" -> 90, "2 min" -> 120, "90s" -> 90, 90 -> 90.
        """
        if not descanso_val:
            return 60
        if isinstance(descanso_val, (int, float)):
            return int(descanso_val)
        
        descanso_str = str(descanso_val).lower().strip()
        numeros = re.findall(r'[\d\.]+', descanso_str)
        if not numeros:
            return 60
        
        try:
            valor = float(numeros[0])
        except ValueError:
            return 60
            
        if "min" in descanso_str:
            return int(valor * 60)
        
        return int(valor)

    def normalizar_plan(self, plan_id: str, plan_generado: dict) -> dict:
        """
        Normaliza el plan generado por la IA guardando la información en las
        tablas relacionales correspondientes de Supabase:
        - semanas_entrenamiento
        - dias_entrenamiento
        - ejercicios_planificados (y catalogo de ejercicios si no existen)

        :param plan_id: UUID del plan insertado.
        :param plan_generado: Diccionario JSON retornado por la IA.
        :returns: dict indicando el resultado de la normalización.
        """
        try:
            headers_rep = HEADERS_SUPABASE.copy()
            headers_rep["Prefer"] = "return=representation"

            # 1. Crear la semana de entrenamiento
            nombre_plan = plan_generado.get("nombre_plan", "Plan de Entrenamiento")
            payload_semana = {
                "plan_id": plan_id,
                "numero_semana": 1,  # Por defecto
                "enfoque_semana": nombre_plan
            }

            url_semana = f"{SUPABASE_URL}/rest/v1/semanas_entrenamiento"
            res_semana = requests.post(url_semana, json=payload_semana, headers=headers_rep)

            if not res_semana.ok:
                print(f"[normalizar_plan] Error al crear semana: {res_semana.text}")
                return {"exito": False, "mensaje": f"Error al crear semana: {res_semana.text}"}

            semana_creada = res_semana.json()
            if not semana_creada:
                return {"exito": False, "mensaje": "Respuesta vacía al crear semana"}
            
            semana_id = semana_creada[0].get("id")
            print(f"[normalizar_plan] Semana creada con ID: {semana_id}")

            # Mapeo de días de la semana a números
            MAPEO_DIAS = {
                "lunes": 1, "martes": 2, "miércoles": 3, "miercoles": 3,
                "jueves": 4, "viernes": 5, "sábado": 6, "sabado": 6, "domingo": 7
            }

            semana_lista = plan_generado.get("semana", [])
            for idx, dia_data in enumerate(semana_lista):
                dia_nombre = dia_data.get("dia", "").strip()
                dia_nombre_lower = dia_nombre.lower()
                numero_dia = MAPEO_DIAS.get(dia_nombre_lower, idx + 1)

                rutina = dia_data.get("rutina")
                # Usa la bandera es_descanso explícita del JSON. Fallback a la validación anterior por retrocompatibilidad.
                es_descanso = dia_data.get("es_descanso", isinstance(rutina, str) or not rutina)

                # 2. Insertar día de entrenamiento
                payload_dia = {
                    "semana_entrenamiento_id": semana_id,
                    "numero_dia": numero_dia,
                    "es_dia_descanso": es_descanso
                }

                url_dia = f"{SUPABASE_URL}/rest/v1/dias_entrenamiento"
                res_dia = requests.post(url_dia, json=payload_dia, headers=headers_rep)

                if not res_dia.ok:
                    print(f"[normalizar_plan] Error al crear día {dia_nombre}: {res_dia.text}")
                    continue

                dia_creado = res_dia.json()
                if not dia_creado:
                    continue
                dia_id = dia_creado[0].get("id")
                print(f"[normalizar_plan] Día {dia_nombre} creado con ID: {dia_id}")

                # Si es día de entrenamiento (no descanso) e incluye ejercicios
                if not es_descanso and isinstance(rutina, list):
                    for orden, ej_data in enumerate(rutina, start=1):
                        nombre_ej = ej_data.get("nombre", "").strip()
                        if not nombre_ej:
                            continue

                        grupo_muscular = ej_data.get("grupo_muscular", "General").strip()
                        series = ej_data.get("series", 4)
                        try:
                            series_int = int(series)
                        except (ValueError, TypeError):
                            series_int = 4

                        reps = str(ej_data.get("reps", "8-12"))
                        if not reps or reps == "None":
                            reps = "8-12"

                        descanso_val = ej_data.get("descanso", "90s")
                        descanso_seg = self._parsear_descanso(descanso_val)
                        notas = ej_data.get("notas", "").strip()

                        # 3. Obtener o crear ejercicio en el catálogo
                        url_cat = f"{SUPABASE_URL}/rest/v1/ejercicios_catalogo"
                        
                        # Buscar por coincidencia exacta de nombre de forma segura (URL-encoded)
                        res_busq = requests.get(url_cat, params={"nombre": f"eq.{nombre_ej}"}, headers=HEADERS_SUPABASE)
                        ej_cat_id = None

                        if res_busq.ok and res_busq.json():
                            ej_cat_id = res_busq.json()[0].get("id")
                            print(f"[normalizar_plan] Ejercicio '{nombre_ej}' encontrado en catálogo con ID: {ej_cat_id}")
                        else:
                            # Insertar nuevo ejercicio
                            payload_cat = {
                                "nombre": nombre_ej,
                                "grupo_muscular": grupo_muscular,
                                "descripcion": notas or "Ejercicio planificado por el sistema FitAI",
                                "instrucciones": notas or ""
                            }
                            res_ins_cat = requests.post(url_cat, json=payload_cat, headers=headers_rep)
                            if res_ins_cat.ok and res_ins_cat.json():
                                ej_cat_id = res_ins_cat.json()[0].get("id")
                                print(f"[normalizar_plan] Nuevo ejercicio '{nombre_ej}' agregado al catálogo con ID: {ej_cat_id}")
                            else:
                                print(f"[normalizar_plan] Error al crear ejercicio en catálogo: {res_ins_cat.text}")

                        # 4. Insertar ejercicio planificado
                        payload_planificado = {
                            "dia_entrenamiento_id": dia_id,
                            "ejercicio_catalogo_id": ej_cat_id,
                            "series_objetivo": series_int,
                            "repeticiones_objetivo": reps,
                            "descanso_objetivo_segundos": descanso_seg,
                            "orden_rutina": orden
                        }

                        url_planificado = f"{SUPABASE_URL}/rest/v1/ejercicios_planificados"
                        res_planificado = requests.post(url_planificado, json=payload_planificado, headers=HEADERS_SUPABASE)
                        if not res_planificado.ok:
                            print(f"[normalizar_plan] Error al planificar ejercicio '{nombre_ej}': {res_planificado.text}")

            return {"exito": True, "mensaje": "Plan normalizado exitosamente en la base de datos"}

        except Exception as e:
            print(f"ERROR en normalizar_plan: {e}")
            import traceback
            traceback.print_exc()
            return {"exito": False, "mensaje": f"Error interno en normalización: {str(e)}"}

    def obtener_rutina_activa(self, usuario_id: str) -> dict:
        """
        Obtiene la rutina de entrenamiento activa actual del usuario de forma normalizada,
        consultando las tablas relacionales:
        planes -> semanas_entrenamiento -> dias_entrenamiento -> ejercicios_planificados.

        :param usuario_id: UUID del usuario.
        :returns: dict indicando exito, y la estructura de semanas, días y ejercicios.
        """
        try:
            # 1. Obtener el plan activo del usuario
            resultado_plan = self.obtener_plan_activo(usuario_id)
            if not resultado_plan.get("exito") or not resultado_plan.get("plan"):
                return {
                    "exito": True,
                    "plan_id": None,
                    "semanas": [],
                    "mensaje": resultado_plan.get("mensaje", "No hay plan activo para el usuario")
                }

            plan = resultado_plan["plan"]
            plan_id = plan["id"]
            respuesta_raw_ia = plan.get("respuesta_raw_ia") or {}

            # Obtener el mapping de tipo de entrenamiento por día desde el JSON raw para enriquecer
            semana_raw = respuesta_raw_ia.get("semana", [])
            tipo_por_dia = {}
            for item in semana_raw:
                dia_str = item.get("dia", "").strip().lower()
                tipo_por_dia[dia_str] = item.get("tipo", "")

            # 2. Obtener las semanas de entrenamiento del plan
            url_semanas = f"{SUPABASE_URL}/rest/v1/semanas_entrenamiento?plan_id=eq.{plan_id}&order=numero_semana.asc"
            res_semanas = requests.get(url_semanas, headers=HEADERS_SUPABASE)
            if not res_semanas.ok:
                return {
                    "exito": False,
                    "plan_id": plan_id,
                    "semanas": [],
                    "mensaje": f"Error al obtener semanas del plan: {res_semanas.text}"
                }

            semanas_db = res_semanas.json()
            if not semanas_db:
                return {
                    "exito": True,
                    "plan_id": plan_id,
                    "semanas": [],
                    "mensaje": "El plan activo no tiene semanas de entrenamiento registradas"
                }

            semana_ids = [s["id"] for s in semanas_db]

            # 3. Obtener los días de entrenamiento de todas las semanas
            url_dias = f"{SUPABASE_URL}/rest/v1/dias_entrenamiento?semana_entrenamiento_id=in.({','.join(semana_ids)})&order=numero_dia.asc"
            res_dias = requests.get(url_dias, headers=HEADERS_SUPABASE)
            if not res_dias.ok:
                return {
                    "exito": False,
                    "plan_id": plan_id,
                    "semanas": [],
                    "mensaje": f"Error al obtener días de entrenamiento: {res_dias.text}"
                }

            dias_db = res_dias.json()
            dia_ids = [d["id"] for d in dias_db]

            # Mapear días por semana para armar la jerarquía
            dias_por_semana = {}
            for d in dias_db:
                semana_id = d["semana_entrenamiento_id"]
                if semana_id not in dias_por_semana:
                    dias_por_semana[semana_id] = []
                dias_por_semana[semana_id].append(d)

            # 4. Obtener todos los ejercicios planificados de esos días
            ejercicios_por_dia = {}
            if dia_ids:
                url_ejercicios = f"{SUPABASE_URL}/rest/v1/ejercicios_planificados?dia_entrenamiento_id=in.({','.join(dia_ids)})&select=*,ejercicios_catalogo(*)&order=orden_rutina.asc"
                res_ejercicios = requests.get(url_ejercicios, headers=HEADERS_SUPABASE)
                if not res_ejercicios.ok:
                    return {
                        "exito": False,
                        "plan_id": plan_id,
                        "semanas": [],
                        "mensaje": f"Error al obtener ejercicios planificados: {res_ejercicios.text}"
                    }

                ejercicios_db = res_ejercicios.json()
                for ej in ejercicios_db:
                    dia_id = ej["dia_entrenamiento_id"]
                    if dia_id not in ejercicios_por_dia:
                        ejercicios_por_dia[dia_id] = []
                    
                    # Extraer información del catálogo si existe
                    cat_info = ej.get("ejercicios_catalogo") or {}
                    nombre_ej = cat_info.get("nombre", "Ejercicio Desconocido")
                    grupo_muscular = cat_info.get("grupo_muscular", "")
                    notas = cat_info.get("descripcion", "")

                    ej_detalle = {
                        "id": ej["id"],
                        "ejercicio_catalogo_id": ej["ejercicio_catalogo_id"],
                        "nombre": nombre_ej,
                        "grupo_muscular": grupo_muscular,
                        "series_objetivo": ej.get("series_objetivo"),
                        "repeticiones_objetivo": ej.get("repeticiones_objetivo"),
                        "descanso_objetivo_segundos": ej.get("descanso_objetivo_segundos"),
                        "orden_rutina": ej.get("orden_rutina"),
                        "notas": notas
                    }
                    ejercicios_por_dia[dia_id].append(ej_detalle)

            # Nombres de días según su número para enriquecer
            NOMBRES_DIAS = {
                1: "Lunes", 2: "Martes", 3: "Miércoles", 4: "Jueves",
                5: "Viernes", 6: "Sábado", 7: "Domingo"
            }

            # 5. Armar la jerarquía de retorno
            semanas_retorno = []
            for s in semanas_db:
                semana_id = s["id"]
                dias_de_esta_semana = dias_por_semana.get(semana_id, [])
                
                dias_retorno = []
                for d in dias_de_esta_semana:
                    dia_id = d["id"]
                    num_dia = d["numero_dia"]
                    dia_nombre = NOMBRES_DIAS.get(num_dia, f"Día {num_dia}")
                    
                    # Obtener el tipo de día desde el raw JSON
                    tipo_dia = tipo_por_dia.get(dia_nombre.lower(), "Descanso" if d["es_dia_descanso"] else "Entrenamiento")

                    dias_retorno.append({
                        "id": dia_id,
                        "numero_dia": num_dia,
                        "es_dia_descanso": d["es_dia_descanso"],
                        "tipo": tipo_dia,
                        "ejercicios": ejercicios_por_dia.get(dia_id, [])
                    })

                semanas_retorno.append({
                    "id": semana_id,
                    "numero_semana": s["numero_semana"],
                    "enfoque_semana": s["enfoque_semana"],
                    "dias": dias_retorno
                })

            return {
                "exito": True,
                "plan_id": plan_id,
                "semanas": semanas_retorno,
                "mensaje": "Rutina activa recuperada exitosamente"
            }

        except Exception as e:
            print(f"ERROR en obtener_rutina_activa: {e}")
            import traceback
            traceback.print_exc()
            return {
                "exito": False,
                "plan_id": None,
                "semanas": [],
                "mensaje": f"Error interno al obtener rutina activa: {str(e)}"
            }

    def actualizar_plan(self, plan_id: str, usuario_id: str, datos_actualizar: dict) -> dict:
        """
        Actualiza los datos de un plan existente (por ejemplo, respuesta_raw_ia).
        """
        try:
            url = f"{SUPABASE_URL}/rest/v1/planes?id=eq.{plan_id}&usuario_id=eq.{usuario_id}"
            
            # Solo permitimos actualizar respuesta_raw_ia por ahora
            payload = {}
            if "respuesta_raw_ia" in datos_actualizar:
                payload["respuesta_raw_ia"] = datos_actualizar["respuesta_raw_ia"]
                
            if not payload:
                return {"exito": False, "mensaje": "No hay datos validos para actualizar"}

            response = requests.patch(url, headers=HEADERS_SUPABASE, json=payload)
            
            if response.ok:
                return {"exito": True, "mensaje": "Plan actualizado correctamente"}
            else:
                return {"exito": False, "mensaje": f"Error al actualizar BD: {response.text}"}

        except Exception as e:
            print(f"ERROR en servicio_planes.actualizar_plan: {e}")
            return {"exito": False, "mensaje": f"Error interno: {str(e)}"}

    def evolucionar_plan(self, plan_id: str, feedback: str) -> dict:
        """
        Ajusta la rutina de la semana activa en función del feedback.
        Si fue 'muy_facil', se añade un repetición o un poco de carga.
        Si fue 'muy_dificil', se reduce volumen.
        """
        try:
            import time
            time.sleep(2) # Simular latencia de Claude

            url = f"{SUPABASE_URL}/rest/v1/planes?id=eq.{plan_id}"
            res = requests.get(url, headers=HEADERS_SUPABASE)
            if not res.ok or not res.json():
                return {"exito": False, "mensaje": "Plan no encontrado"}
            
            plan_db = res.json()[0]
            raw_ia = plan_db.get("respuesta_raw_ia", {})
            if not raw_ia or "semana" not in raw_ia:
                return {"exito": True, "mensaje": "Plan evolucionado lógicamente (sin raw IA disponible)."}

            # MOCK EVOLUTION LOGIC:
            for dia in raw_ia.get("semana", []):
                for ej in dia.get("rutina", []):
                    try:
                        if feedback == "muy_facil":
                            ej["reps"] = str(int(ej.get("reps", 10)) + 2)
                        elif feedback == "muy_dificil":
                            ej["series"] = max(1, int(ej.get("series", 3)) - 1)
                    except:
                        pass
            
            payload = {"respuesta_raw_ia": raw_ia}
            headers = HEADERS_SUPABASE.copy()
            headers["Prefer"] = "return=minimal"
            update_res = requests.patch(url, json=payload, headers=headers)
            
            if update_res.ok:
                return {"exito": True, "mensaje": "Tu plan ha sido re-generado por la IA en base a tus resultados."}
            return {"exito": False, "mensaje": "Error guardando la evolución en BD."}

        except Exception as e:
            return {"exito": False, "mensaje": str(e)}

servicio_planes = ServicioPlanes()

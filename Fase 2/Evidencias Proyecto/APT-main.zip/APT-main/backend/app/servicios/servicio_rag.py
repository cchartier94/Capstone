import os
from typing import List
from langchain_community.document_loaders import TextLoader, PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

class ServicioRAG:
    """
    Servicio de Recuperación de Información (RAG).
    Indexa documentos técnicos de fitness y nutrición para proveer contexto a la IA.
    """

    def __init__(self):
        self.ruta_conocimiento = os.path.join(os.getcwd(), "conocimiento")
        self.ruta_db_vectorial = os.path.join(os.getcwd(), "faiss_index")
        
        # Usamos un modelo de embeddings ligero y local
        print("Cargando modelo de embeddings local (esto puede tardar la primera vez)...")
        self.embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        self.vector_db = None
        
        # Inicializar base de datos
        self.inicializar_base_datos()

    def inicializar_base_datos(self):
        """Carga el índice existente o crea uno nuevo si hay documentos."""
        if os.path.exists(self.ruta_db_vectorial):
            print("Cargando base de datos vectorial existente...")
            self.vector_db = FAISS.load_local(
                self.ruta_db_vectorial, 
                self.embeddings, 
                allow_dangerous_deserialization=True
            )
        else:
            self.indexar_documentos()

    def indexar_documentos(self):
        """Lee los archivos en la carpeta conocimiento e indexa su contenido."""
        if not os.path.exists(self.ruta_conocimiento):
            os.makedirs(self.ruta_conocimiento)
            return

        documentos_cargados = []
        for archivo in os.listdir(self.ruta_conocimiento):
            ruta_completa = os.path.join(self.ruta_conocimiento, archivo)
            try:
                if archivo.endswith(".md") or archivo.endswith(".txt"):
                    loader = TextLoader(ruta_completa, encoding="utf-8")
                    documentos_cargados.extend(loader.load())
                elif archivo.endswith(".pdf"):
                    loader = PyPDFLoader(ruta_completa)
                    documentos_cargados.extend(loader.load())
            except Exception as e:
                print(f"Error cargando {archivo}: {e}")

        if not documentos_cargados:
            print("No se encontraron documentos para indexar en 'conocimiento/'.")
            return

        # Dividir texto en trozos (chunks) manejables
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=100
        )
        chunks = text_splitter.split_documents(documentos_cargados)

        # Crear índice FAISS
        self.vector_db = FAISS.from_documents(chunks, self.embeddings)
        
        # Guardar localmente
        self.vector_db.save_local(self.ruta_db_vectorial)
        print(f"OK: Base de datos vectorial indexada con {len(chunks)} fragmentos.")

    def buscar_contexto(self, query: str, k: int = 3) -> str:
        """Busca los fragmentos más relevantes para una consulta."""
        if not self.vector_db:
            return ""
        
        resultados = self.vector_db.similarity_search(query, k=k)
        contexto = "\n\n".join([doc.page_content for doc in resultados])
        return contexto

# Instancia global del servicio
try:
    servicio_rag = ServicioRAG()
except Exception as e:
    print(f"ADVERTENCIA: No se pudo iniciar el servicio RAG: {e}")
    servicio_rag = None

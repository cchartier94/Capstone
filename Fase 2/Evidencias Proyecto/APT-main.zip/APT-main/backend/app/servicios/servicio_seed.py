import os
import requests
import uuid
import random
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()

# Raw IA response of the plan
PLAN_RAW_IA = {
  "semana": [
    {
      "dia": "Lunes",
      "tipo": "Descanso Activo / Cardio Ligero",
      "rutina": "Descanso"
    },
    {
      "dia": "Martes",
      "tipo": "Fuerza Inferior - Cuádriceps y Glúteos",
      "rutina": [
        {
          "reps": "5",
          "nombre": "Sentadilla trasera profunda",
          "series": 5,
          "descanso": "180s",
          "grupo_muscular": "Piernas"
        },
        {
          "reps": "12-15",
          "nombre": "Prensa de piernas",
          "series": 4,
          "descanso": "90s",
          "grupo_muscular": "Piernas"
        },
        {
          "reps": "15-20",
          "nombre": "Extensiones de cuádriceps",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Piernas"
        },
        {
          "reps": "12 por lado",
          "nombre": "Zancadas caminando",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Piernas"
        }
      ]
    },
    {
      "dia": "Miércoles",
      "tipo": "Tracción y Core - Espalda y Bíceps",
      "rutina": [
        {
          "reps": "8-10",
          "nombre": "Dominadas con lastre",
          "series": 4,
          "descanso": "90s",
          "grupo_muscular": "Espalda"
        },
        {
          "reps": "8-10",
          "nombre": "Remo con barra (Pendlay)",
          "series": 4,
          "descanso": "90s",
          "grupo_muscular": "Espalda"
        },
        {
          "reps": "12-15",
          "nombre": "Jalón al pecho agarre estrecho",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Espalda"
        },
        {
          "reps": "10-12",
          "nombre": "Curl de bíceps con barra Z",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Bíceps"
        },
        {
          "reps": "15",
          "nombre": "Abdominales en polea alta",
          "series": 4,
          "descanso": "45s",
          "grupo_muscular": "Core"
        }
      ]
    },
    {
      "dia": "Jueves",
      "tipo": "Descanso Total",
      "rutina": "Descanso"
    },
    {
      "dia": "Viernes",
      "tipo": "Empuje de Potencia - Pecho y Hombros",
      "rutina": [
        {
          "reps": "6-8",
          "nombre": "Press de banca con barra",
          "series": 4,
          "descanso": "120s",
          "grupo_muscular": "Pecho"
        },
        {
          "reps": "8-10",
          "nombre": "Press militar de pie",
          "series": 4,
          "descanso": "90s",
          "grupo_muscular": "Hombros"
        },
        {
          "reps": "12-15",
          "nombre": "Aperturas inclinadas con mancuernas",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Pecho"
        },
        {
          "reps": "15-20",
          "nombre": "Elevaciones laterales",
          "series": 4,
          "descanso": "45s",
          "grupo_muscular": "Hombros"
        },
        {
          "reps": "Fallo",
          "nombre": "Fondos en paralelas",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Tríceps"
        }
      ]
    },
    {
      "dia": "Sábado",
      "tipo": "Acondicionamiento Metabólico y Brazos",
      "rutina": [
        {
          "reps": "10-12",
          "nombre": "Press francés",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Tríceps"
        },
        {
          "reps": "10-12",
          "nombre": "Curl martillo",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Bíceps"
        },
        {
          "reps": "15-20",
          "nombre": "Facepulls",
          "series": 3,
          "descanso": "45s",
          "grupo_muscular": "Hombros"
        },
        {
          "reps": "20",
          "nombre": "KB Swings",
          "series": 4,
          "descanso": "30s",
          "grupo_muscular": "Full Body"
        }
      ]
    },
    {
      "dia": "Domingo",
      "tipo": "Fuerza Inferior - Isquios y Pantorrillas",
      "rutina": [
        {
          "reps": "10-12",
          "nombre": "Peso muerto rumano",
          "series": 4,
          "descanso": "90s",
          "grupo_muscular": "Piernas"
        },
        {
          "reps": "12-15",
          "nombre": "Curl femoral acostado",
          "series": 4,
          "descanso": "60s",
          "grupo_muscular": "Piernas"
        },
        {
          "reps": "15-20",
          "nombre": "Elevaciones de talones de pie",
          "series": 4,
          "descanso": "45s",
          "grupo_muscular": "Piernas"
        },
        {
          "reps": "12",
          "nombre": "Rueda abdominal",
          "series": 3,
          "descanso": "60s",
          "grupo_muscular": "Core"
        }
      ]
    }
  ],
  "resumen": "Programa de alta intensidad diseñado para maximizar la quema de grasa preservando la masa magra. Enfoque en sobrecarga progresiva y densidad de entrenamiento.",
  "nombre_plan": "Protocolo de Definición Élite - Fase 2",
  "duracion_semanas": 4,
  "macros_recomendados": {
    "grasas_g": 60,
    "proteinas_g": 200,
    "carbohidratos_g": 180
  },
  "calorias_diarias_recomendadas": 2150
}

# Exercise mapping for completed log generator
WORKOUTS_ROUTINE = {
  1: [ # Tuesday
    {"nombre": "Sentadilla trasera profunda", "series": 5, "reps": 5, "peso": 120},
    {"nombre": "Prensa de piernas", "series": 4, "reps": 12, "peso": 200},
    {"nombre": "Extensiones de cuádriceps", "series": 3, "reps": 15, "peso": 60},
    {"nombre": "Zancadas caminando", "series": 3, "reps": 12, "peso": 20}
  ],
  2: [ # Wednesday
    {"nombre": "Dominadas con lastre", "series": 4, "reps": 8, "peso": 20},
    {"nombre": "Remo con barra (Pendlay)", "series": 4, "reps": 10, "peso": 80},
    {"nombre": "Jalón al pecho agarre estrecho", "series": 3, "reps": 12, "peso": 65},
    {"nombre": "Curl de bíceps con barra Z", "series": 3, "reps": 12, "peso": 35},
    {"nombre": "Abdominales en polea alta", "series": 4, "reps": 15, "peso": 30}
  ],
  4: [ # Friday
    {"nombre": "Press de banca con barra", "series": 4, "reps": 8, "peso": 95},
    {"nombre": "Press militar de pie", "series": 4, "reps": 10, "peso": 55},
    {"nombre": "Aperturas inclinadas con mancuernas", "series": 3, "reps": 12, "peso": 26},
    {"nombre": "Elevaciones laterales", "series": 4, "reps": 15, "peso": 12.5},
    {"nombre": "Fondos en paralelas", "series": 3, "reps": 12, "peso": 0.0}
  ],
  5: [ # Saturday
    {"nombre": "Press francés", "series": 3, "reps": 12, "peso": 30},
    {"nombre": "Curl martillo", "series": 3, "reps": 12, "peso": 15},
    {"nombre": "Facepulls", "series": 3, "reps": 15, "peso": 20},
    {"nombre": "KB Swings", "series": 4, "reps": 20, "peso": 24}
  ],
  6: [ # Sunday
    {"nombre": "Peso muerto rumano", "series": 4, "reps": 10, "peso": 100},
    {"nombre": "Curl femoral acostado", "series": 4, "reps": 12, "peso": 45},
    {"nombre": "Elevaciones de talones de pie", "series": 4, "reps": 15, "peso": 60},
    {"nombre": "Rueda abdominal", "series": 3, "reps": 12, "peso": 0.0}
  ]
}

def seed_demo_users(db_ignored):
    """Pobla Supabase vía REST API para la demo con datos enriched."""
    try:
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

        # IDs fijos
        ID_DEMO_ADVANCED = "11111111-1111-1111-1111-111111111111" # Carlos Avanzado fallback
        ID_STUCK = "bbbb2222-2222-2222-2222-222222222222" # Diego Rezagado
        ID_NEW = "cccc3333-3333-3333-3333-333333333333" # Marta Nova

        # 1. Limpiar usuarios (ON DELETE CASCADE limpia perfiles, metricas, planes y registros)
        print("Cleaning up old demo users...")
        # Limpiar por email para evitar conflictos de llave única
        for email in ["carlos.avanzado@fitai.test", "diego.rezagado@fitai.demo", "marta.nueva@fitai.demo", "demo@fitai.cl"]:
            requests.delete(f"{supabase_url}/rest/v1/usuarios?correo_electronico=eq.{email}", headers=headers)
        # Limpiar por ID por si acaso
        for uid in [ID_DEMO_ADVANCED, ID_STUCK, ID_NEW]:
            requests.delete(f"{supabase_url}/rest/v1/usuarios?id=eq.{uid}", headers=headers)

        # 2. Crear Usuarios
        print("Inserting users...")
        # contrasena is hashed for password "123456" for Carlos, and "password123" for others
        usuarios = [
            {
                "id": ID_DEMO_ADVANCED, 
                "correo_electronico": "carlos.avanzado@fitai.test", 
                "contrasena": "$2b$12$OsqP45QqwlPSrZRIH6RdC.BD/dG6mn4J6esU.UFi0hAKP/xNr6EC6"
            },
            {
                "id": ID_STUCK, 
                "correo_electronico": "diego.rezagado@fitai.demo", 
                "contrasena": "$2b$12$uQNwOAyQncjhy4huL5iXp.nzvFKPFd2tlGNnw00KZMfC9nf20N/ay"
            },
            {
                "id": ID_NEW, 
                "correo_electronico": "marta.nueva@fitai.demo", 
                "contrasena": "$2b$12$uQNwOAyQncjhy4huL5iXp.nzvFKPFd2tlGNnw00KZMfC9nf20N/ay"
            }
        ]
        requests.post(f"{supabase_url}/rest/v1/usuarios", json=usuarios, headers=headers)

        # 3. Crear Perfiles de Usuario
        print("Inserting user profiles...")
        perfiles = [
            {
                "usuario_id": ID_DEMO_ADVANCED, "nombre": "Carlos Martínez", "edad": 30, "sexo_biologico": "Masculino",
                "peso_actual_kg": 86.0, "estatura_cm": 180.0, "objetivo_principal": "Bajar grasa",
                "nivel_actividad": "Activo", "nivel_experiencia": "Avanzado", "lugar_entrenamiento": "Gimnasio",
                "tipo_entrenamiento": "Pesas", "dias_disponibles_semana": 5, "tiempo_por_sesion_minutos": 60,
                "condiciones_salud": "Ninguna", "tipo_dieta": "Sin restricciones",
                "preferencias_alimenticias": "Me gusta la pasta y el pollo", "alimentos_excluidos": "Mariscos"
            },
            {
                "usuario_id": ID_STUCK, "nombre": "Diego Rezagado", "edad": 25, "sexo_biologico": "Masculino",
                "peso_actual_kg": 80.0, "estatura_cm": 175.0, "objetivo_principal": "Ganar músculo",
                "nivel_actividad": "Moderado", "nivel_experiencia": "Intermedio", "lugar_entrenamiento": "Casa",
                "tipo_entrenamiento": "Calistenia", "dias_disponibles_semana": 3, "tiempo_por_sesion_minutos": 45,
                "condiciones_salud": "Ninguna", "tipo_dieta": "Sin restricciones",
                "preferencias_alimenticias": "Comida casera estándar", "alimentos_excluidos": "Maní"
            },
            {
                "usuario_id": ID_NEW, "nombre": "Marta Nova", "edad": 22, "sexo_biologico": "Femenino",
                "peso_actual_kg": 65.0, "estatura_cm": 165.0, "objetivo_principal": "Tonificar",
                "nivel_actividad": "Sedentario", "nivel_experiencia": "Principiante", "lugar_entrenamiento": "Gimnasio",
                "tipo_entrenamiento": "Máquinas", "dias_disponibles_semana": 3, "tiempo_por_sesion_minutos": 60,
                "condiciones_salud": "Ninguna", "tipo_dieta": "Sin restricciones",
                "preferencias_alimenticias": "Prefiero carnes blancas y ensaladas", "alimentos_excluidos": "Lácteos"
            }
        ]
        requests.post(f"{supabase_url}/rest/v1/perfiles_usuario", json=perfiles, headers=headers)

        # 4. Crear Configuraciones de Usuario
        print("Inserting user configurations...")
        configs = [
            {"usuario_id": ID_DEMO_ADVANCED, "unidad_peso": "kg"},
            {"usuario_id": ID_STUCK, "unidad_peso": "kg"},
            {"usuario_id": ID_NEW, "unidad_peso": "kg"}
        ]
        requests.post(f"{supabase_url}/rest/v1/configuracion_usuario", json=configs, headers=headers)

        # 5. Métricas físicas para Carlos Martínez (12 métricas durante 12 semanas)
        print("Inserting metrics for Carlos...")
        metricas_carlos = []
        for i in range(12, -1, -1):
            fecha = (datetime.now() - timedelta(weeks=i)).strftime("%Y-%m-%d")
            # De 88.0 kg baja progresivamente a 86.0 kg
            peso = 88.0 - ((12 - i) * 0.18)
            # Medida de cintura baja progresivamente de 92cm a 88cm
            cintura = 92.0 - ((12 - i) * 0.33)
            metricas_carlos.append({
                "usuario_id": ID_DEMO_ADVANCED,
                "fecha_registro": fecha,
                "peso_corporal_kg": round(peso, 2),
                "medida_cintura_cm": round(cintura, 2),
                "medida_pecho_cm": 104.0,
                "medida_cadera_cm": 100.0,
                "medida_brazos_cm": 38.0,
                "medida_piernas_cm": 58.0,
                "pasos_diarios": 10000 + random.randint(-1500, 1500),
                "calorias_quemadas": 2700.0 + random.randint(-200, 200)
            })
        requests.post(f"{supabase_url}/rest/v1/metricas_fisicas", json=metricas_carlos, headers=headers)

        # 6. Métricas físicas para Diego Rezagado (Diego estancado)
        print("Inserting metrics for Diego...")
        metricas_diego = []
        for i in range(8, -1, -1):
            fecha = (datetime.now() - timedelta(weeks=i)).strftime("%Y-%m-%d")
            metricas_diego.append({
                "usuario_id": ID_STUCK,
                "fecha_registro": fecha,
                "peso_corporal_kg": 80.0,
                "medida_cintura_cm": 86.0,
                "pasos_diarios": 6000 + random.randint(-1000, 1000),
                "calorias_quemadas": 2200.0
            })
        requests.post(f"{supabase_url}/rest/v1/metricas_fisicas", json=metricas_diego, headers=headers)

        # 7. Crear Plan Activo para Carlos Martínez
        print("Inserting plan for Carlos...")
        PLAN_ID = "dafe0321-e675-494a-940a-f88b01bf2763"
        plan_payload = {
            "id": PLAN_ID,
            "usuario_id": ID_DEMO_ADVANCED,
            "fecha_creacion": (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%dT%H:%M:%S+00:00"),
            "duracion_meses": 1,
            "objetivo_seleccionado": "Bajar Grasa - Fase Final",
            "estado": "activo",
            "respuesta_raw_ia": PLAN_RAW_IA
        }
        requests.post(f"{supabase_url}/rest/v1/planes", json=plan_payload, headers=headers)

        # Normalizar el plan en tablas relacionales para que se puedan consultar los ejercicios
        print("Normalizing active plan in tables...")
        from app.servicios.servicio_planes import ServicioPlanes
        ServicioPlanes().normalizar_plan(PLAN_ID, PLAN_RAW_IA)

        # 8. Generar 30 Entrenamientos reales e históricos para Carlos Martínez
        print("Generating training sessions history for Carlos...")
        entrenamientos = []
        # Carlos entrena: Martes(1), Miércoles(2), Viernes(4), Sábado(5), Domingo(6)
        dias_entrenamiento = [1, 2, 4, 5, 6]
        
        # Generar registros de entrenamiento en los últimos 60 días
        fechas_entrenamiento = []
        for i in range(60):
            dia_eval = datetime.now() - timedelta(days=60 - i)
            # No incluir el día de hoy para que se mantenga como pendiente en el dashboard
            if dia_eval.date() == datetime.now().date():
                continue
                
            if dia_eval.weekday() in dias_entrenamiento:
                # 90% consistencia
                if random.random() < 0.90:
                    fechas_entrenamiento.append(dia_eval)

        # Insertar registros_entrenamiento y obtener los IDs generados
        registros_entrenamiento_payload = []
        for dt in fechas_entrenamiento:
            registros_entrenamiento_payload.append({
                "usuario_id": ID_DEMO_ADVANCED,
                "dia_entrenamiento_id": None, # Relacional simplificado
                "fecha_ejecucion": dt.strftime("%Y-%m-%d"),
                "puntaje_adherencia": random.randint(85, 100),
                "notas_sensaciones": random.choice([
                    "Buen bombeo, me sentí fuerte en la primera serie.",
                    "Excelente sesión. Cumplí todas las repeticiones objetivo.",
                    "Sensaciones óptimas. Incrementé un 2% la carga en empujes.",
                    "Cansado al inicio, pero completé todo el volumen planificado.",
                    "Entrenamiento intenso. Muy buena respuesta de recuperación muscular."
                ])
            })
            
        headers_rep = headers.copy()
        headers_rep["Prefer"] = "return=representation"
        res_ent = requests.post(f"{supabase_url}/rest/v1/registros_entrenamiento", json=registros_entrenamiento_payload, headers=headers_rep)
        
        if res_ent.ok:
            entrenamientos_registrados = res_ent.json()
            print(f"Successfully seeded {len(entrenamientos_registrados)} training sessions.")
            
            # 9. Crear bitácoras de registros_ejercicios para cada entrenamiento
            # Esto es vital para calcular el Volumen Total en el progreso
            print("Generating exercise logs for volume calculation...")
            ejercicios_logs_payload = []
            
            for ent in entrenamientos_registrados:
                ent_id = ent.get("id")
                fecha_str = ent.get("fecha_ejecucion")
                dt = datetime.strptime(fecha_str, "%Y-%m-%d")
                weekday = dt.weekday()
                
                # Obtener ejercicios planificados para ese día de la semana
                ejercicios_del_dia = WORKOUTS_ROUTINE.get(weekday, [])
                for ej in ejercicios_del_dia:
                    # Variar levemente el peso o reps por realismo
                    variacion_peso = random.choice([-2.5, 0.0, 2.5]) if ej["peso"] > 0 else 0.0
                    peso_real = max(0.0, ej["peso"] + variacion_peso)
                    
                    ejercicios_logs_payload.append({
                        "registro_entrenamiento_id": ent_id,
                        "ejercicio_planificado_id": None, # Simplificado
                        "series_completadas": ej["series"],
                        "repeticiones_completadas": ej["reps"],
                        "peso_utilizado_kg": peso_real,
                        "tiempo_descanso_segundos": 60
                    })
            
            # Insertar en lotes de 100 para no saturar la API
            batch_size = 100
            for k in range(0, len(ejercicios_logs_payload), batch_size):
                requests.post(f"{supabase_url}/rest/v1/registros_ejercicios", json=ejercicios_logs_payload[k:k+batch_size], headers=headers)
            print(f"Successfully seeded {len(ejercicios_logs_payload)} exercise details (Volume populated).")
        else:
            print(f"Error seeding training sessions: {res_ent.text}")

        print("OK: Seeding de Supabase finalizado con éxito.")
        return True
    except Exception as e:
        print(f"Error seeding Supabase: {e}")
        return False

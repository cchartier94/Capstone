"""
FitAI Backend - Paquete de aplicación
"""

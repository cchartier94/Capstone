"""
@file principal.py
@description Aplicación principal de FastAPI para FitAI
@author Carlos Chartier
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import os
from dotenv import load_dotenv
from sqlalchemy.orm import Session
from sqlalchemy import text
import uuid

# Cargar variables de entorno
load_dotenv()

# Importar cliente BD
from app.nucleo.bd import obtener_bd, verificar_conexion
from app.modelos.perfil import PerfilUsuario
from app.esquemas.perfil import (
    ActualizarPerfilEntrada, RespuestaPerfil, RespuestaPlan,
    AuthRegistroEntrada, AuthVerificarCodigoEntrada
)
from app.esquemas.progreso import (
    ResumenProgresoRespuesta,
    HistorialEntrenamientosRespuesta,
    InsightsProgresoRespuesta,
)
from app.esquemas.metricas import (
    RegistrarMetricaEntrada,
    RespuestaMetrica,
    HistorialMetricasRespuesta,
)
from app.esquemas.planes import (
    HistorialPlanesRespuesta,
    DetallePlanRespuesta,
    RespuestaRutinaActiva,
    ActualizarPlanEntrada,
    EvolucionarPlanEntrada,
)
from app.servicios.servicio_claude import servicio_claude
from app.servicios.servicio_progreso import servicio_progreso
from app.servicios.servicio_metricas import servicio_metricas
from app.servicios.servicio_planes import servicio_planes
from app.servicios.servicio_entrenamiento import servicio_entrenamiento
from app.servicios.servicio_chat import servicio_chat
from app.servicios.servicio_ejercicios import servicio_ejercicios
from app.esquemas.entrenamiento import (
    RegistrarSesionEntrada,
    RespuestaRegistroSesion,
    RespuestaUltimoPeso,
)
from app.esquemas.chat import (
    EnviarMensajeEntrada,
    RespuestaMensaje,
)
from app.esquemas.ejercicios import (
    RespuestaAlternativas,
)
from app.esquemas.esquema_configuracion import (
    ConfiguracionEntrada,
    RespuestaConfiguracion,
    RespuestaCuenta,
)
from app.servicios.servicio_configuracion import servicio_configuracion
from app.servicios.servicio_cuenta import servicio_cuenta

# Importar enrutadores (serán creados después)
# from app.enrutadores import perfil, entrenamiento, nutricion

# Variables globales
ENTORNO_APP = os.getenv("ENTORNO_APP", "desarrollo")
PUERTO_APP = int(os.getenv("PUERTO_APP", 8000))
ORIGENES_PERMITIDOS = os.getenv("ORIGENES_PERMITIDOS", "http://localhost:8081").split(",")
USUARIO_ID = uuid.UUID("11111111-1111-1111-1111-111111111111")  # Demo user


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Contexto de vida de la aplicación"""
    # Al iniciar
    print(f"FitAI Backend iniciado en ambiente: {ENTORNO_APP}")
    if verificar_conexion():
        print("OK: Base de datos conectada")
    else:
        print("ADVERTENCIA: No se pudo conectar a la base de datos")
    yield
    # Al apagar
    print("FitAI Backend detenido")


# Crear aplicación FastAPI
app = FastAPI(
    title="FitAI API",
    description="API REST para FitAI - Aplicación de IA para Fitness Personalizado",
    version="1.0.0",
    lifespan=lifespan,
)

# Configurar CORS - Permitir todo en red local para pruebas
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==============================================================================
# RUTAS DE PRUEBA
# ==============================================================================

@app.get("/")
async def raiz():
    """Ruta raíz - Verificar que el servidor está corriendo"""
    return {
        "mensaje": "FitAI Backend está corriendo",
        "versión": "1.0.0",
        "ambiente": ENTORNO_APP,
    }


@app.post("/admin/seed-demo")
async def seed_datos(bd: Session = Depends(obtener_bd)):
    """Poblar base de datos con usuarios para la demo."""
    from app.servicios.servicio_seed import seed_demo_users
    exito = seed_demo_users(bd)
    if exito:
        return {"mensaje": "Base de datos poblada con éxito"}
    else:
        raise HTTPException(status_code=500, detail="Error al poblar datos")


@app.get("/health")
async def health_check(bd: Session = Depends(obtener_bd)):
    """Health check para monitoreo con verificación de BD"""
    try:
        # Intenta una query simple para verificar BD
        bd.execute(text("SELECT 1"))
        return {
            "estado": "ok",
            "servicio": "fitai-backend",
            "base_datos": "conectada"
        }
    except Exception as e:
        return {
            "estado": "error",
            "servicio": "fitai-backend",
            "base_datos": "desconectada",
            "error": str(e)
        }


# ==============================================================================
# ENDPOINTS DE PERFIL (SCRUM-42 al 54)
# ==============================================================================

@app.post("/auth/verificar-email")
async def verificar_email(datos: dict):
    """Verifica si un correo ya existe en la base de datos."""
    import requests
    try:
        correo = datos.get("correo")
        if not correo:
            raise HTTPException(status_code=400, detail="Correo requerido")

        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}"
        }
        
        url = f"{supabase_url}/rest/v1/usuarios?correo_electronico=eq.{correo}"
        res = requests.get(url, headers=headers)
        
        existe = len(res.json()) > 0
        return {"existe": existe}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/auth/login")
async def login_usuario(datos: dict):
    """
    Inicia sesión verificando si el correo existe en la base de datos y la contraseña coincide.
    Retorna los datos del usuario si existe, o un error.
    """
    import requests
    import bcrypt
    try:
        correo = datos.get("correo")
        contrasena = datos.get("contrasena")
        if not correo:
            raise HTTPException(status_code=400, detail="Correo requerido")
        if not contrasena:
            raise HTTPException(status_code=400, detail="Contraseña requerida")

        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}"
        }
        
        url = f"{supabase_url}/rest/v1/usuarios?correo_electronico=eq.{correo.lower().strip()}"
        res = requests.get(url, headers=headers)
        
        if not res.ok:
            return {"exito": False, "mensaje": "Error al consultar la base de datos"}
            
        usuarios = res.json()
        if not usuarios or len(usuarios) == 0:
            return {"exito": False, "mensaje": "El correo electrónico no está registrado."}
            
        usuario = usuarios[0]
        
        # Verificar contraseña
        hash_almacenado = usuario.get("contrasena")
        if not hash_almacenado:
            return {"exito": False, "mensaje": "Este usuario no tiene contraseña registrada. Regístrate de nuevo."}
            
        if not bcrypt.checkpw(contrasena.encode('utf-8'), hash_almacenado.encode('utf-8')):
            return {"exito": False, "mensaje": "Contraseña incorrecta."}
            
        perfil_url = f"{supabase_url}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario['id']}"
        res_perfil = requests.get(perfil_url, headers=headers)
        nombre = "Usuario"
        if res_perfil.ok and res_perfil.json():
            nombre = res_perfil.json()[0].get("nombre", "Usuario")
            
        return {
            "exito": True,
            "mensaje": "Inicio de sesión exitoso",
            "usuario": {
                "id": usuario["id"],
                "correo_electronico": usuario["correo_electronico"],
                "nombre": nombre
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/auth/registro", response_model=RespuestaPerfil)
async def registro_usuario(datos: AuthRegistroEntrada):
    """
    Inicia el registro: valida correo, crea usuario con contraseña hasheada, crea perfil
    y envía un código de confirmación simulado.
    """
    import requests
    import bcrypt
    try:
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

        # 1. Verificar si existe
        url_check = f"{supabase_url}/rest/v1/usuarios?correo_electronico=eq.{datos.correo}"
        res_check = requests.get(url_check, headers=headers)
        if len(res_check.json()) > 0:
            return RespuestaPerfil(exito=False, mensaje="El correo ya está registrado")

        # Hash de contraseña
        salt = bcrypt.gensalt()
        contrasena_hash = bcrypt.hashpw(datos.contrasena.encode('utf-8'), salt).decode('utf-8')

        # 2. Crear usuario
        user_url = f"{supabase_url}/rest/v1/usuarios"
        user_res = requests.post(user_url, json={
            "correo_electronico": datos.correo,
            "contrasena": contrasena_hash
        }, headers=headers)
        if user_res.status_code not in (200, 201):
            raise Exception("Error al crear usuario")
        
        usuario_id = user_res.json()[0]["id"]

        # 3. Crear perfil inicial con el nombre real
        perfil_inicial = {
            "usuario_id": usuario_id,
            "nombre": datos.nombre,
            "edad": 0,
            "sexo_biologico": "No especificado",
            "peso_actual_kg": 0,
            "estatura_cm": 0,
            "objetivo_principal": "No especificado",
            "nivel_actividad": "No especificado",
            "nivel_experiencia": "No especificado",
            "lugar_entrenamiento": "No especificado",
            "tipo_entrenamiento": "No especificado",
            "dias_disponibles_semana": 0,
            "tiempo_por_sesion_minutos": 0
        }
        
        profile_url = f"{supabase_url}/rest/v1/perfiles_usuario"
        requests.post(profile_url, json=perfil_inicial, headers=headers)

        # 4. Éxito
        return RespuestaPerfil(
            exito=True, 
            mensaje="Registro exitoso",
            datos_guardados={"usuario_id": usuario_id}
        )
    except Exception as e:
        return RespuestaPerfil(exito=False, mensaje=str(e))


@app.post("/auth/verificar-codigo")
async def verificar_codigo(datos: AuthVerificarCodigoEntrada):
    """Valida el código de 6 dígitos."""
    if datos.codigo == "123456":
        return {"exito": True, "mensaje": "Cuenta verificada correctamente"}
    else:
        return {"exito": False, "mensaje": "Código incorrecto"}


@app.patch("/perfil/actualizar", response_model=RespuestaPerfil)
async def actualizar_perfil(
    datos: ActualizarPerfilEntrada, 
    usuario_id: str = None, 
    bd: Session = Depends(obtener_bd)
):
    """
    Endpoint para guardar datos del perfil del usuario en el onboarding.
    """
    import requests

    try:
        # Priorizar id_usuario del body (HDU), luego query param, luego demo
        target_id = datos.id_usuario or usuario_id or str(USUARIO_ID)
        
        # Mapeo de campos frontend → DB
        mapeo_campos = {
            "objetivo": "objetivo_principal",
            "peso": "peso_actual_kg",
            "estatura": "estatura_cm",
            "dias_por_semana": "dias_disponibles_semana",
        }

        # Preparar datos para actualización
        datos_dict = datos.model_dump(exclude_unset=True)
        
        # Quitar id_usuario de los datos a guardar en la tabla (ya se usa para el filtro)
        if "id_usuario" in datos_dict:
            del datos_dict["id_usuario"]

        datos_actualizacion = {}

        for campo_frontend, valor in datos_dict.items():
            if valor is not None:
                campo_db = mapeo_campos.get(campo_frontend, campo_frontend)
                datos_actualizacion[campo_db] = valor

        # Obtener credenciales
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")

        # URL REST API de Supabase
        url = f"{supabase_url}/rest/v1/perfiles_usuario?usuario_id=eq.{target_id}"
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

        # PATCH request a Supabase REST API
        print(f"Backend: Enviando actualización para {target_id}: {datos_actualizacion}")
        response = requests.patch(url, json=datos_actualizacion, headers=headers)

        if response.status_code in (200, 201):
            return RespuestaPerfil(
                exito=True,
                mensaje="Perfil actualizado correctamente",
                datos_guardados=datos_dict,
            )
        else:
            return RespuestaPerfil(
                exito=False,
                mensaje=f"Error al guardar: {response.text}",
                datos_guardados=None,
            )

    except Exception as e:
        print(f"ERROR al actualizar perfil: {str(e)}")
        import traceback
        traceback.print_exc()
        return RespuestaPerfil(
            exito=False,
            mensaje=f"Error al guardar: {str(e)}",
            datos_guardados=None,
        )


@app.get("/perfil/{usuario_id}", response_model=RespuestaPerfil)
async def obtener_perfil(usuario_id: str):
    """Obtiene los datos actuales del perfil del usuario."""
    import requests
    try:
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
        url = f"{supabase_url}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario_id}&limit=1"
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}"
        }
        
        response = requests.get(url, headers=headers)
        if response.ok:
            perfiles = response.json()
            if perfiles:
                return RespuestaPerfil(exito=True, mensaje="Perfil encontrado", datos_guardados=perfiles[0])
            return RespuestaPerfil(exito=False, mensaje="Perfil no encontrado")
        else:
            return RespuestaPerfil(exito=False, mensaje=f"Error Supabase: {response.text}")
    except Exception as e:
        return RespuestaPerfil(exito=False, mensaje=str(e))


@app.post("/perfil/crear", response_model=RespuestaPerfil)
async def crear_perfil_vacio():
    """Crea un perfil inicial (UUID nuevo) para usuarios que no pasan por login/registro."""
    import requests
    import uuid
    try:
        nuevo_id = str(uuid.uuid4())
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
        url = f"{supabase_url}/rest/v1/perfiles_usuario"
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        
        perfil_vacio = {
            "usuario_id": nuevo_id,
            "nombre": "Nuevo Usuario",
            "objetivo_principal": "No especificado"
        }
        
        response = requests.post(url, json=perfil_vacio, headers=headers)
        if response.ok:
            return RespuestaPerfil(exito=True, mensaje="Perfil creado", datos_guardados={"usuario_id": nuevo_id})
        return RespuestaPerfil(exito=False, mensaje=f"Error Supabase: {response.text}")
    except Exception as e:
        return RespuestaPerfil(exito=False, mensaje=str(e))


# ==============================================================================
# ENRUTADORES (se importarán cuando estén creados)
# ==============================================================================

# app.include_router(perfil.router, prefix="/perfil", tags=["perfil"])
# app.include_router(entrenamiento.router, prefix="/entrenamiento", tags=["entrenamiento"])
# app.include_router(nutricion.router, prefix="/nutricion", tags=["nutricion"])


# ==============================================================================
# ENDPOINTS DE PROGRESO (SCRUM-12)
# ==============================================================================

@app.get("/progreso/resumen", response_model=ResumenProgresoRespuesta)
async def resumen_progreso(
    periodo: str = "semana",
    usuario_id: str = str(USUARIO_ID),
):
    """
    Retorna el resumen de progreso del usuario con métricas agregadas,
    datos para gráficos y ejercicios destacados.
    Filtrable por período: dia, semana, mes.
    """
    try:
        resultado = servicio_progreso.obtener_resumen(usuario_id, periodo)
        return ResumenProgresoRespuesta(**resultado)
    except Exception as e:
        print(f"ERROR en resumen_progreso: {e}")
        return ResumenProgresoRespuesta(
            exito=False,
            periodo=periodo,
            mensaje=f"Error al obtener resumen: {str(e)}",
        )


@app.get("/progreso/entrenamientos", response_model=HistorialEntrenamientosRespuesta)
async def historial_entrenamientos(
    periodo: str = "semana",
    usuario_id: str = str(USUARIO_ID),
):
    """
    Retorna el historial de entrenamientos completados por el usuario.
    Filtrable por período: dia, semana, mes.
    """
    try:
        resultado = servicio_progreso.obtener_entrenamientos(usuario_id, periodo)
        return HistorialEntrenamientosRespuesta(**resultado)
    except Exception as e:
        print(f"ERROR en historial_entrenamientos: {e}")
        return HistorialEntrenamientosRespuesta(
            exito=False,
            periodo=periodo,
            total=0,
            mensaje=f"Error al obtener historial: {str(e)}",
        )


@app.get("/progreso/insights", response_model=InsightsProgresoRespuesta)
async def insights_progreso(
    usuario_id: str = str(USUARIO_ID),
):
    """
    Retorna insights y recomendaciones heurísticas basadas en el progreso.
    Futuro: se reemplazará por análisis con Claude AI.
    """
    try:
        resultado = servicio_progreso.obtener_insights(usuario_id)
        return InsightsProgresoRespuesta(**resultado)
    except Exception as e:
        print(f"ERROR en insights_progreso: {e}")
        return InsightsProgresoRespuesta(
            exito=False,
            mensaje=f"Error al obtener insights: {str(e)}",
        )



# ==============================================================================
# ENDPOINTS DE MÉTRICAS FÍSICAS (SCRUM-36)
# ==============================================================================

@app.post("/metricas/registrar", response_model=RespuestaMetrica)
async def registrar_metrica(
    datos: RegistrarMetricaEntrada,
    bd: Session = Depends(obtener_bd),
):
    """
    Registra una nueva medición de métricas físicas del usuario.
    Peso corporal es obligatorio; medidas corporales son opcionales.
    """
    try:
        target_id = datos.id_usuario or str(USUARIO_ID)
        datos_dict = datos.model_dump(exclude_unset=True)
        if "id_usuario" in datos_dict:
            del datos_dict["id_usuario"]

        resultado = servicio_metricas.registrar(datos_dict, target_id)
        return RespuestaMetrica(**resultado)
    except ValueError as e:
        return RespuestaMetrica(
            exito=False,
            mensaje=f"Datos inválidos: {str(e)}",
        )
    except Exception as e:
        print(f"ERROR en registrar_metrica: {e}")
        return RespuestaMetrica(
            exito=False,
            mensaje=f"Error al registrar métrica: {str(e)}",
        )


@app.get("/metricas/historial", response_model=HistorialMetricasRespuesta)
async def historial_metricas(
    usuario_id: str = str(USUARIO_ID),
    limite: int = 50,
):
    """
    Obtiene el historial de métricas físicas del usuario,
    ordenado por fecha descendente (más reciente primero).
    """
    try:
        resultado = servicio_metricas.obtener_historial(usuario_id, limite)
        return HistorialMetricasRespuesta(**resultado)
    except Exception as e:
        print(f"ERROR en historial_metricas: {e}")
        return HistorialMetricasRespuesta(
            exito=False,
            total=0,
            mensaje=f"Error al obtener historial: {str(e)}",
        )


@app.get("/metricas/ultimo", response_model=RespuestaMetrica)
async def ultima_metrica(
    usuario_id: str = str(USUARIO_ID),
):
    """
    Obtiene el registro de métricas más reciente del usuario.
    """
    try:
        resultado = servicio_metricas.obtener_ultimo(usuario_id)
        return RespuestaMetrica(**resultado)
    except Exception as e:
        print(f"ERROR en ultima_metrica: {e}")
        return RespuestaMetrica(
            exito=False,
            mensaje=f"Error al obtener última métrica: {str(e)}",
        )


@app.delete("/metricas/{metrica_id}", response_model=RespuestaMetrica)
async def eliminar_metrica(
    metrica_id: str,
    usuario_id: str = str(USUARIO_ID),
):
    """
    Elimina un registro de métrica específico del usuario.
    """
    try:
        resultado = servicio_metricas.eliminar(metrica_id, usuario_id)
        return RespuestaMetrica(**resultado)
    except Exception as e:
        print(f"ERROR en eliminar_metrica: {e}")
        return RespuestaMetrica(
            exito=False,
            mensaje=f"Error al eliminar métrica: {str(e)}",
        )


# ==============================================================================
# ENDPOINTS DE HISTORIAL DE PLANES (SCRUM-37)
# ==============================================================================

@app.get("/planes/historial", response_model=HistorialPlanesRespuesta)
async def historial_planes(
    usuario_id: str = str(USUARIO_ID),
    limite: int = 20,
):
    """
    Retorna el historial de planes del usuario, ordenados por fecha
    descendente. Solo incluye campos de resumen (sin el JSON completo de IA).
    """
    try:
        resultado = servicio_planes.obtener_historial(usuario_id, limite)
        return HistorialPlanesRespuesta(**resultado)
    except Exception as e:
        print(f"ERROR en historial_planes: {e}")
        return HistorialPlanesRespuesta(
            exito=False,
            total=0,
            mensaje=f"Error al obtener historial: {str(e)}",
        )


@app.get("/planes/activo", response_model=DetallePlanRespuesta)
async def plan_activo(
    usuario_id: str = str(USUARIO_ID),
):
    """
    Retorna el plan activo actual del usuario.
    """
    try:
        resultado = servicio_planes.obtener_plan_activo(usuario_id)
        return DetallePlanRespuesta(**resultado)
    except Exception as e:
        print(f"ERROR en plan_activo: {e}")
        return DetallePlanRespuesta(
            exito=False,
            mensaje=f"Error al obtener plan activo: {str(e)}",
        )


@app.get("/rutina/activa", response_model=RespuestaRutinaActiva)
async def rutina_activa(
    usuario_id: str = str(USUARIO_ID),
):
    """
    Retorna la rutina de entrenamiento activa normalizada del usuario
    (semanas, días y ejercicios planificados).
    """
    try:
        resultado = servicio_planes.obtener_rutina_activa(usuario_id)
        return RespuestaRutinaActiva(**resultado)
    except Exception as e:
        print(f"ERROR en rutina_activa: {e}")
        return RespuestaRutinaActiva(
            exito=False,
            mensaje=f"Error al obtener rutina activa: {str(e)}",
        )


@app.get("/planes/{plan_id}", response_model=DetallePlanRespuesta)
async def detalle_plan(
    plan_id: str,
    usuario_id: str = str(USUARIO_ID),
):
    """
    Retorna el detalle completo de un plan específico, incluyendo
    el JSON generado por la IA (respuesta_raw_ia).
    """
    try:
        resultado = servicio_planes.obtener_detalle(plan_id, usuario_id)
        return DetallePlanRespuesta(**resultado)
    except Exception as e:
        print(f"ERROR en detalle_plan: {e}")
        return DetallePlanRespuesta(
            exito=False,
            mensaje=f"Error al obtener detalle: {str(e)}",
        )


@app.patch("/planes/{plan_id}")
async def actualizar_plan(
    plan_id: str,
    datos: ActualizarPlanEntrada,
    usuario_id: str = str(USUARIO_ID),
):
    """
    Actualiza datos específicos de un plan (ej. respuesta_raw_ia)
    """
    try:
        resultado = servicio_planes.actualizar_plan(
            plan_id, usuario_id, datos.model_dump(exclude_unset=True)
        )
        return resultado
    except Exception as e:
        print(f"ERROR en actualizar_plan: {e}")
        return {"exito": False, "mensaje": f"Error al actualizar: {str(e)}"}

@app.post("/planes/{plan_id}/evolucionar")
async def evolucionar_plan(
    plan_id: str,
    datos: EvolucionarPlanEntrada,
):
    """
    Evoluciona un plan de entrenamiento basado en el feedback del usuario ('muy_facil', 'bien', 'muy_dificil').
    """
    try:
        resultado = servicio_planes.evolucionar_plan(plan_id, datos.feedback)
        return resultado
    except Exception as e:
        print(f"ERROR en evolucionar_plan: {e}")
        return {"exito": False, "mensaje": f"Error interno: {str(e)}"}


@app.post("/plan/generar", response_model=RespuestaPlan)
async def generar_plan(usuario_id: str = str(USUARIO_ID)):
    """
    Genera un plan de entrenamiento personalizado consultando el perfil en Supabase
    y enviándolo a Claude AI.
    """
    import requests
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
        "Content-Type": "application/json",
    }

    try:
        # 1. Obtener perfil del usuario
        url = f"{supabase_url}/rest/v1/perfiles_usuario?usuario_id=eq.{usuario_id}"
        response = requests.get(url, headers=headers)
        
        if not response.ok or not response.json():
            return RespuestaPlan(exito=False, mensaje=f"No se encontró perfil para el usuario {usuario_id}")
        
        perfil = response.json()[0]
        
        # 2. Generar plan con Claude
        plan_generado = servicio_claude.generar_plan_entrenamiento(perfil)
        
        if isinstance(plan_generado, dict) and "error" in plan_generado:
            return RespuestaPlan(exito=False, mensaje=plan_generado["error"])
            
        # Desactivar planes anteriores del mismo usuario
        desactivar_url = f"{supabase_url}/rest/v1/planes?usuario_id=eq.{usuario_id}&estado=eq.activo"
        requests.patch(desactivar_url, json={"estado": "completado"}, headers=headers)

        # 3. Persistir el plan en la tabla 'planes' para el historial (SCRUM-37)
        nuevo_plan_db = {
            "usuario_id": usuario_id,
            "objetivo_seleccionado": plan_generado.get("nombre_plan", perfil.get("objetivo_principal", "Plan Personalizado")),
            "duracion_meses": 1, # Por defecto
            "estado": "activo",
            "respuesta_raw_ia": plan_generado
        }
        
        insert_url = f"{supabase_url}/rest/v1/planes"
        headers_rep = headers.copy()
        headers_rep["Prefer"] = "return=representation"
        insert_res = requests.post(insert_url, json=nuevo_plan_db, headers=headers_rep)
        
        if not insert_res.ok or not insert_res.json():
            print(f"ADVERTENCIA: No se pudo guardar el plan en el historial: {insert_res.text}")
            return RespuestaPlan(exito=True, plan=plan_generado, mensaje="Plan generado, pero no se pudo persistir en la base de datos")

        plan_creado = insert_res.json()[0]
        plan_id = plan_creado.get("id")
        print(f"[generar_plan] Plan guardado en la BD con ID: {plan_id}. Iniciando normalización...")

        # 4. Normalizar el plan generado en tablas relacionales de la BD (SCRUM-81)
        res_normalizacion = servicio_planes.normalizar_plan(plan_id, plan_generado)
        if not res_normalizacion.get("exito"):
            print(f"ADVERTENCIA: Falló la normalización del plan en la BD: {res_normalizacion.get('mensaje')}")
            return RespuestaPlan(
                exito=True, 
                plan=plan_generado, 
                mensaje=f"Plan generado y guardado, pero falló la normalización relacional: {res_normalizacion.get('mensaje')}"
            )

        print("[generar_plan] Normalización relacional completada exitosamente.")
        return RespuestaPlan(exito=True, plan=plan_generado, mensaje="Plan generado, guardado y normalizado exitosamente en la base de datos")

    except Exception as e:
        return RespuestaPlan(exito=False, mensaje=f"Error interno: {str(e)}")


# ==============================================================================
# ENDPOINTS DE REGISTRO DE ENTRENAMIENTO (SCRUM-34)
# ==============================================================================

@app.post("/entrenamientos/registrar", response_model=RespuestaRegistroSesion)
async def registrar_entrenamiento(datos: RegistrarSesionEntrada):
    """
    Registra una sesión de entrenamiento completa con sus ejercicios.
    Persiste en tablas registros_entrenamiento y registros_ejercicios.
    """
    try:
        datos_dict = datos.model_dump()
        resultado = servicio_entrenamiento.registrar_sesion(datos_dict)
        return RespuestaRegistroSesion(**resultado)
    except Exception as e:
        print(f"ERROR en registrar_entrenamiento: {e}")
        return RespuestaRegistroSesion(
            exito=False,
            mensaje=f"Error al registrar entrenamiento: {str(e)}",
        )

@app.get("/entrenamientos/ejercicios/{nombre_ejercicio}/ultimo-peso", response_model=RespuestaUltimoPeso)
async def obtener_ultimo_peso(nombre_ejercicio: str, usuario_id: str = str(USUARIO_ID)):
    """
    Obtiene el último peso levantado por el usuario para un ejercicio específico.
    """
    try:
        resultado = servicio_entrenamiento.obtener_ultimo_peso(usuario_id, nombre_ejercicio)
        return RespuestaUltimoPeso(**resultado)
    except Exception as e:
        print(f"ERROR en obtener_ultimo_peso: {e}")
        return RespuestaUltimoPeso(exito=False)


# ==============================================================================
# ENDPOINTS DE CHAT CON COACH IA (SCRUM-32)
# ==============================================================================

@app.post("/coach/mensaje", response_model=RespuestaMensaje)
async def coach_mensaje(datos: EnviarMensajeEntrada):
    """
    Envía un mensaje al coach IA y recibe una respuesta contextual.
    Usa LangChain + ChatAnthropic + RAG para respuestas personalizadas.
    """
    try:
        historial = [m.model_dump() for m in datos.historial]
        contexto = datos.contexto.model_dump() if datos.contexto else None

        resultado = servicio_chat.procesar_mensaje(
            usuario_id=datos.usuario_id,
            mensaje=datos.mensaje,
            historial=historial,
            contexto=contexto,
        )
        return RespuestaMensaje(**resultado)
    except Exception as e:
        print(f"ERROR en coach_mensaje: {e}")
        return RespuestaMensaje(
            exito=False,
            mensaje=f"Error al procesar mensaje: {str(e)}",
        )


# ==============================================================================
# ENDPOINTS DE EJERCICIOS Y ALTERNATIVAS (SCRUM-29)
# ==============================================================================

@app.get("/ejercicios/alternativas", response_model=RespuestaAlternativas)
async def alternativas_ejercicio(
    grupo_muscular: str,
    ejercicio_actual: str = "",
    usuario_id: str = "",
):
    """
    Obtiene ejercicios alternativos para un grupo muscular dado.
    Busca primero en el catálogo de Supabase, luego usa LangChain como fallback.
    """
    try:
        resultado = servicio_ejercicios.obtener_alternativas(
            grupo_muscular=grupo_muscular,
            ejercicio_actual=ejercicio_actual,
            usuario_id=usuario_id or None,
        )
        return RespuestaAlternativas(**resultado)
    except Exception as e:
        print(f"ERROR en alternativas_ejercicio: {e}")
        return RespuestaAlternativas(
            exito=False,
            mensaje=f"Error al obtener alternativas: {str(e)}",
        )


@app.get("/ejercicios/buscar")
async def buscar_ejercicios(q: str = ""):
    """
    Busca ejercicios en el catálogo de Supabase.
    Si no hay query q, retorna una lista por defecto de los primeros 20 ejercicios.
    """
    import requests
    try:
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_CLAVE_SERVICIO")
        headers = {
            "apikey": supabase_key,
            "Authorization": f"Bearer {supabase_key}"
        }
        if not q:
            url = f"{supabase_url}/rest/v1/ejercicios_catalogo?select=nombre,grupo_muscular&limit=30"
        else:
            url = f"{supabase_url}/rest/v1/ejercicios_catalogo?nombre=ilike.*{q}*&select=nombre,grupo_muscular&limit=20"
            
        res = requests.get(url, headers=headers)
        if res.ok:
            return {"exito": True, "resultados": res.json()}
        else:
            return {"exito": False, "resultados": [], "mensaje": f"Supabase error: {res.text}"}
    except Exception as e:
        return {"exito": False, "resultados": [], "mensaje": str(e)}


@app.post("/notificaciones/enviar")
async def enviar_notificacion_broadcast(datos: dict):
    """
    Simula la difusión de una notificación push en tiempo real.
    Acepta un mensaje, un tipo y un delay opcional.
    """
    try:
        titulo = datos.get("titulo", "FitAI Coach")
        mensaje = datos.get("mensaje", "¡Es hora de entrenar! Mantén tu racha activa.")
        tipo = datos.get("tipo", "entrenamiento")
        delay = int(datos.get("delay", 0))
        
        return {
            "exito": True,
            "mensaje": f"Notificación broadcast enviada con éxito.",
            "datos": {
                "titulo": titulo,
                "mensaje": mensaje,
                "tipo": tipo,
                "delay_segundos": delay
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==============================================================================
# ENDPOINTS DE CONFIGURACIÓN (SCRUM-39 / SCRUM-40)
# ==============================================================================

@app.get("/configuracion/{usuario_id}", response_model=RespuestaConfiguracion)
async def obtener_configuracion(usuario_id: str):
    """
    Retorna la configuración del usuario (unidad de peso, notificaciones).
    Si no existe, crea una con valores por defecto.
    """
    try:
        resultado = servicio_configuracion.obtener(usuario_id)
        return RespuestaConfiguracion(**resultado)
    except Exception as e:
        print(f"ERROR en obtener_configuracion: {e}")
        return RespuestaConfiguracion(
            exito=False,
            mensaje=f"Error al obtener configuración: {str(e)}",
        )


@app.patch("/configuracion/{usuario_id}", response_model=RespuestaConfiguracion)
async def actualizar_configuracion(
    usuario_id: str,
    datos: ConfiguracionEntrada,
):
    """
    Actualiza la configuración del usuario.
    Campos opcionales: unidad_peso, notificaciones_activas,
    recordatorios_entrenamiento, recordatorios_alimentacion,
    recordatorios_seguimiento.
    """
    try:
        datos_dict = datos.model_dump(exclude_unset=True)
        resultado = servicio_configuracion.actualizar(usuario_id, datos_dict)
        return RespuestaConfiguracion(**resultado)
    except Exception as e:
        print(f"ERROR en actualizar_configuracion: {e}")
        return RespuestaConfiguracion(
            exito=False,
            mensaje=f"Error al actualizar configuración: {str(e)}",
        )


# ==============================================================================
# ENDPOINTS DE GESTIÓN DE CUENTA (SCRUM-41)
# ==============================================================================

@app.delete("/cuenta/{usuario_id}", response_model=RespuestaCuenta)
async def eliminar_cuenta(usuario_id: str):
    """
    Elimina la cuenta del usuario y todos sus datos asociados.
    Requiere confirmación previa desde el frontend.
    ON DELETE CASCADE en la BD se encarga de borrar todos los registros relacionados.
    """
    try:
        resultado = servicio_cuenta.eliminar_cuenta(usuario_id)
        return RespuestaCuenta(**resultado)
    except Exception as e:
        print(f"ERROR en eliminar_cuenta: {e}")
        return RespuestaCuenta(
            exito=False,
            mensaje=f"Error al eliminar cuenta: {str(e)}",
        )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.principal:app",
        host="0.0.0.0",
        port=PUERTO_APP,
        reload=(ENTORNO_APP == "desarrollo"),
        log_level="info",
    )

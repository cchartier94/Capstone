/**
 * @file servicio-notificaciones.js
 * @description Servicio pub/sub para simular y gestionar notificaciones in-app y del sistema (navegador).
 */

let oyentes = [];

const servicioNotificaciones = {
  /**
   * Se suscribe a los cambios de notificaciones.
   * @param {function} callback - Función que se llama al recibir una notificación.
   * @returns {function} Función para desuscribirse.
   */
  suscribir: (callback) => {
    oyentes.push(callback);
    return () => {
      oyentes = oyentes.filter(o => o !== callback);
    };
  },

  /**
   * Solicita permisos de notificación al navegador.
   * @returns {Promise<boolean>} True si se concedieron los permisos.
   */
  solicitarPermisoNavegador: async () => {
    if (typeof Notification === 'undefined') return false;
    try {
      const permiso = await Notification.requestPermission();
      return permiso === 'granted';
    } catch (e) {
      console.warn('Error al solicitar permisos de notificación:', e);
      return false;
    }
  },

  /**
   * Muestra una notificación inmediata (in-app y/o navegador).
   * @param {string} titulo - Título de la notificación.
   * @param {string} mensaje - Cuerpo de la notificación.
   * @param {string} [tipo='info'] - Tipo: 'entrenamiento', 'seguimiento', 'info'.
   */
  mostrar: (titulo, mensaje, tipo = 'info') => {
    // 1. Notificar a los oyentes de la app (in-app toast)
    oyentes.forEach(callback => {
      try {
        callback(titulo, mensaje, tipo);
      } catch (err) {
        console.error('Error en callback de notificación:', err);
      }
    });

    // 2. Intentar mostrar notificación nativa del navegador
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try {
        new Notification(titulo, {
          body: mensaje,
          icon: 'https://cdn-icons-png.flaticon.com/512/3661/3661391.png' // Ícono genérico fitness para presentación
        });
      } catch (err) {
        console.warn('No se pudo enviar notificación nativa:', err);
      }
    }
  },

  /**
   * Programa una notificación con un retardo específico en segundos.
   * @param {string} titulo
   * @param {string} mensaje
   * @param {string} tipo
   * @param {number} segundos
   */
  mostrarConRetraso: (titulo, mensaje, tipo = 'info', segundos = 5) => {
    setTimeout(() => {
      servicioNotificaciones.mostrar(titulo, mensaje, tipo);
    }, segundos * 1000);
  },

  /**
   * Envía una notificación simulando un broadcast masivo desde el servidor backend.
   * @param {string} titulo
   * @param {string} mensaje
   * @param {string} tipo
   * @param {number} delay_segundos
   */
  enviarBroadcastServidor: async (titulo, mensaje, tipo = 'entrenamiento', delay_segundos = 5) => {
    try {
      const BACKEND_URL = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';
      const res = await fetch(`${BACKEND_URL}/notificaciones/enviar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ titulo, mensaje, tipo, delay: delay_segundos })
      });
      
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      
      // Programamos localmente el disparo para la simulación
      servicioNotificaciones.mostrarConRetraso(titulo, mensaje, tipo, delay_segundos);
      return data;
    } catch (e) {
      console.warn('Error enviando broadcast al servidor:', e.message);
      // Fallback local instantáneo si el servidor no responde
      servicioNotificaciones.mostrarConRetraso(titulo, mensaje, tipo, delay_segundos);
      return { exito: true, mensaje: 'Broadcast simulado localmente' };
    }
  }
};

export default servicioNotificaciones;

/**
 * @file servicio-progreso.js
 * @description Servicio para consultar el progreso del usuario (SCRUM-12).
 *              Usa fetch nativo. El compañero de frontend conecta su UI a estas funciones.
 *
 * Endpoints backend:
 *   GET /progreso/resumen?periodo=semana         → obtenerResumen(periodo, usuarioId)
 *   GET /progreso/entrenamientos?periodo=semana   → obtenerEntrenamientos(periodo, usuarioId)
 *   GET /progreso/insights                        → obtenerInsights(usuarioId)
 */

/** URL del backend; fallback a localhost para desarrollo fuera de Docker. */
const BACKEND_URL = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';

const servicioProgreso = {
  /**
   * Obtiene el resumen de progreso con métricas agregadas, datos de gráfico
   * y ejercicios destacados.
   *
   * @param {string} [periodo='semana'] - Período: 'dia', 'semana', 'mes'
   * @param {string} usuarioId - UUID del usuario.
   * @returns {Promise<{exito, periodo, metricas[], grafico_actividad[], ejercicios_destacados[]}>}
   */
  obtenerResumen: async (periodo = 'semana', usuarioId) => {
    try {
      const params = new URLSearchParams({ periodo });
      if (usuarioId) params.append('usuario_id', usuarioId);

      const response = await fetch(
        `${BACKEND_URL}/progreso/resumen?${params}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error obteniendo resumen:', e.message);
      return { exito: false, periodo, metricas: [], grafico_actividad: [], ejercicios_destacados: [] };
    }
  },

  /**
   * Obtiene el historial de entrenamientos completados.
   *
   * @param {string} [periodo='semana'] - Período: 'dia', 'semana', 'mes'
   * @param {string} usuarioId - UUID del usuario.
   * @returns {Promise<{exito, periodo, total, entrenamientos[]}>}
   */
  obtenerEntrenamientos: async (periodo = 'semana', usuarioId) => {
    try {
      const params = new URLSearchParams({ periodo });
      if (usuarioId) params.append('usuario_id', usuarioId);

      const response = await fetch(
        `${BACKEND_URL}/progreso/entrenamientos?${params}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error obteniendo entrenamientos:', e.message);
      return { exito: false, periodo, total: 0, entrenamientos: [] };
    }
  },

  /**
   * Obtiene insights y recomendaciones basadas en el progreso.
   *
   * @param {string} usuarioId - UUID del usuario.
   * @returns {Promise<{exito, insights[]}>}
   */
  obtenerInsights: async (usuarioId) => {
    try {
      const params = new URLSearchParams();
      if (usuarioId) params.append('usuario_id', usuarioId);

      const response = await fetch(
        `${BACKEND_URL}/progreso/insights?${params}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error obteniendo insights:', e.message);
      return { exito: false, insights: [] };
    }
  },
};

export default servicioProgreso;

const BACKEND_URL = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';

// TODO: eliminar fallback cuando Jean Paul implemente POST /coach/mensaje
const servicioCoach = {
  enviarMensaje: async (usuarioId, mensaje, historial = [], contextoInicial = null) => {
    try {
      const body = { usuario_id: usuarioId, mensaje, historial };
      if (contextoInicial) body.contexto = contextoInicial;

      const response = await fetch(`${BACKEND_URL}/coach/mensaje`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (e) {
      console.warn('servicioCoach.enviarMensaje:', e.message);
      return {
        exito: false,
        respuesta: null,
        mensaje: 'El coach no está disponible en este momento. Intenta más tarde.',
      };
    }
  },
};

export default servicioCoach;

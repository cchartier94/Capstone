/**
 * @file servicio-metricas.js
 * @description Servicio para registrar y consultar métricas físicas del usuario (SCRUM-36).
 *              Usa fetch nativo. El compañero de frontend conecta su UI a estas funciones.
 *
 * Endpoints backend:
 *   POST   /metricas/registrar   → registrarMetrica(datos, usuarioId)
 *   GET    /metricas/historial   → obtenerHistorial(usuarioId, limite)
 *   GET    /metricas/ultimo      → obtenerUltimaMetrica(usuarioId)
 *   DELETE /metricas/{id}        → eliminarMetrica(metricaId, usuarioId)
 */

/** URL del backend; fallback a localhost para desarrollo fuera de Docker. */
const BACKEND_URL = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';

const servicioMetricas = {
  /**
   * Registra una nueva medición de métricas físicas.
   *
   * @param {object} datos - Campos de la métrica:
   *   @param {number}  datos.peso_corporal_kg    - (Obligatorio) Peso en kg
   *   @param {string}  [datos.fecha_registro]     - Fecha ISO (YYYY-MM-DD), default = hoy
   *   @param {number}  [datos.medida_cintura_cm]  - Cintura en cm
   *   @param {number}  [datos.medida_pecho_cm]    - Pecho en cm
   *   @param {number}  [datos.medida_cadera_cm]   - Cadera en cm
   *   @param {number}  [datos.medida_brazos_cm]   - Brazos en cm
   *   @param {number}  [datos.medida_piernas_cm]  - Piernas en cm
   * @param {string} usuarioId - UUID del usuario.
   * @returns {Promise<{exito: boolean, mensaje: string, datos: object|null}>}
   */
  registrarMetrica: async (datos, usuarioId) => {
    try {
      const response = await fetch(`${BACKEND_URL}/metricas/registrar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id_usuario: usuarioId,
          ...datos,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error registrando métrica:', e.message);
      return { exito: false, mensaje: e.message, datos: null };
    }
  },

  /**
   * Obtiene el historial de métricas físicas del usuario.
   * Ordenado por fecha descendente (más reciente primero).
   *
   * @param {string} usuarioId - UUID del usuario.
   * @param {number} [limite=50] - Máximo de registros a obtener.
   * @returns {Promise<{exito: boolean, total: number, registros: Array}>}
   */
  obtenerHistorial: async (usuarioId, limite = 50) => {
    try {
      const params = new URLSearchParams({
        usuario_id: usuarioId,
        limite: limite.toString(),
      });

      const response = await fetch(
        `${BACKEND_URL}/metricas/historial?${params}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error obteniendo historial:', e.message);
      return { exito: false, total: 0, registros: [] };
    }
  },

  /**
   * Obtiene la última métrica registrada del usuario.
   *
   * @param {string} usuarioId - UUID del usuario.
   * @returns {Promise<{exito: boolean, mensaje: string, datos: object|null}>}
   */
  obtenerUltimaMetrica: async (usuarioId) => {
    try {
      const response = await fetch(
        `${BACKEND_URL}/metricas/ultimo?usuario_id=${usuarioId}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error obteniendo última métrica:', e.message);
      return { exito: false, mensaje: e.message, datos: null };
    }
  },

  /**
   * Elimina un registro de métrica específico.
   *
   * @param {string} metricaId - UUID de la métrica a eliminar.
   * @param {string} usuarioId - UUID del usuario propietario.
   * @returns {Promise<{exito: boolean, mensaje: string}>}
   */
  eliminarMetrica: async (metricaId, usuarioId) => {
    try {
      const response = await fetch(
        `${BACKEND_URL}/metricas/${metricaId}?usuario_id=${usuarioId}`,
        { method: 'DELETE' }
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error eliminando métrica:', e.message);
      return { exito: false, mensaje: e.message };
    }
  },
};

export default servicioMetricas;

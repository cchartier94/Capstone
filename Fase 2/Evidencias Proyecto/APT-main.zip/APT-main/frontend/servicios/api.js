/**
 * @file api.js
 * @description Cliente HTTP base (axios) para comunicación con el backend FastAPI.
 *              Todos los servicios deben importar este cliente en lugar de crear instancias propias.
 */

import axios from 'axios';

import { Platform } from 'react-native';

/** Fallback inteligente según la plataforma */
const fallbackUrl = Platform.OS === 'android' ? 'http://10.0.2.2:8000' : 'http://localhost:8000';

/** URL base del backend, inyectada por variable de entorno Expo. */
export const urlApiBase = process.env.EXPO_PUBLIC_URL_API || fallbackUrl;

/**
 * Instancia axios preconfigurada con baseURL, timeout de 30 s
 * y Content-Type JSON por defecto.
 */
const cliente = axios.create({
  baseURL: urlApiBase,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export default cliente;

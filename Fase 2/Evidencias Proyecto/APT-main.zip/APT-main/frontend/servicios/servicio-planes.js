/**
 * @file servicio-planes.js
 * @description Servicio para consultar el historial de planes del usuario (SCRUM-37).
 *              Usa fetch nativo. El compañero de frontend conecta su UI a estas funciones.
 *
 * Endpoints backend:
 *   GET /planes/historial               → obtenerHistorial(usuarioId, limite)
 *   GET /planes/activo                  → obtenerPlanActivo(usuarioId)
 *   GET /planes/{plan_id}               → obtenerDetalle(planId, usuarioId)
 */

import { urlApiBase } from './api';

const BACKEND_URL = urlApiBase;

const servicioPlanes = {
  /**
   * Obtiene el historial de planes del usuario.
   * Ordenado por fecha descendente (más reciente primero).
   * Solo incluye campos de resumen (sin JSON completo de IA).
   *
   * @param {string} usuarioId - UUID del usuario.
   * @param {number} [limite=20] - Máximo de planes a obtener.
   * @returns {Promise<{exito: boolean, total: number, planes: Array}>}
   */
  obtenerHistorial: async (usuarioId, limite = 20) => {
    try {
      const params = new URLSearchParams({
        usuario_id: usuarioId,
        limite: limite.toString(),
      });

      const response = await fetch(
        `${BACKEND_URL}/planes/historial?${params}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      throw new Error(`Error obteniendo historial de planes: ${e.message}`);
    }
  },

  /**
   * Obtiene el plan activo actual del usuario.
   *
   * @param {string} usuarioId - UUID del usuario.
   * @returns {Promise<{exito: boolean, plan: object|null, mensaje: string}>}
   */
  obtenerPlanActivo: async (usuarioId) => {
    try {
      const response = await fetch(
        `${BACKEND_URL}/planes/activo?usuario_id=${usuarioId}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      throw new Error(`Error obteniendo plan activo: ${e.message}`);
    }
  },

  /**
   * Obtiene el detalle completo de un plan específico,
   * incluyendo el JSON generado por la IA.
   *
   * @param {string} planId - UUID del plan.
   * @param {string} usuarioId - UUID del usuario propietario.
   * @returns {Promise<{exito: boolean, plan: object|null, mensaje: string}>}
   */
  obtenerDetalle: async (planId, usuarioId) => {
    try {
      const response = await fetch(
        `${BACKEND_URL}/planes/${planId}?usuario_id=${usuarioId}`
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      throw new Error(`Error obteniendo detalle de plan: ${e.message}`);
    }
  },

  /**
   * Actualiza datos específicos de un plan (como respuesta_raw_ia)
   *
   * @param {string} planId - UUID del plan.
   * @param {string} usuarioId - UUID del usuario.
   * @param {object} datos - Datos a actualizar.
   * @returns {Promise<{exito: boolean, mensaje: string}>}
   */
  actualizarPlan: async (planId, usuarioId, datos) => {
    try {
      const params = new URLSearchParams({ usuario_id: usuarioId });
      const response = await fetch(
        `${BACKEND_URL}/planes/${planId}?${params}`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(datos),
        }
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      throw new Error(`Error actualizando plan: ${e.message}`);
    }
  },

  evolucionarPlan: async (planId, feedback) => {
    try {
      const response = await fetch(`${BACKEND_URL}/planes/${planId}/evolucionar`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ feedback }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (e) {
      throw new Error(`Error evolucionando plan: ${e.message}`);
    }
  },
};

export default servicioPlanes;

/**
 * @file servicio-configuracion.js
 * @description Servicio de configuración del usuario (SCRUM-39/40).
 *              Persiste en el backend vía API REST y usa AsyncStorage como cache/fallback.
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const URL_API = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';
const CLAVE = '@FitAI:configuracion';

const DEFAULTS = {
  notificaciones: {
    entrenamiento: true,
    seguimiento: true,
  },
  general: {
    unidadPeso: 'kg',
  },
};

const servicioConfiguracion = {
  /**
   * Obtiene la configuración: intenta desde API, fallback a AsyncStorage.
   * @param {string} [usuarioId] - ID del usuario para obtener de la API.
   */
  async obtener(usuarioId) {
    // Si tenemos ID, intentar desde API
    if (usuarioId) {
      try {
        const res = await fetch(`${URL_API}/configuracion/${usuarioId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.exito && data.configuracion) {
            const config = data.configuracion;
            const resultado = {
              notificaciones: {
                entrenamiento: config.recordatorios_entrenamiento ?? true,
                seguimiento: config.recordatorios_seguimiento ?? true,
              },
              general: {
                unidadPeso: config.unidad_peso || 'kg',
              },
            };
            // Cachear en AsyncStorage
            await AsyncStorage.setItem(CLAVE, JSON.stringify(resultado));
            return resultado;
          }
        }
      } catch (e) {
        console.warn('API configuración no disponible, usando cache:', e.message);
      }
    }

    // Fallback: AsyncStorage
    try {
      const json = await AsyncStorage.getItem(CLAVE);
      if (!json) return { ...DEFAULTS, notificaciones: { ...DEFAULTS.notificaciones }, general: { ...DEFAULTS.general } };
      const guardado = JSON.parse(json);
      return {
        notificaciones: { ...DEFAULTS.notificaciones, ...guardado.notificaciones },
        general: { ...DEFAULTS.general, ...guardado.general },
      };
    } catch {
      return { notificaciones: { ...DEFAULTS.notificaciones }, general: { ...DEFAULTS.general } };
    }
  },

  /**
   * Guarda cambios de configuración: persiste en API y AsyncStorage.
   * @param {object} cambios - Cambios parciales { notificaciones, general }.
   * @param {string} [usuarioId] - ID del usuario para guardar en API.
   */
  async guardar(cambios, usuarioId) {
    // Actualizar AsyncStorage primero (respuesta inmediata)
    try {
      const actual = await servicioConfiguracion.obtener();
      const nuevo = {
        notificaciones: { ...actual.notificaciones, ...(cambios.notificaciones || {}) },
        general: { ...actual.general, ...(cambios.general || {}) },
      };
      await AsyncStorage.setItem(CLAVE, JSON.stringify(nuevo));
    } catch {
      // Ignorar error de AsyncStorage
    }

    // Persistir en API si tenemos ID
    if (usuarioId) {
      try {
        // Mapear formato frontend → formato API (campos de BD)
        const datosApi = {};

        if (cambios.general?.unidadPeso !== undefined) {
          datosApi.unidad_peso = cambios.general.unidadPeso;
        }
        if (cambios.notificaciones?.entrenamiento !== undefined) {
          datosApi.recordatorios_entrenamiento = cambios.notificaciones.entrenamiento;
        }
        if (cambios.notificaciones?.seguimiento !== undefined) {
          datosApi.recordatorios_seguimiento = cambios.notificaciones.seguimiento;
        }

        // Si alguna notificación cambió, actualizar también notificaciones_activas
        if (cambios.notificaciones) {
          const actual = await servicioConfiguracion.obtener();
          const merged = { ...actual.notificaciones, ...cambios.notificaciones };
          datosApi.notificaciones_activas =
            merged.entrenamiento || merged.seguimiento;
        }

        if (Object.keys(datosApi).length > 0) {
          await fetch(`${URL_API}/configuracion/${usuarioId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datosApi),
          });
        }
      } catch (e) {
        console.warn('Error guardando configuración en API:', e.message);
      }
    }

    return { exito: true };
  },
};

export default servicioConfiguracion;

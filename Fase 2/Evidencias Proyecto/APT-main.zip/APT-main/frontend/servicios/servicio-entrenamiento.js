const BACKEND_URL = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';

// TODO: eliminar mock fallback cuando Jean Paul implemente POST /entrenamientos/registrar
const servicioEntrenamiento = {
  buscarEjercicios: async (query = '') => {
    try {
      const response = await fetch(`${BACKEND_URL}/ejercicios/buscar?q=${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (e) {
      console.warn('buscarEjercicios:', e.message);
      return { exito: false, resultados: [] };
    }
  },

  registrarSesion: async (usuarioId, ejercicios, fecha) => {
    try {
      const response = await fetch(`${BACKEND_URL}/entrenamientos/registrar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          usuario_id: usuarioId,
          fecha: fecha || new Date().toISOString().split('T')[0],
          ejercicios,
        }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (e) {
      console.warn('registrarSesion error:', e.message);
      return { exito: false, mensaje: `Error de conexión: ${e.message}`, sesion_id: null };
    }
  },

  obtenerUltimoPeso: async (nombreEjercicio, usuarioId = 'USER_TEST_123') => {
    try {
      const response = await fetch(`${BACKEND_URL}/entrenamientos/ejercicios/${encodeURIComponent(nombreEjercicio)}/ultimo-peso?usuario_id=${usuarioId}`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (e) {
      console.warn('obtenerUltimoPeso:', e.message);
      return { exito: false, peso_kg: null, fecha: null };
    }
  },

  obtenerAlternativas: async (grupoMuscular, ejercicioActual, usuarioId = 'USER_TEST_123') => {
    try {
      const params = new URLSearchParams({
        grupo_muscular: grupoMuscular,
        ejercicio_actual: ejercicioActual || '',
        usuario_id: usuarioId
      });
      const response = await fetch(`${BACKEND_URL}/ejercicios/alternativas?${params.toString()}`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (e) {
      console.warn('obtenerAlternativas:', e.message);
      return { exito: false, alternativas: [] };
    }
  },
};

export default servicioEntrenamiento;

/**
 * @file servicio-cuenta.js
 * @description Servicio de gestión de cuenta (SCRUM-41).
 *              Maneja cierre de sesión y eliminación de cuenta.
 */

const URL_API = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';

const servicioCuenta = {
  /**
   * Elimina la cuenta del usuario en el backend.
   * ON DELETE CASCADE en la BD borra todos los datos asociados.
   *
   * @param {string} usuarioId - ID del usuario a eliminar.
   * @returns {Promise<{exito: boolean, mensaje?: string}>}
   */
  async eliminarCuenta(usuarioId) {
    try {
      const res = await fetch(`${URL_API}/cuenta/${usuarioId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.mensaje || `Error del servidor: ${res.status}`);
      }

      const data = await res.json();
      return { exito: data.exito, mensaje: data.mensaje };
    } catch (e) {
      console.error('Error eliminando cuenta:', e.message);
      return { exito: false, mensaje: e.message };
    }
  },
};

export default servicioCuenta;

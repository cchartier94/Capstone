/**
 * @file servicio-perfil.js
 * @description Servicio para crear y actualizar el perfil del usuario en el backend FastAPI.
 *              Usa fetch nativo para evitar dependencia de axios en este módulo.
 */

import { urlApiBase } from './api';

const BACKEND_URL = urlApiBase;

const servicioPerfil = {
  /**
   * Crea un perfil vacío en el backend y devuelve el ID generado.
   *
   * @returns {Promise<string>} ID del usuario 
   */
  crearPerfil: async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/perfil/crear`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      if (data.exito && data.datos_guardados && data.datos_guardados.usuario_id) {
        return data.datos_guardados.usuario_id;
      }
      throw new Error('Respuesta inválida');
    } catch (e) {
      throw new Error(`Error de red o servidor: ${e.message}`);
    }
  },

  /**
   * Actualiza uno o más campos del perfil existente en el backend.
   * Si el backend no está disponible, registra los datos en consola y continúa.
   *
   * @param {object} campos    - Objeto con los campos a actualizar (e.g. { nombre, edad }).
   * @param {string} usuarioId - ID del usuario propietario del perfil.
   * @returns {Promise<object>} Respuesta del backend
   */
  actualizarCampo: async (campos, usuarioId) => {
    try {
      const url = `${BACKEND_URL}/perfil/actualizar`;
      
      // Incluir el ID del usuario en el cuerpo
      const cuerpo = {
        id_usuario: usuarioId,
        ...campos,
      };

      const response = await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cuerpo),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      return data;
    } catch (e) {
      throw new Error(`Error de red o servidor: ${e.message}`);
    }
  },

  /**
   * Obtiene los datos del perfil del backend.
   *
   * @param {string} usuarioId - ID del usuario.
   * @returns {Promise<object>} Datos del perfil.
   */
  obtenerPerfil: async (usuarioId) => {
    try {
      const response = await fetch(`${BACKEND_URL}/perfil/${usuarioId}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      return data;
    } catch (e) {
      console.warn('Error obteniendo perfil:', e.message);
      return { exito: false, mensaje: e.message };
    }
  },
};

export default servicioPerfil;

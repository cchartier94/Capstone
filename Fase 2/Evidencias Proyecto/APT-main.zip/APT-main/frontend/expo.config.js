/**
 * @file expo.config.js
 * @description Configuración mínima de Expo
 *
 * @author Carlos Chartier
 */

module.exports = {
  expo: {
    name: 'FitAI',
    slug: 'fitai',
    version: '1.0.0',
    orientation: 'portrait',
    userInterfaceStyle: 'dark',
    backgroundColor: '#1A1A2E',
  },
};

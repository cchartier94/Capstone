/**
 * @file App.js
 * @description Componente raíz. Maneja la navegación global entre pantallas
 *              mediante un estado `pantalla` (stack manual sin expo-router).
 *
 * Flujo: bienvenida → registro/login → onboarding → generando-plan → dashboard
 */

import { SafeAreaProvider } from 'react-native-safe-area-context'; // proveedor de insets seguros para barra de estado
import { useFonts } from 'expo-font'; // hook para cargar fuentes personalizadas 
import * as SplashScreen from 'expo-splash-screen'; // controla cuándo se oculta la pantalla de splash
import { useEffect, useState } from 'react'; // hooks de efecto y estado local
import Onboarding from './onboarding'; // flujo completo de onboarding
import Bienvenida from './pantallas/Bienvenida'; // pantalla de landing inicial
import Login from './pantallas/Login'; // pantalla de inicio de sesión
import Registro from './pantallas/Registro'; // pantalla de creación de cuenta
import RecuperarContrasena from './pantallas/RecuperarContrasena'; // pantalla de recuperación de contraseña
import GenerandoPlan from './pantallas/GenerandoPlan'; // pantalla de carga mientras Claude genera el plan
import Dashboard from './pantallas/Dashboard'; // pantalla principal con el plan generado
import NotificacionToast from './componentes/NotificacionToast'; // tostada global de notificaciones
import servicioPlanes from './servicios/servicio-planes'; // servicio para consultar planes existentes
import { ActivityIndicator, View, Alert, Platform } from 'react-native';
import { COLORES } from './constantes/colores';
import * as NavigationBar from 'expo-navigation-bar';
import { StatusBar } from 'expo-status-bar';

// Mantiene el splash visible hasta que las fuentes terminen de cargar
SplashScreen.preventAutoHideAsync();

/**
 * Componente raíz de la aplicación.
 * Carga las fuentes Inter y renderiza condicionalmente la pantalla activa.
 *
 * @returns {JSX.Element|null} La pantalla activa, o null mientras cargan las fuentes.
 */
export default function App() {
  /** Pantalla activa del stack manual de navegación. */
  const [pantalla, setPantalla] = useState('bienvenida');
  
  /** Datos del usuario actual (nombre, correo, etc.) */
  const [usuario, setUsuario] = useState({ nombre: '', correo: '', id: '' });
  const [plan, setPlan] = useState(null);
  const [verificandoSesion, setVerificandoSesion] = useState(false);

  const [fontsLoaded] = useFonts({
    Inter_400Regular: require('@expo-google-fonts/inter').Inter_400Regular,
    Inter_500Medium: require('@expo-google-fonts/inter').Inter_500Medium,
    Inter_600SemiBold: require('@expo-google-fonts/inter').Inter_600SemiBold,
    Inter_700Bold: require('@expo-google-fonts/inter').Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded) {
      SplashScreen.hideAsync();
      if (Platform.OS === 'android') {
        NavigationBar.setVisibilityAsync('hidden');
        NavigationBar.setBehaviorAsync('overlay-swipe');
      }
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) return null;

  return (
    <SafeAreaProvider>
      <StatusBar hidden={true} />
      <NotificacionToast />
      {verificandoSesion && (
        <View style={{ flex: 1, backgroundColor: COLORES.oscuro, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={COLORES.primario} />
        </View>
      )}
      {!verificandoSesion && (
        <>
      {pantalla === 'bienvenida' && (
        <Bienvenida
          onCrearCuenta={() => setPantalla('registro')}
          onIniciarSesion={() => setPantalla('login')}
        />
      )}
      {pantalla === 'login' && (
        <Login
          onIrRegistro={() => setPantalla('registro')}
          onIrRecuperar={() => setPantalla('recuperar')}
          onLoginExitoso={async (datos) => {
            setVerificandoSesion(true);
            try {
              // En una app real, el ID vendría del login. Para demo usamos el UUID fijo del backend.
              const demoId = '11111111-1111-1111-1111-111111111111';
              const userConId = { ...datos, id: datos.id || demoId };
              setUsuario(userConId);

              // Verificar si ya tiene un plan activo
              const res = await servicioPlanes.obtenerPlanActivo(userConId.id);
              
              if (res.exito && res.plan) {
                let planNormalizado = res.plan;
                if (planNormalizado.respuesta_raw_ia) {
                  planNormalizado = { ...planNormalizado, ...planNormalizado.respuesta_raw_ia };
                }
                setPlan(planNormalizado);
                setPantalla('dashboard');
              } else if (!res.exito) {
                Alert.alert('Error de Conexión', 'No se pudo conectar al servidor o a la base de datos. Por favor, verifica tu conexión e intenta más tarde.');
                // Permanecer en la pantalla de login
              } else {
                
                // Intentar cargar datos del perfil para pre-llenar onboarding
                const { obtenerPerfil } = require('./servicios/servicio-perfil').default;
                const resPerfil = await obtenerPerfil(userConId.id);
                
                if (!resPerfil.exito) {
                  Alert.alert('Error de Conexión', 'No se pudo conectar al servidor o a la base de datos.');
                  // Permanecer en la pantalla de login
                } else {
                  if (resPerfil.exito && resPerfil.datos_guardados) {
                    const datosPerfil = resPerfil.datos_guardados;
                    setUsuario({
                      ...userConId,
                      nombre: datosPerfil.nombre || userConId.nombre,
                      edad: datosPerfil.edad ? String(datosPerfil.edad) : '',
                      sexo: datosPerfil.sexo_biologico || null,
                      objetivo: datosPerfil.objetivo_principal || null,
                      peso: datosPerfil.peso_actual_kg ? String(datosPerfil.peso_actual_kg) : '',
                      estatura: datosPerfil.estatura_cm ? String(datosPerfil.estatura_cm) : '',
                      nivelActividad: datosPerfil.nivel_actividad || null,
                      nivelExperiencia: datosPerfil.nivel_experiencia || null,
                      dias: datosPerfil.dias_disponibles_semana || null,
                      minutos: datosPerfil.tiempo_por_sesion_minutos || null,
                    });
                  }
                  
                  setPantalla('onboarding');
                }
              }
            } catch (e) {
              Alert.alert('Error Crítico', 'No se pudo verificar tu estado con el servidor. Revisa tu conexión e intenta más tarde.');
            } finally {
              setVerificandoSesion(false);
            }
          }}
        />
      )}
      {pantalla === 'registro' && (
        <Registro
          onVolver={() => setPantalla('bienvenida')}
          onRegistroExitoso={(datos) => {
            setUsuario(prev => ({ ...prev, ...datos }));
            setPantalla('onboarding');
          }}
        />
      )}
      {pantalla === 'recuperar' && (
        <RecuperarContrasena
          onVolver={() => setPantalla('login')}
        />
      )}
      {pantalla === 'onboarding' && (
        <Onboarding 
          usuarioActual={usuario}
          onTerminar={(datos) => {
            setUsuario(prev => ({ ...prev, ...datos }));
            setPantalla('generando-plan');
          }} 
        />
      )}
      {pantalla === 'generando-plan' && (
        <GenerandoPlan
          usuarioId={usuario.id}
          onPlanListo={(planGenerado) => {
            setPlan(planGenerado);
            setPantalla('dashboard');
          }}
        />
      )}
      {pantalla === 'dashboard' && (
        <Dashboard 
          usuario={usuario} 
          plan={plan}
          onActualizarPlan={setPlan}
          onCerrarSesion={() => {
            setUsuario({ nombre: '', correo: '' });
            setPlan(null);
            setPantalla('bienvenida');
          }}
        />
      )}
        </>
      )}
    </SafeAreaProvider>
  );
}

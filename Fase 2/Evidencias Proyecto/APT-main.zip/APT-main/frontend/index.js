/**
 * @file index.js
 * @description Punto de entrada de la aplicación FitAI. Registra el componente raíz
 *              e inyecta estilos globales para web (oculta el botón nativo de revelar contraseña).
 */

import { registerRootComponent } from 'expo';
import App from './App';

// Oculta el ícono nativo de revelar contraseña en navegadores web (IE/Edge/WebKit)
if (typeof document !== 'undefined') {
  const style = document.createElement('style');
  style.textContent = `
    input[type="password"]::-ms-reveal,
    input[type="password"]::-ms-clear,
    input[type="password"]::-webkit-contacts-auto-fill-button,
    input[type="password"]::-webkit-credentials-auto-fill-button {
      display: none !important;
    }
  `;
  document.head.appendChild(style);
}

registerRootComponent(App);

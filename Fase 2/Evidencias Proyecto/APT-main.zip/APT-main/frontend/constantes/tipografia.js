/**
 * @file tipografia.js
 * @description Familia tipográfica (Inter) y escala de tamaños de texto.
 *              Usar siempre estas constantes en lugar de valores numéricos directos.
 */

/** Nombres de las variantes cargadas de la fuente Inter. */
export const FUENTES = {
  regular:     'Inter_400Regular',
  medio:       'Inter_500Medium',
  semiNegrita: 'Inter_600SemiBold',
  negrita:     'Inter_700Bold',
};

/** Escala de tamaños en puntos, de xs (10) a h1 (36). */
export const TAMANOS = {
  xs:   10, // microtexto (badges, labels de tabs)
  sm:   12, // texto auxiliar, etiquetas de campos
  md:   13, // texto compacto
  base: 14, // texto de cuerpo estándar
  lg:   16, // texto de botones y subtítulos
  xl:   20, // títulos de sección
  xxl:  24, // títulos de paso / modal
  h2:   28, // encabezados secundarios
  h1:   36, // encabezados principales de pantalla
};

/**
 * @file colores.js
 * @description Paleta de colores global de la app. Importar COLORES en lugar de 
 * valores hexadecimales directos.
 */

/** Tokens de color del sistema de diseño FitAI. */
export const COLORES = {
  oscuro:     '#1A1A2E', // fondo principal de pantallas
  superficie: '#16213E', // fondo de headers y tabs
  tarjeta:    '#212E4D', // fondo de cards, inputs y chips
  primario:   '#6C63FF', // color de acento (botones, selección activa)
  borde:      '#404060', // borde de inputs y chips inactivos
  blanco:     '#FFFFFF',
  subtitulo:  '#A0A0B0', // texto secundario y placeholders
  exito:      '#33C78F', // estado de éxito
  exitoFondo: '#0D2218', // fondo del ícono de éxito
  alerta:     '#FF9933', // advertencias
  error:      '#E64D4D', // mensajes de error
};

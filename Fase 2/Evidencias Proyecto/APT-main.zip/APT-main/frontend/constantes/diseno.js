/**
 * @file diseno.js
 * @description Espaciado, tamaños y radios del sistema de diseño.
 *              Centraliza los valores para mantener consistencia visual en toda la app.
 */

/** Constantes de layout y geometría reutilizables. */
export const DISENO = {
  paddingH:   20, // padding horizontal estándar de pantallas
  paddingV:   16, // padding vertical estándar
  altoBoton:  52, // altura fija para todos los botones primarios
  altoChip:   38, // altura fija para chips de selección
  altoNavBar: 80, // altura de la barra de navegación inferior
  radio: {
    sm:   8,   // esquinas sutiles (cards pequeñas)
    md:   14,  // esquinas medianas (inputs, cards)
    lg:   16,  // esquinas grandes (botones)
    xl:   20,  // esquinas muy redondeadas (cards destacadas)
    chip: 19,  // píldora para chips de texto
    full: 999, // círculo completo (avatars, dots)
  },
};

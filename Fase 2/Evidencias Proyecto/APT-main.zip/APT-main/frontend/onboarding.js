/**
 * @file onboarding.js
 * @description Flujo de onboarding modular. Maneja el estado global del proceso
 *              y delega el renderizado de cada paso a componentes especializados.
 */

import React, { useState, useEffect } from 'react'; // hooks de estado y efecto
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, KeyboardAvoidingView, Platform, Alert,
} from 'react-native'; // componentes primitivos de UI y utilidades de teclado/plataforma
import AsyncStorage from '@react-native-async-storage/async-storage'; // persiste el usuario_id entre sesiones
import servicioPerfil from './servicios/servicio-perfil'; // llamadas al backend (crear/actualizar perfil)
import { COLORES } from './constantes/colores'; // paleta de colores del sistema de diseño
import { FUENTES, TAMANOS } from './constantes/tipografia'; // familias tipográficas y tamaños de fuente
import { DISENO } from './constantes/diseno'; // constantes de layout (paddings, radios, alturas)
import Paso1 from './pantallas/onboarding/Paso1'; // nombre, edad, sexo biológico
import Paso2 from './pantallas/onboarding/Paso2'; // objetivo principal de fitness
import Paso3 from './pantallas/onboarding/Paso3'; // peso y estatura
import Paso4 from './pantallas/onboarding/Paso4'; // nivel de actividad, experiencia, días y duración
import Paso5 from './pantallas/onboarding/Paso5'; // condiciones de salud
import Paso6 from './pantallas/onboarding/Paso6'; // tipo de dieta y alimentos excluidos

const CLAVE_STORAGE_ID = '@FitAI:usuario_id';

export default function Onboarding({ onTerminar, usuarioActual }) {
  const [paso, setPaso] = useState(1);
  const [cargando, setCargando] = useState(false);
  const [usuarioId, setUsuarioId] = useState(usuarioActual?.id || null);

  // --- Estado de los campos ---
  const [nombre, setNombre] = useState(usuarioActual?.nombre || '');
  const [edad, setEdad] = useState(usuarioActual?.edad || '');
  const [sexo, setSexo] = useState(usuarioActual?.sexo || null);
  const [objetivo, setObjetivo] = useState(usuarioActual?.objetivo || null);
  const [peso, setPeso] = useState(usuarioActual?.peso || '');
  const [estatura, setEstatura] = useState(usuarioActual?.estatura || '');
  const [nivelActividad, setNivelActividad] = useState(usuarioActual?.nivelActividad || null);
  const [nivelExperiencia, setNivelExperiencia] = useState(usuarioActual?.nivelExperiencia || null);
  const [dias, setDias] = useState(usuarioActual?.dias || null);
  const [minutos, setMinutos] = useState(usuarioActual?.minutos || null);
  const [condiciones, setCondiciones] = useState(usuarioActual?.condiciones || '');
  const [tipoDieta, setTipoDieta] = useState(usuarioActual?.tipoDieta || null);
  const [alimentos, setAlimentos] = useState(usuarioActual?.alimentos || '');

  // Recuperar ID persistido al montar
  useEffect(() => {
    const recuperarId = async () => {
      try {
        const idGuardado = await AsyncStorage.getItem(CLAVE_STORAGE_ID);
        if (idGuardado) {
          setUsuarioId(idGuardado);
        }
      } catch (e) {
        // Fallback silencioso si falla el storage nativo
        console.warn('No se pudo recuperar ID del storage:', e.message);
      }
    };
    recuperarId();
  }, []);

  const handleContinuar = async () => {
    setCargando(true);
    try {
      let currentId = usuarioId;
      
      // Paso 1: Crear perfil si no existe
      if (paso === 1 && !currentId) {
        currentId = await servicioPerfil.crearPerfil();
        setUsuarioId(currentId);
        try {
          await AsyncStorage.setItem(CLAVE_STORAGE_ID, currentId);
        } catch (storageError) {
          console.warn('Error guardando ID en storage (ignorado):', storageError.message);
        }
      }
      
      // Error de seguridad si llegamos aquí sin ID
      if (!currentId) {
        throw new Error('No se pudo identificar al usuario. Por favor, reinicia el paso 1.');
      }

      const datos = {};
      if (paso === 1) {
        datos.nombre = nombre.trim();
        datos.edad = parseInt(edad, 10);
        datos.sexo_biologico = sexo;
      } else if (paso === 2) {
        datos.objetivo = objetivo;
      } else if (paso === 3) {
        datos.peso = parseFloat(peso);
        datos.estatura = parseFloat(estatura);
      } else if (paso === 4) {
        datos.nivel_actividad = nivelActividad;
        datos.nivel_experiencia = nivelExperiencia;
        datos.dias_por_semana = dias;
        datos.tiempo_por_sesion_minutos = minutos;
      } else if (paso === 5) {
        datos.condiciones_salud = condiciones.trim() || 'Ninguna';
      } else if (paso === 6) {
        datos.tipo_dieta = tipoDieta;
        datos.alimentos_excluidos = alimentos.trim() || 'Ninguno';
      }

      const res = await servicioPerfil.actualizarCampo(datos, currentId);
      
      // Si el backend falló realmente (no offline), mostramos error
      if (res && res.exito === false) {
        throw new Error(res.mensaje || 'Error desconocido en el servidor');
      }

      if (paso < 5) {
        setPaso(paso + 1);
      } else {
        // Al terminar, limpiar el storage para la próxima vez
        await AsyncStorage.removeItem(CLAVE_STORAGE_ID);
        onTerminar && onTerminar({ nombre, id: currentId });
      }
    } catch (error) {
      console.error('Error en onboarding:', error);
      Alert.alert('Atención', error.message);
      // Si el ID se rompió, volvemos al paso 1
      if (error.message.includes('identificar')) setPaso(1);
    } finally {
      setCargando(false);
    }
  };

  const esValido = () => {
    if (paso === 1) return nombre.trim() && edad && sexo;
    if (paso === 2) return objetivo;
    if (paso === 3) return peso && estatura;
    if (paso === 4) return nivelActividad && nivelExperiencia && dias && minutos;
    if (paso === 5) return true;
    if (paso === 6) return tipoDieta;
    return false;
  };

  const renderChip = (item, selectedValue, onSelect) => {
    const activo = selectedValue === item.id;
    return (
      <TouchableOpacity
        key={String(item.id)}
        style={[st.chip, activo && st.chipActivo]}
        onPress={() => onSelect(item.id)}
        activeOpacity={0.7}
      >
        <Text style={[st.chipTexto, activo && st.chipTextoActivo]}>{item.etiqueta}</Text>
      </TouchableOpacity>
    );
  };

  const renderNumChip = (num, selectedValue, onSelect) => {
    const activo = selectedValue === num;
    return (
      <TouchableOpacity
        key={String(num)}
        style={[st.chipDia, activo && st.chipActivo]}
        onPress={() => onSelect(num)}
        activeOpacity={0.7}
      >
        <Text style={[st.chipTexto, activo && st.chipTextoActivo]}>{String(num)}</Text>
      </TouchableOpacity>
    );
  };

  const renderPasoActual = () => {
    const propsComunes = { renderChip, renderNumChip };
    switch (paso) {
      case 1: return <Paso1 nombre={nombre} setNombre={setNombre} edad={edad} setEdad={setEdad} sexo={sexo} setSexo={setSexo} {...propsComunes} />;
      case 2: return <Paso2 objetivo={objetivo} setObjetivo={setObjetivo} {...propsComunes} />;
      case 3: return <Paso3 peso={peso} setPeso={setPeso} estatura={estatura} setEstatura={setEstatura} />;
      case 4: return <Paso4 nivelActividad={nivelActividad} setNivelActividad={setNivelActividad} nivelExperiencia={nivelExperiencia} setNivelExperiencia={setNivelExperiencia} dias={dias} setDias={setDias} minutos={minutos} setMinutos={setMinutos} {...propsComunes} />;
      case 5: return <Paso5 condiciones={condiciones} setCondiciones={setCondiciones} />;
      case 6: return <Paso6 tipoDieta={tipoDieta} setTipoDieta={setTipoDieta} alimentos={alimentos} setAlimentos={setAlimentos} {...propsComunes} />;
      default: return null;
    }
  };

  const btnLabel = cargando ? 'Guardando...' : (paso === 5 ? 'Terminar' : 'Continuar');
  const isDisabled = !esValido() || cargando;

  return (
    <KeyboardAvoidingView
      style={st.contenedor}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={st.barraFondo}>
        <View style={[st.barraRelleno, { width: `${(paso / 5) * 100}%` }]} />
      </View>
      <Text style={st.pasoTexto}>Paso {paso} de 5</Text>

      <ScrollView
        showsVerticalScrollIndicator={false}
        style={st.scroll}
        contentContainerStyle={st.scrollContenido}
        keyboardShouldPersistTaps="handled"
      >
        {renderPasoActual()}
      </ScrollView>

      <View style={st.botones}>
        {paso > 1 && (
          <TouchableOpacity
            style={st.botonSecundario}
            onPress={() => setPaso(paso - 1)}
            activeOpacity={0.7}
          >
            <Text style={st.botonSecundarioTexto}>Atrás</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[st.boton, isDisabled && st.botonDesactivado]}
          onPress={handleContinuar}
          disabled={isDisabled}
          activeOpacity={0.8}
        >
          <Text style={st.botonTexto}>{btnLabel}</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const st = StyleSheet.create({
  contenedor: { flex: 1, backgroundColor: COLORES.oscuro, paddingHorizontal: DISENO.paddingH, paddingTop: 60, paddingBottom: 20 },
  barraFondo: { height: 4, backgroundColor: COLORES.superficie, borderRadius: 2, marginBottom: 8, overflow: 'hidden' },
  barraRelleno: { height: 4, backgroundColor: COLORES.primario, borderRadius: 2 },
  pasoTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 20 },
  scroll: { flex: 1 },
  scrollContenido: { paddingBottom: 20 },
  chipGroup: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  chip: { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.chip, borderWidth: 1, borderColor: COLORES.borde, height: DISENO.altoChip, paddingHorizontal: 16, justifyContent: 'center' },
  chipDia: { flex: 1, backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, borderWidth: 1, borderColor: COLORES.borde, height: 44, alignItems: 'center', justifyContent: 'center' },
  chipActivo: { backgroundColor: COLORES.primario, borderColor: COLORES.primario },
  chipTexto: { fontFamily: FUENTES.regular, fontSize: TAMANOS.md, color: COLORES.blanco },
  chipTextoActivo: { fontFamily: FUENTES.medio, color: COLORES.blanco },
  botones: { flexDirection: 'row', marginTop: 20, gap: 10 },
  boton: { flex: 1, backgroundColor: COLORES.primario, borderRadius: DISENO.radio.lg, height: DISENO.altoBoton, justifyContent: 'center', alignItems: 'center' },
  botonSecundario: { flex: 1, backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, borderWidth: 1, borderColor: COLORES.borde, height: DISENO.altoBoton, justifyContent: 'center', alignItems: 'center' },
  botonDesactivado: { opacity: 0.4 },
  botonTexto: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  botonSecundarioTexto: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
});

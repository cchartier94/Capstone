import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Animated, Dimensions, TouchableOpacity, Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import servicioNotificaciones from '../servicios/servicio-notificaciones';

const { width } = Dimensions.get('window');

const CONFIG_TIPO = {
  entrenamiento: {
    icono: 'barbell',
    color: COLORES.primario,
    bgColor: 'rgba(108, 99, 255, 0.15)',
    label: 'ENTRENAMIENTO'
  },
  seguimiento: {
    icono: 'stats-chart',
    color: COLORES.alerta,
    bgColor: 'rgba(255, 193, 7, 0.15)',
    label: 'SEGUIMIENTO'
  },
  info: {
    icono: 'notifications',
    color: COLORES.exito,
    bgColor: 'rgba(40, 167, 69, 0.15)',
    label: 'COACH NOTIFICACIÓN'
  }
};

export default function NotificacionToast() {
  const [visible, setVisible] = useState(false);
  const [datos, setDatos] = useState({ titulo: '', mensaje: '', tipo: 'info' });
  const animY = useRef(new Animated.Value(-120)).current;
  const timeoutRef = useRef(null);

  useEffect(() => {
    // Suscribirse al servicio de notificaciones
    const desuscribir = servicioNotificaciones.suscribir((titulo, mensaje, tipo) => {
      // Limpiar cualquier timeout activo
      if (timeoutRef.current) clearTimeout(timeoutRef.current);

      setDatos({ titulo, mensaje, tipo: CONFIG_TIPO[tipo] ? tipo : 'info' });
      setVisible(true);

      // Iniciar animación de entrada
      Animated.spring(animY, {
        toValue: Platform.OS === 'web' ? 20 : 50, // Más abajo en móviles por el notch/status bar
        useNativeDriver: true,
        bounciness: 8
      }).start();

      // Programar ocultamiento tras 4.5 segundos
      timeoutRef.current = setTimeout(() => {
        ocultar();
      }, 4500);
    });

    return () => {
      desuscribir();
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const ocultar = () => {
    Animated.timing(animY, {
      toValue: -140,
      duration: 350,
      useNativeDriver: true
    }).start(() => {
      setVisible(false);
    });
  };

  if (!visible) return null;

  const cfg = CONFIG_TIPO[datos.tipo];

  return (
    <Animated.View style={[s.toastContainer, { transform: [{ translateY: animY }] }]}>
      <View style={[s.toast, { borderLeftColor: cfg.color }]}>
        <View style={[s.iconoBg, { backgroundColor: cfg.bgColor }]}>
          <Ionicons name={cfg.icono} size={20} color={cfg.color} />
        </View>
        <View style={s.textos}>
          <Text style={[s.tipoLabel, { color: cfg.color }]}>{cfg.label}</Text>
          <Text style={s.titulo} numberOfLines={1}>{datos.titulo}</Text>
          <Text style={s.mensaje} numberOfLines={2}>{datos.mensaje}</Text>
        </View>
        <TouchableOpacity style={s.botonCerrar} onPress={ocultar} activeOpacity={0.7}>
          <Ionicons name="close-outline" size={18} color={COLORES.subtitulo} />
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
}

const s = StyleSheet.create({
  toastContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 99999,
    paddingHorizontal: 16,
    // Sombra para dar efecto de profundidad premium
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.35,
        shadowRadius: 12,
      },
      android: {
        elevation: 8,
      },
      web: {
        boxShadow: '0 8px 30px rgba(0,0,0,0.4)',
      }
    })
  },
  toast: {
    width: Platform.OS === 'web' ? Math.min(width - 32, 450) : '100%',
    backgroundColor: 'rgba(28, 28, 30, 0.95)', // Glassmorphism oscuro
    borderWidth: 1,
    borderColor: COLORES.borde,
    borderLeftWidth: 5,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
    ...(Platform.OS === 'web' && {
      backdropFilter: 'blur(12px)',
    })
  },
  iconoBg: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center'
  },
  textos: {
    flex: 1,
  },
  tipoLabel: {
    fontFamily: FUENTES.negrita,
    fontSize: 9,
    letterSpacing: 1,
    marginBottom: 2
  },
  titulo: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.sm,
    color: COLORES.blanco,
    marginBottom: 1
  },
  mensaje: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.xs,
    color: COLORES.subtitulo,
    lineHeight: 16
  },
  botonCerrar: {
    width: 28,
    height: 28,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.04)'
  }
});

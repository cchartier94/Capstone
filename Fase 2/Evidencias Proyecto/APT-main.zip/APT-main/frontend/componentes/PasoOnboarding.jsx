/**
 * @file PasoOnboarding.jsx
 * @description Layout reutilizable para cada paso del onboarding.
 *              Muestra la barra de progreso, título, subtítulo, contenido hijo y botón de continuar.
 */

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';

/**
 * Wrapper de paso de onboarding con barra de progreso y botón de continuar.
 *
 * @param {object}    props
 * @param {number}    props.numeroPaso        - Número del paso actual (1-6); controla el ancho de la barra.
 * @param {string}    props.titulo            - Título principal del paso.
 * @param {string}    [props.subtitulo]       - Subtítulo opcional debajo del título.
 * @param {ReactNode} props.children          - Contenido del paso (inputs, chips, etc.).
 * @param {Function}  props.onPressContinuar  - Callback al pulsar "Continuar".
 * @param {boolean}   [props.deshabilitado]   - Deshabilita el botón si true.
 * @param {boolean}   [props.cargando]        - Muestra "Guardando..." y deshabilita el botón.
 * @returns {JSX.Element}
 */
export default function PasoOnboarding({
  numeroPaso,
  titulo,
  subtitulo,
  children,
  onPressContinuar,
  deshabilitado = false,
  cargando = false,
}) {
  /** Porcentaje de progreso basado en el paso actual sobre 6 pasos totales. */
  const progreso = (numeroPaso / 6) * 100;

  return (
    <View style={s.container}>
      <View style={s.progressBar}>
        <View style={[s.progressFill, { width: `${progreso}%` }]} />
      </View>

      <Text style={s.stepText}>Paso {numeroPaso} de 6</Text>
      <Text style={s.title}>{titulo}</Text>
      {subtitulo && <Text style={s.subtitle}>{subtitulo}</Text>}

      <View style={s.content}>{children}</View>

      <TouchableOpacity
        style={[s.btn, (deshabilitado || cargando) && s.btnDisabled]}
        onPress={onPressContinuar}
        disabled={deshabilitado || cargando}
      >
        <Text style={s.btnText}>
          {cargando ? 'Guardando...' : 'Continuar'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORES.oscuro,
    paddingHorizontal: DISENO.paddingH,
    paddingTop: 60,
    paddingBottom: 20,
  },
  progressBar: {
    height: 4,
    backgroundColor: COLORES.tarjeta,
    borderRadius: 2,
    marginBottom: 20,
    overflow: 'hidden',
  },
  progressFill: {
    height: 4,
    backgroundColor: COLORES.primario,
    borderRadius: 2,
  },
  stepText: {
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
    marginBottom: 8,
    fontWeight: '500',
  },
  title: {
    fontSize: TAMANOS.h1,
    color: COLORES.blanco,
    marginBottom: 8,
    fontWeight: '700',
  },
  subtitle: {
    fontSize: TAMANOS.lg,
    color: COLORES.subtitulo,
    marginBottom: 32,
  },
  content: {
    flex: 1,
  },
  btn: {
    backgroundColor: COLORES.primario,
    borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  btnDisabled: {
    opacity: 0.4,
  },
  btnText: {
    fontSize: TAMANOS.lg,
    color: COLORES.blanco,
    fontWeight: '600',
  },
});

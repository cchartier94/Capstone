/**
 * @file TarjetaMetrica.jsx
 * @description Card de métrica con valor, unidad e indicador de tendencia.
 *              Muestra ↑ mejora (verde), → estable (amarillo), ↓ retroceso (rojo).
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';

const TENDENCIA_CONFIG = {
  mejora: { icono: 'trending-up', color: COLORES.exito, label: 'Mejora' },
  estable: { icono: 'remove-outline', color: COLORES.alerta, label: 'Estable' },
  retroceso: { icono: 'trending-down', color: COLORES.error, label: 'Retroceso' },
};

/**
 * @param {object} props
 * @param {string} props.etiqueta - Nombre de la métrica
 * @param {string} props.valor - Valor principal a mostrar
 * @param {string} [props.unidad] - Unidad (ej: "kg", "días")
 * @param {string} [props.tendencia] - "mejora"|"estable"|"retroceso"
 * @param {number} [props.cambioPorcentual] - Cambio % vs período anterior
 */
export default function TarjetaMetrica({
  etiqueta,
  valor,
  unidad,
  tendencia = 'estable',
  cambioPorcentual,
}) {
  const config = TENDENCIA_CONFIG[tendencia] || TENDENCIA_CONFIG.estable;

  return (
    <View style={s.tarjeta}>
      <View style={[s.iconoTendencia, { backgroundColor: config.color + '20' }]}>
        <Ionicons name={config.icono} size={16} color={config.color} />
      </View>
      <Text style={s.valor} numberOfLines={1} adjustsFontSizeToFit>
        {valor}
      </Text>
      {unidad ? <Text style={s.unidad}>{unidad}</Text> : null}
      <Text style={s.etiqueta}>{etiqueta}</Text>
      {cambioPorcentual != null && (
        <Text style={[s.cambio, { color: config.color }]}>
          {cambioPorcentual > 0 ? '+' : ''}{cambioPorcentual}%
        </Text>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  tarjeta: {
    flex: 1,
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.lg,
    padding: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORES.borde,
  },
  iconoTendencia: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  valor: {
    fontFamily: FUENTES.negrita,
    fontSize: TAMANOS.xl,
    color: COLORES.blanco,
    marginBottom: 2,
  },
  unidad: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.xs,
    color: COLORES.subtitulo,
    marginBottom: 4,
  },
  etiqueta: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.xs,
    color: COLORES.subtitulo,
  },
  cambio: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.xs,
    marginTop: 4,
  },
});

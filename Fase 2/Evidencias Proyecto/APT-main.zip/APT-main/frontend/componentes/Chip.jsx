/**
 * @file Chip.jsx
 * @description Componente de selección tipo píldora. Muestra estado activo/inactivo
 *              según la prop `selected` y llama a `onPress` al ser pulsado.
 */

import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { COLORES } from '../constantes/colores';
import { TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';

/**
 * Chip seleccionable de texto.
 *
 * @param {object}   props
 * @param {string}   props.label    - Texto que muestra el chip.
 * @param {boolean}  props.selected - Si es true, aplica el estilo activo (color primario).
 * @param {Function} props.onPress  - Callback al presionar el chip.
 * @returns {JSX.Element}
 */
export default function Chip({ label, selected, onPress }) {
  return (
    <TouchableOpacity
      style={[s.chip, selected && s.chipActive]}
      onPress={onPress}
    >
      <Text style={[s.chipText, selected && s.chipTextActive]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  chip: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.chip,
    borderWidth: 1,
    borderColor: COLORES.borde,
    paddingHorizontal: 16,
    paddingVertical: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chipActive: {
    backgroundColor: COLORES.primario,
    borderColor: COLORES.primario,
  },
  chipText: {
    fontSize: TAMANOS.base,
    color: COLORES.blanco,
    fontWeight: '500',
  },
  chipTextActive: {
    color: COLORES.blanco,
  },
});

/**
 * @file FiltroPeriodo.jsx
 * @description Selector de período (día/semana/mes) con pills animadas.
 *              Usado en el tab de progreso para filtrar métricas (SCRUM-35).
 */

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';

const PERIODOS = [
  { id: 'dia', label: 'Día' },
  { id: 'semana', label: 'Semana' },
  { id: 'mes', label: 'Mes' },
];

/**
 * @param {object} props
 * @param {string} props.periodoActivo - Período seleccionado ('dia'|'semana'|'mes')
 * @param {function} props.onChange - Callback al cambiar período
 */
export default function FiltroPeriodo({ periodoActivo, onChange }) {
  return (
    <View style={s.contenedor}>
      {PERIODOS.map((p) => {
        const activo = periodoActivo === p.id;
        return (
          <TouchableOpacity
            key={p.id}
            style={[s.pill, activo && s.pillActivo]}
            onPress={() => onChange(p.id)}
            activeOpacity={0.7}
          >
            <Text style={[s.pillTexto, activo && s.pillTextoActivo]}>
              {p.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const s = StyleSheet.create({
  contenedor: {
    flexDirection: 'row',
    backgroundColor: COLORES.tarjeta,
    borderRadius: 12,
    padding: 4,
    gap: 4,
  },
  pill: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 10,
  },
  pillActivo: {
    backgroundColor: COLORES.primario,
  },
  pillTexto: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
  },
  pillTextoActivo: {
    color: COLORES.blanco,
  },
});

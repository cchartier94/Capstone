/**
 * @file GraficoBarras.jsx
 * @description Mini gráfico de barras custom (sin librería externa).
 *              Renderiza barras proporcionales al valor máximo del dataset.
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';

/**
 * @param {object} props
 * @param {Array<{etiqueta: string, valor: number}>} props.datos - Datos del gráfico
 * @param {string} [props.titulo] - Título opcional sobre el gráfico
 * @param {number} [props.alturaMax=120] - Altura máxima de las barras en px
 */
export default function GraficoBarras({ datos = [], titulo, alturaMax = 120 }) {
  const maxValor = Math.max(...datos.map((d) => d.valor), 1);

  return (
    <View style={s.contenedor}>
      {titulo ? <Text style={s.titulo}>{titulo}</Text> : null}
      <View style={s.grafico}>
        {datos.map((d, i) => {
          const altura = (d.valor / maxValor) * alturaMax;
          const esActivo = d.valor > 0;
          return (
            <View key={`${d.etiqueta}-${i}`} style={s.columna}>
              <View style={s.barraContenedor}>
                {esActivo && (
                  <Text style={s.barraValor}>{d.valor}</Text>
                )}
                <View
                  style={[
                    s.barra,
                    {
                      height: Math.max(altura, 4),
                      backgroundColor: esActivo
                        ? COLORES.primario
                        : COLORES.borde,
                      opacity: esActivo ? 1 : 0.4,
                    },
                  ]}
                />
              </View>
              <Text style={s.etiqueta}>{d.etiqueta}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  contenedor: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.lg,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORES.borde,
  },
  titulo: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
    marginBottom: 16,
  },
  grafico: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    gap: 6,
  },
  columna: {
    flex: 1,
    alignItems: 'center',
  },
  barraContenedor: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    minHeight: 30,
  },
  barra: {
    width: '70%',
    minWidth: 16,
    borderRadius: 6,
  },
  barraValor: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: 9,
    color: COLORES.primario,
    marginBottom: 4,
  },
  etiqueta: {
    fontFamily: FUENTES.regular,
    fontSize: 9,
    color: COLORES.subtitulo,
    marginTop: 8,
    textAlign: 'center',
  },
});

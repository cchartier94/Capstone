/**
 * @file TarjetaInsight.jsx
 * @description Card de insight/recomendación con icono, título y descripción.
 *              Coloreado según tipo: logro (verde), recomendacion (azul), alerta (rojo).
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';

const TIPO_CONFIG = {
  logro: {
    color: COLORES.exito,
    fondo: COLORES.exitoFondo,
  },
  recomendacion: {
    color: COLORES.primario,
    fondo: COLORES.primario + '15',
  },
  alerta: {
    color: COLORES.error,
    fondo: COLORES.error + '15',
  },
};

/**
 * @param {object} props
 * @param {string} props.tipo - "logro"|"recomendacion"|"alerta"
 * @param {string} props.icono - Nombre de icono Ionicons
 * @param {string} props.titulo - Título del insight
 * @param {string} props.descripcion - Descripción detallada
 */
export default function TarjetaInsight({ tipo = 'recomendacion', icono, titulo, descripcion }) {
  const config = TIPO_CONFIG[tipo] || TIPO_CONFIG.recomendacion;

  return (
    <View style={s.tarjeta}>
      <View style={[s.iconoContenedor, { backgroundColor: config.fondo }]}>
        <Ionicons name={icono || 'bulb-outline'} size={20} color={config.color} />
      </View>
      <View style={s.contenido}>
        <Text style={s.titulo}>{titulo}</Text>
        <Text style={s.descripcion}>{descripcion}</Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  tarjeta: {
    flexDirection: 'row',
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.lg,
    padding: 16,
    gap: 14,
    borderWidth: 1,
    borderColor: COLORES.borde,
  },
  iconoContenedor: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  contenido: {
    flex: 1,
  },
  titulo: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.base,
    color: COLORES.blanco,
    marginBottom: 4,
  },
  descripcion: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
    lineHeight: 18,
  },
});

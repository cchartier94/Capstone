/**
 * @file RegistroMetricas.jsx
 * @description HU2 — Formulario para registrar métricas físicas del usuario.
 *              Peso es obligatorio; medidas corporales son opcionales.
 *              El usuario puede seleccionar cualquier fecha pasada o presente.
 */

import React, { useState, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  TextInput, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';
import servicioMetricas from '../servicios/servicio-metricas';

// ─── Helpers de fecha ───────────────────────────────────────────────────────

function hoyPartes() {
  const d = new Date();
  return {
    dia:  String(d.getDate()).padStart(2, '0'),
    mes:  String(d.getMonth() + 1).padStart(2, '0'),
    anio: String(d.getFullYear()),
  };
}

function partesAIso(dia, mes, anio) {
  return `${anio}-${mes}-${dia}`;
}

function esFechaValida(dia, mes, anio) {
  const d = parseInt(dia, 10);
  const m = parseInt(mes, 10);
  const a = parseInt(anio, 10);
  if (!d || !m || !a || a < 2000 || a > 2100) return false;
  const fecha = new Date(a, m - 1, d);
  if (fecha > new Date()) return false; // no fechas futuras
  return fecha.getFullYear() === a && fecha.getMonth() + 1 === m && fecha.getDate() === d;
}

// ─── Selector de fecha ───────────────────────────────────────────────────────

function SelectorFecha({ dia, mes, anio, onDia, onMes, onAnio }) {
  const refMes  = useRef(null);
  const refAnio = useRef(null);
  const valida  = esFechaValida(dia, mes, anio);

  const inputFecha = (setter, max, refSiguiente) => (texto) => {
    const solo = texto.replace(/\D/g, '').slice(0, max === 4 ? 4 : 2);
    setter(solo);
    if (solo.length === (max === 4 ? 4 : 2) && refSiguiente?.current) {
      refSiguiente.current.focus();
    }
  };

  return (
    <View style={sf.contenedor}>
      <View style={[sf.campo, !valida && dia.length === 2 && sf.campoError]}>
        <Text style={sf.etiqueta}>Día</Text>
        <TextInput
          style={sf.input}
          value={dia}
          onChangeText={inputFecha(onDia, 2, refMes)}
          placeholder="DD"
          placeholderTextColor={COLORES.subtitulo}
          keyboardType="numeric"
          maxLength={2}
          returnKeyType="next"
        />
      </View>

      <Text style={sf.separador}>/</Text>

      <View style={[sf.campo, !valida && mes.length === 2 && sf.campoError]}>
        <Text style={sf.etiqueta}>Mes</Text>
        <TextInput
          ref={refMes}
          style={sf.input}
          value={mes}
          onChangeText={inputFecha(onMes, 2, refAnio)}
          placeholder="MM"
          placeholderTextColor={COLORES.subtitulo}
          keyboardType="numeric"
          maxLength={2}
          returnKeyType="next"
        />
      </View>

      <Text style={sf.separador}>/</Text>

      <View style={[sf.campo, sf.campoAnio, !valida && anio.length === 4 && sf.campoError]}>
        <Text style={sf.etiqueta}>Año</Text>
        <TextInput
          ref={refAnio}
          style={sf.input}
          value={anio}
          onChangeText={inputFecha(onAnio, 4, null)}
          placeholder="AAAA"
          placeholderTextColor={COLORES.subtitulo}
          keyboardType="numeric"
          maxLength={4}
          returnKeyType="done"
        />
      </View>

      {valida && (
        <Ionicons name="checkmark-circle" size={20} color={COLORES.exito} style={sf.check} />
      )}
    </View>
  );
}

const sf = StyleSheet.create({
  contenedor: { flexDirection: 'row', alignItems: 'flex-end', gap: 6, marginBottom: 24 },
  campo:      { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, borderWidth: 1, borderColor: COLORES.borde, paddingHorizontal: 12, paddingTop: 8, paddingBottom: 6, flex: 1 },
  campoAnio:  { flex: 1.6 },
  campoError: { borderColor: COLORES.error },
  etiqueta:   { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo, marginBottom: 4 },
  input:      { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco, padding: 0 },
  separador:  { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.subtitulo, marginBottom: 10 },
  check:      { marginBottom: 8 },
});

// ─── Campo numérico genérico ──────────────────────────────────────────────────

function CampoNumerico({ label, valor, onChange, placeholder, obligatorio }) {
  return (
    <View style={s.campoWrap}>
      <Text style={s.campoLabel}>
        {label}
        {obligatorio && <Text style={{ color: COLORES.primario }}> *</Text>}
      </Text>
      <TextInput
        style={s.input}
        value={valor}
        onChangeText={onChange}
        placeholder={placeholder || '0.0'}
        placeholderTextColor={COLORES.subtitulo}
        keyboardType="decimal-pad"
        returnKeyType="done"
      />
    </View>
  );
}

// ─── Pantalla principal ───────────────────────────────────────────────────────

export default function RegistroMetricas({ usuario, onVolver }) {
  const inicial = hoyPartes();
  const [dia,  setDia]  = useState(inicial.dia);
  const [mes,  setMes]  = useState(inicial.mes);
  const [anio, setAnio] = useState(inicial.anio);

  const [peso,    setPeso]    = useState('');
  const [cintura, setCintura] = useState('');
  const [pecho,   setPecho]   = useState('');
  const [cadera,  setCadera]  = useState('');
  const [brazos,  setBrazos]  = useState('');
  const [piernas, setPiernas] = useState('');
  const [grasa,   setGrasa]   = useState('');

  const [expandido, setExpandido] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [exito,     setExito]     = useState(false);

  const fechaValida = esFechaValida(dia, mes, anio);
  const pesoValido  = peso.trim() !== '' && !isNaN(parseFloat(peso.replace(',', '.')));
  const puedeGuardar = pesoValido && fechaValida && !guardando;

  const guardar = async () => {
    if (!puedeGuardar) return;
    setGuardando(true);
    try {
      const datos = {
        fecha_registro: partesAIso(dia, mes, anio),
        peso_corporal_kg: parseFloat(peso.replace(',', '.')),
        ...(cintura && { medida_cintura_cm: parseFloat(cintura.replace(',', '.')) }),
        ...(pecho   && { medida_pecho_cm:   parseFloat(pecho.replace(',', '.')) }),
        ...(cadera  && { medida_cadera_cm:  parseFloat(cadera.replace(',', '.')) }),
        ...(brazos  && { medida_brazos_cm:  parseFloat(brazos.replace(',', '.')) }),
        ...(piernas && { medida_piernas_cm: parseFloat(piernas.replace(',', '.')) }),
        ...(grasa   && { porcentaje_grasa:  parseFloat(grasa.replace(',', '.')) }),
      };
      const res = await servicioMetricas.registrar(
        usuario?.id || '11111111-1111-1111-1111-111111111111',
        datos,
      );
      if (res.exito) {
        setExito(true);
        setTimeout(() => onVolver(), 1500);
      } else {
        Alert.alert('Error', res.mensaje || 'No se pudo guardar');
      }
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setGuardando(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={s.contenedor}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={onVolver} style={s.botonVolver} activeOpacity={0.7}>
          <Ionicons name="arrow-back" size={22} color={COLORES.blanco} />
        </TouchableOpacity>
        <Text style={s.headerTitulo}>Registrar Métricas</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={s.scroll}
        keyboardShouldPersistTaps="handled"
      >
        {/* Selector de fecha */}
        <Text style={s.seccion}>Fecha del registro</Text>
        <SelectorFecha
          dia={dia}   onDia={setDia}
          mes={mes}   onMes={setMes}
          anio={anio} onAnio={setAnio}
        />

        {/* Peso obligatorio */}
        <Text style={s.seccion}>Peso corporal</Text>
        <CampoNumerico
          label="Peso (kg)"
          valor={peso}
          onChange={setPeso}
          placeholder="ej: 75.5"
          obligatorio
        />

        {/* Medidas opcionales */}
        <TouchableOpacity
          style={s.toggleMedidas}
          onPress={() => setExpandido(!expandido)}
          activeOpacity={0.7}
        >
          <Text style={s.toggleTexto}>Medidas corporales (opcional)</Text>
          <Ionicons
            name={expandido ? 'chevron-up' : 'chevron-down'}
            size={18}
            color={COLORES.subtitulo}
          />
        </TouchableOpacity>

        {expandido && (
          <View style={s.medidasWrap}>
            <CampoNumerico label="Cintura (cm)" valor={cintura} onChange={setCintura} />
            <CampoNumerico label="Pecho (cm)"   valor={pecho}   onChange={setPecho} />
            <CampoNumerico label="Cadera (cm)"  valor={cadera}  onChange={setCadera} />
            <CampoNumerico label="Brazos (cm)"  valor={brazos}  onChange={setBrazos} />
            <CampoNumerico label="Piernas (cm)" valor={piernas} onChange={setPiernas} />
            <CampoNumerico label="Grasa (%)"    valor={grasa}   onChange={setGrasa} placeholder="ej: 15.5" />
          </View>
        )}

        {/* Mensaje éxito */}
        {exito && (
          <View style={s.exitoCard}>
            <Ionicons name="checkmark-circle" size={22} color={COLORES.exito} />
            <Text style={s.exitoTexto}>Métricas guardadas correctamente</Text>
          </View>
        )}

        {/* Botón guardar */}
        <TouchableOpacity
          style={[s.boton, !puedeGuardar && s.botonDesactivado]}
          onPress={guardar}
          disabled={!puedeGuardar}
          activeOpacity={0.8}
        >
          <Text style={s.botonTexto}>
            {guardando ? 'Guardando...' : 'Guardar registro'}
          </Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  contenedor:       { flex: 1, backgroundColor: COLORES.oscuro },
  header:           { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: DISENO.paddingH, paddingTop: 56, paddingBottom: 16, backgroundColor: COLORES.superficie, borderBottomWidth: 1, borderBottomColor: COLORES.borde },
  botonVolver:      { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitulo:     { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  scroll:           { paddingHorizontal: DISENO.paddingH, paddingTop: 24, paddingBottom: 24 },
  seccion:          { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 12 },
  campoWrap:        { marginBottom: 16 },
  campoLabel:       { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 8 },
  input:            { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, borderWidth: 1, borderColor: COLORES.borde, height: 50, paddingHorizontal: 16, fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.blanco },
  toggleMedidas:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, padding: 16, borderWidth: 1, borderColor: COLORES.borde, marginBottom: 12 },
  toggleTexto:      { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  medidasWrap:      { marginBottom: 8 },
  exitoCard:        { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: COLORES.exitoFondo, borderRadius: DISENO.radio.md, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: COLORES.exito },
  exitoTexto:       { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.exito },
  boton:            { backgroundColor: COLORES.primario, borderRadius: DISENO.radio.lg, height: DISENO.altoBoton, alignItems: 'center', justifyContent: 'center', marginTop: 16 },
  botonDesactivado: { opacity: 0.4 },
  botonTexto:       { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
});

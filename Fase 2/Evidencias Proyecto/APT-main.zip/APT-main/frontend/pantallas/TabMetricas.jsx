/**
 * @file TabMetricas.jsx
 * @description Tab para registrar y ver historial de métricas físicas (SCRUM-36).
 *              Formulario de registro + lista histórica conectados al backend.
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, Alert, RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';
import servicioMetricas from '../servicios/servicio-metricas';

export default function TabMetricas({ usuarioId }) {
  const [historial, setHistorial] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [refrescando, setRefrescando] = useState(false);
  const [mostrarForm, setMostrarForm] = useState(false);

  // Campos del formulario
  const [peso, setPeso] = useState('');
  const [cintura, setCintura] = useState('');
  const [pecho, setPecho] = useState('');
  const [cadera, setCadera] = useState('');
  const [brazos, setBrazos] = useState('');
  const [piernas, setPiernas] = useState('');
  const [grasa, setGrasa] = useState('');

  const cargarHistorial = useCallback(async () => {
    try {
      const data = await servicioMetricas.obtenerHistorial(usuarioId);
      if (data.exito) setHistorial(data.registros || []);
    } catch (e) {
      console.warn('Error cargando historial:', e);
    } finally {
      setCargando(false);
      setRefrescando(false);
    }
  }, [usuarioId]);

  useEffect(() => { cargarHistorial(); }, [cargarHistorial]);

  const limpiarForm = () => {
    setPeso(''); setCintura(''); setPecho('');
    setCadera(''); setBrazos(''); setPiernas(''); setGrasa('');
  };

  const guardarMetrica = async () => {
    const pesoNum = parseFloat(peso);
    if (!peso || isNaN(pesoNum) || pesoNum <= 0) {
      Alert.alert('Error', 'Ingresa un peso válido');
      return;
    }

    setGuardando(true);
    const datos = { peso_corporal_kg: pesoNum };
    if (cintura) datos.medida_cintura_cm = parseFloat(cintura);
    if (pecho) datos.medida_pecho_cm = parseFloat(pecho);
    if (cadera) datos.medida_cadera_cm = parseFloat(cadera);
    if (brazos) datos.medida_brazos_cm = parseFloat(brazos);
    if (piernas) datos.medida_piernas_cm = parseFloat(piernas);
    if (grasa) datos.porcentaje_grasa = parseFloat(grasa);

    const res = await servicioMetricas.registrarMetrica(datos, usuarioId);
    setGuardando(false);

    if (res.exito) {
      Alert.alert('✅ Registrado', 'Métrica guardada correctamente');
      limpiarForm();
      setMostrarForm(false);
      cargarHistorial();
    } else {
      Alert.alert('Error', res.mensaje || 'No se pudo guardar');
    }
  };

  if (cargando) {
    return (
      <View style={s.centrado}>
        <ActivityIndicator size="large" color={COLORES.primario} />
        <Text style={s.cargandoTexto}>Cargando métricas...</Text>
      </View>
    );
  }

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={s.contenido}
      refreshControl={
        <RefreshControl refreshing={refrescando} onRefresh={() => { setRefrescando(true); cargarHistorial(); }} tintColor={COLORES.primario} />
      }
    >
      <Text style={s.titulo}>Métricas Físicas</Text>

      {/* Botón registrar */}
      <TouchableOpacity
        style={s.botonRegistrar}
        onPress={() => setMostrarForm(!mostrarForm)}
        activeOpacity={0.8}
      >
        <Ionicons name={mostrarForm ? 'close' : 'add-circle-outline'} size={22} color={COLORES.blanco} />
        <Text style={s.botonRegistrarTexto}>
          {mostrarForm ? 'Cancelar' : 'Registrar medición'}
        </Text>
      </TouchableOpacity>

      {/* Formulario */}
      {mostrarForm && (
        <View style={s.formCard}>
          <Text style={s.formTitulo}>Nueva medición</Text>

          <Text style={s.inputLabel}>Peso corporal (kg) *</Text>
          <TextInput
            style={s.input}
            value={peso}
            onChangeText={setPeso}
            placeholder="Ej: 75.5"
            placeholderTextColor={COLORES.subtitulo}
            keyboardType="decimal-pad"
          />

          <Text style={s.inputLabel}>Medidas corporales (cm) — opcional</Text>
          <View style={s.inputRow}>
            <View style={s.inputHalf}>
              <Text style={s.inputMiniLabel}>Cintura</Text>
              <TextInput style={s.input} value={cintura} onChangeText={setCintura} placeholder="cm" placeholderTextColor={COLORES.subtitulo} keyboardType="decimal-pad" />
            </View>
            <View style={s.inputHalf}>
              <Text style={s.inputMiniLabel}>Pecho</Text>
              <TextInput style={s.input} value={pecho} onChangeText={setPecho} placeholder="cm" placeholderTextColor={COLORES.subtitulo} keyboardType="decimal-pad" />
            </View>
          </View>
          <View style={s.inputRow}>
            <View style={s.inputHalf}>
              <Text style={s.inputMiniLabel}>Cadera</Text>
              <TextInput style={s.input} value={cadera} onChangeText={setCadera} placeholder="cm" placeholderTextColor={COLORES.subtitulo} keyboardType="decimal-pad" />
            </View>
            <View style={s.inputHalf}>
              <Text style={s.inputMiniLabel}>Brazos</Text>
              <TextInput style={s.input} value={brazos} onChangeText={setBrazos} placeholder="cm" placeholderTextColor={COLORES.subtitulo} keyboardType="decimal-pad" />
            </View>
          </View>
          <View style={s.inputRow}>
            <View style={s.inputHalf}>
              <Text style={s.inputMiniLabel}>Piernas</Text>
              <TextInput style={s.input} value={piernas} onChangeText={setPiernas} placeholder="cm" placeholderTextColor={COLORES.subtitulo} keyboardType="decimal-pad" />
            </View>
            <View style={s.inputHalf}>
              <Text style={s.inputMiniLabel}>Grasa</Text>
              <TextInput style={s.input} value={grasa} onChangeText={setGrasa} placeholder="%" placeholderTextColor={COLORES.subtitulo} keyboardType="decimal-pad" />
            </View>
          </View>

          <TouchableOpacity style={s.botonGuardar} onPress={guardarMetrica} disabled={guardando} activeOpacity={0.8}>
            {guardando ? (
              <ActivityIndicator color={COLORES.blanco} />
            ) : (
              <Text style={s.botonGuardarTexto}>Guardar medición</Text>
            )}
          </TouchableOpacity>
        </View>
      )}

      {/* Historial */}
      <Text style={s.subtitulo}>Historial</Text>
      {historial.length === 0 ? (
        <View style={s.cardVacio}>
          <Ionicons name="scale-outline" size={40} color={COLORES.subtitulo} />
          <Text style={s.vacioTitulo}>Sin registros</Text>
          <Text style={s.vacioDesc}>Registra tu primera medición para empezar a ver tu progreso.</Text>
        </View>
      ) : (
        historial.map((reg) => (
          <View key={reg.id} style={s.registroCard}>
            <View style={s.registroHeader}>
              <Text style={s.registroFecha}>{reg.fecha_registro}</Text>
              <Text style={s.registroPeso}>{reg.peso_corporal_kg} kg</Text>
            </View>
            {(reg.medida_cintura_cm || reg.medida_pecho_cm || reg.medida_cadera_cm || reg.porcentaje_grasa) && (
              <View style={s.medidasRow}>
                {reg.medida_cintura_cm && <Text style={s.medidaTag}>Cintura: {reg.medida_cintura_cm}cm</Text>}
                {reg.medida_pecho_cm && <Text style={s.medidaTag}>Pecho: {reg.medida_pecho_cm}cm</Text>}
                {reg.medida_cadera_cm && <Text style={s.medidaTag}>Cadera: {reg.medida_cadera_cm}cm</Text>}
                {reg.medida_brazos_cm && <Text style={s.medidaTag}>Brazos: {reg.medida_brazos_cm}cm</Text>}
                {reg.medida_piernas_cm && <Text style={s.medidaTag}>Piernas: {reg.medida_piernas_cm}cm</Text>}
                {reg.porcentaje_grasa && <Text style={s.medidaTag}>Grasa: {reg.porcentaje_grasa}%</Text>}
              </View>
            )}
          </View>
        ))
      )}

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  contenido: { paddingHorizontal: DISENO.paddingH, paddingBottom: 100 },
  centrado: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  cargandoTexto: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginTop: 12 },
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 16, marginTop: 20 },
  subtitulo: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 12, marginTop: 20 },
  botonRegistrar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: COLORES.primario, borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton, marginBottom: 8,
  },
  botonRegistrarTexto: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.base, color: COLORES.blanco },
  formCard: {
    backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.xl,
    padding: 20, marginTop: 12, borderWidth: 1, borderColor: COLORES.borde,
  },
  formTitulo: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 16 },
  inputLabel: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 8 },
  inputMiniLabel: { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo, marginBottom: 4 },
  input: {
    backgroundColor: COLORES.superficie, borderRadius: DISENO.radio.md,
    height: 46, paddingHorizontal: 14, color: COLORES.blanco,
    fontFamily: FUENTES.regular, fontSize: TAMANOS.base,
    borderWidth: 1, borderColor: COLORES.borde, marginBottom: 12,
  },
  inputRow: { flexDirection: 'row', gap: 10 },
  inputHalf: { flex: 1 },
  botonGuardar: {
    backgroundColor: COLORES.exito, borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton, alignItems: 'center', justifyContent: 'center', marginTop: 4,
  },
  botonGuardarTexto: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.base, color: COLORES.blanco },
  cardVacio: {
    backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 32,
    alignItems: 'center', borderStyle: 'dashed', borderWidth: 1, borderColor: COLORES.borde,
  },
  vacioTitulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginTop: 12, marginBottom: 8 },
  vacioDesc: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, textAlign: 'center', lineHeight: 22 },
  registroCard: {
    backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg,
    padding: 16, marginBottom: 10, borderWidth: 1, borderColor: COLORES.borde,
  },
  registroHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  registroFecha: { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  registroPeso: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  medidasRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 },
  medidaTag: {
    fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.primario,
    backgroundColor: COLORES.primario + '15', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8,
  },
});

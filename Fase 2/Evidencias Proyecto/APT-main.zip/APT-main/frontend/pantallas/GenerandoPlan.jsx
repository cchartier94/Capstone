/**
 * @file GenerandoPlan.jsx
 * @description Pantalla de carga animada que simula la generación del plan personalizado por IA.
 *              Avanza por los pasos cada 1.2 s y llama a `onPlanListo` al terminar.
 *              La integración real con Claude API está pendiente.
 */

import React, { useEffect, useState } from 'react'; // hooks de efecto y estado
import { View, Text, StyleSheet, Alert } from 'react-native'; // componentes primitivos de UI
import { Ionicons } from '@expo/vector-icons'; // icono checkmark para los pasos completados
import { COLORES } from '../constantes/colores'; // paleta de colores del sistema de diseño
import { FUENTES, TAMANOS } from '../constantes/tipografia'; // familias tipográficas y tamaños de fuente
import { DISENO } from '../constantes/diseno'; // constantes de layout (paddings, radios, alturas)
import { urlApiBase } from '../servicios/api';

/** Mensajes de progreso que se muestran secuencialmente durante la "generación" del plan. */
const PASOS_CARGA = [
  'Analizando tu perfil...',
  'Calculando tu plan de entrenamiento...',
  'Personalizando rutinas...',
  'Finalizando tu plan...',
];

/**
 * Pantalla de carga animada post-onboarding.
 *
 * @param {object}   props
 * @param {Function} props.onPlanListo - Callback que se invoca al completar todos los pasos de carga.
 * @returns {JSX.Element}
 */
export default function GenerandoPlan({ onPlanListo, usuarioId }) {
  /** Índice del paso de carga actualmente activo (0 a PASOS_CARGA.length - 1). */
  const [pasoActual, setPasoActual] = useState(0);

  useEffect(() => {
    const DEMO_ID = '11111111-1111-1111-1111-111111111111';
    const idAUsar = usuarioId || DEMO_ID;

    const generarPlanReal = async () => {
      try {
        const response = await fetch(`${urlApiBase}/plan/generar?usuario_id=${idAUsar}`, {
          method: 'POST',
        });
        const data = await response.json();

        if (data.exito && data.plan) {
          setTimeout(() => onPlanListo && onPlanListo(data.plan), 2000);
        } else {
          Alert.alert('Error de IA', data.mensaje || 'No se pudo generar el plan de entrenamiento.');
        }
      } catch (e) {
        Alert.alert('Error Crítico', 'No se pudo conectar al servidor para generar el plan.');
      }
    };

    generarPlanReal();

    const intervalo = setInterval(() => {
      setPasoActual(prev => {
        if (prev < PASOS_CARGA.length - 1) return prev + 1;
        clearInterval(intervalo);
        return prev;
      });
    }, 1500);

    return () => clearInterval(intervalo);
  }, []);

  /** Porcentaje de progreso basado en el paso actual sobre el total de pasos. */
  const porcentaje = Math.round(((pasoActual + 1) / PASOS_CARGA.length) * 100);

  return (
    <View style={s.contenedor}>

      <View style={s.logoWrapper}>
        <Text style={s.logoTexto}>F</Text>
      </View>

      <Text style={s.titulo}>Generando tu plan</Text>
      <Text style={s.subtitulo}>La IA está creando tu plan{'\n'}personalizado</Text>

      {/* Lista de pasos con dot indicador y check al completarse */}
      <View style={s.pasosContenedor}>
        {PASOS_CARGA.map((paso, i) => (
          <View key={i} style={s.pasoFila}>
            <View style={[s.pasoDot, i <= pasoActual && s.pasoDotActivo]} />
            <Text style={[s.pasoTexto, i <= pasoActual && s.pasoTextoActivo]}>
              {paso}
            </Text>
            {i <= pasoActual && (
              <Ionicons name="checkmark" size={TAMANOS.base} color={COLORES.exito} />
            )}
          </View>
        ))}
      </View>

      {/* Barra de progreso global */}
      <View style={s.barraFondo}>
        <View style={[s.barraRelleno, { width: `${porcentaje}%` }]} />
      </View>
      <Text style={s.porcentaje}>{porcentaje}%</Text>

    </View>
  );
}

const s = StyleSheet.create({
  contenedor: {
    flex: 1,
    backgroundColor: COLORES.oscuro,
    paddingHorizontal: DISENO.paddingH,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoWrapper: {
    width: 80, height: 80, borderRadius: 22,
    backgroundColor: COLORES.primario,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 32,
  },
  logoTexto: {
    fontFamily: FUENTES.negrita,
    fontSize: 36, color: COLORES.blanco,
  },
  titulo: {
    fontFamily: FUENTES.negrita,
    fontSize: TAMANOS.h1,
    color: COLORES.blanco,
    textAlign: 'center',
    marginBottom: 12,
  },
  subtitulo: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.lg,
    color: COLORES.subtitulo,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 48,
  },
  pasosContenedor: {
    width: '100%',
    gap: 14,
    marginBottom: 40,
  },
  pasoFila: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  pasoDot: {
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: COLORES.borde,
  },
  pasoDotActivo: {
    backgroundColor: COLORES.primario,
  },
  pasoTexto: {
    flex: 1,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo,
  },
  pasoTextoActivo: {
    color: COLORES.blanco,
    fontFamily: FUENTES.medio,
  },
  barraFondo: {
    width: '100%', height: 6,
    backgroundColor: COLORES.tarjeta,
    borderRadius: 3, overflow: 'hidden',
    marginBottom: 8,
  },
  barraRelleno: {
    height: 6,
    backgroundColor: COLORES.primario,
    borderRadius: 3,
  },
  porcentaje: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
  },
});

/**
 * @file Progreso.jsx
 * @description HU1 — Resumen de progreso del usuario. Muestra frecuencia de
 *              entrenamiento, evolución de peso y tendencia, con filtros por período.
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';
import servicioMetricas from '../servicios/servicio-metricas';

const PERIODOS = [
  { id: 'dia',    label: 'Día' },
  { id: 'semana', label: 'Semana' },
  { id: 'mes',    label: 'Mes' },
];

const MOCK_FRECUENCIA = { dia: 1, semana: 4, mes: 14 };
const MOCK_VOLUMEN    = { dia: 2400, semana: 9800, mes: 38500 };

function calcularTendencia(metricas) {
  if (metricas.length < 2) return 'sin_datos';
  const ultimo   = metricas[0].peso_corporal_kg;
  const anterior = metricas[1].peso_corporal_kg;
  if (ultimo < anterior) return 'mejorando';
  if (ultimo > anterior) return 'retrocediendo';
  return 'manteniendo';
}

function formatearFecha(isoString) {
  const d = new Date(isoString);
  if (isNaN(d)) return isoString;
  return d.toLocaleDateString('es-CL', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

const TENDENCIA_META = {
  mejorando:    { texto: 'Mejorando',    icono: 'trending-up',   color: COLORES.exito },
  manteniendo:  { texto: 'Manteniendo', icono: 'remove-outline', color: COLORES.alerta },
  retrocediendo:{ texto: 'Retrocediendo',icono: 'trending-down', color: COLORES.error },
  sin_datos:    { texto: 'Sin datos',    icono: 'analytics-outline', color: COLORES.subtitulo },
};

const INSIGHTS = {
  mejorando:     'Tu peso está bajando. Mantén la constancia y asegúrate de consumir suficiente proteína para preservar músculo.',
  manteniendo:   'Tu peso se mantiene estable. Si tu objetivo es cambio corporal, considera ajustar la dieta o intensidad.',
  retrocediendo: 'Tu peso está subiendo. Revisa tu nivel de actividad física y el volumen de entrenamiento de tus sesiones para asegurar resultados.',
  sin_datos:     'Registra tus métricas periódicamente para ver tu evolución y recibir recomendaciones personalizadas.',
};

export default function Progreso({ usuario, onRegistrarMetricas }) {
  const [periodo, setPeriodo] = useState('semana');
  const [metricas, setMetricas] = useState([]);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    const cargar = async () => {
      setCargando(true);
      const datos = await servicioMetricas.obtener(usuario?.id || '11111111-1111-1111-1111-111111111111');
      setMetricas(datos);
      setCargando(false);
    };
    cargar();
  }, [usuario?.id]);

  const tendencia = calcularTendencia(metricas);
  const tendenciaMeta = TENDENCIA_META[tendencia];
  const pesoActual = metricas[0]?.peso_corporal_kg;

  return (
    <View style={s.contenedor}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>
        <Text style={s.titulo}>Tu Progreso</Text>

        {/* Filtros de período */}
        <View style={s.filtros}>
          {PERIODOS.map((p) => {
            const activo = periodo === p.id;
            return (
              <TouchableOpacity
                key={p.id}
                style={[s.chip, activo && s.chipActivo]}
                onPress={() => setPeriodo(p.id)}
                activeOpacity={0.7}
              >
                <Text style={[s.chipTexto, activo && s.chipTextoActivo]}>{p.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Métricas de entrenamiento */}
        <Text style={s.seccion}>Entrenamiento</Text>
        {cargando ? (
          <ActivityIndicator color={COLORES.primario} style={{ marginVertical: 20 }} />
        ) : (
          <>
            <View style={s.statsRow}>
              <View style={s.statCard}>
                <Ionicons name="calendar-outline" size={22} color={COLORES.primario} />
                <Text style={s.statValor}>{MOCK_FRECUENCIA[periodo]}</Text>
                <Text style={s.statLabel}>días entrenados</Text>
              </View>
              <View style={s.statCard}>
                <Ionicons name="barbell-outline" size={22} color={COLORES.primario} />
                <Text style={s.statValor}>{MOCK_VOLUMEN[periodo].toLocaleString('es-CL')}</Text>
                <Text style={s.statLabel}>kg de volumen</Text>
              </View>
              <View style={[s.statCard, { borderColor: tendenciaMeta.color }]}>
                <Ionicons name={tendenciaMeta.icono} size={22} color={tendenciaMeta.color} />
                <Text style={[s.statValor, { color: tendenciaMeta.color }]}>{tendenciaMeta.texto}</Text>
                <Text style={s.statLabel}>tendencia</Text>
              </View>
            </View>

            {/* Evolución física */}
            <Text style={s.seccion}>Evolución física</Text>
            {pesoActual ? (
              <View style={s.cardEvolucion}>
                <View style={s.pesoRow}>
                  <Text style={s.pesoLabel}>Peso actual</Text>
                  <Text style={s.pesoValor}>{pesoActual} kg</Text>
                </View>
                {metricas.slice(0, 4).map((m, i) => {
                  const anterior = metricas[i + 1];
                  const subio = anterior && m.peso_corporal_kg > anterior.peso_corporal_kg;
                  const bajo  = anterior && m.peso_corporal_kg < anterior.peso_corporal_kg;
                  return (
                    <View key={m.id} style={s.metricaFila}>
                      <Text style={s.metricaFecha}>{formatearFecha(m.fecha_registro)}</Text>
                      <View style={s.metricaDerecha}>
                        <Text style={s.metricaPeso}>{m.peso_corporal_kg} kg</Text>
                        {subio && <Ionicons name="arrow-up" size={14} color={COLORES.error} />}
                        {bajo  && <Ionicons name="arrow-down" size={14} color={COLORES.exito} />}
                        {!subio && !bajo && i > 0 && <Ionicons name="remove-outline" size={14} color={COLORES.subtitulo} />}
                      </View>
                    </View>
                  );
                })}
              </View>
            ) : (
              <View style={s.cardVacio}>
                <Text style={s.vacioTexto}>No hay métricas registradas aún.</Text>
              </View>
            )}

            {/* Insights */}
            <Text style={s.seccion}>Recomendación</Text>
            <View style={s.cardInsight}>
              <Ionicons name="bulb-outline" size={20} color={COLORES.alerta} style={{ marginBottom: 8 }} />
              <Text style={s.insightTexto}>{INSIGHTS[tendencia]}</Text>
            </View>
          </>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* FAB registrar métricas */}
      <TouchableOpacity style={s.fab} onPress={onRegistrarMetricas} activeOpacity={0.85}>
        <Ionicons name="add" size={28} color={COLORES.blanco} />
      </TouchableOpacity>
    </View>
  );
}

const s = StyleSheet.create({
  contenedor:       { flex: 1, backgroundColor: COLORES.oscuro },
  scroll:           { paddingHorizontal: DISENO.paddingH, paddingTop: 20, paddingBottom: 24 },
  titulo:           { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 20 },
  seccion:          { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 12, marginTop: 8 },
  filtros:          { flexDirection: 'row', gap: 10, marginBottom: 24 },
  chip:             { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.chip, borderWidth: 1, borderColor: COLORES.borde, height: DISENO.altoChip, paddingHorizontal: 20, justifyContent: 'center' },
  chipActivo:       { backgroundColor: COLORES.primario, borderColor: COLORES.primario },
  chipTexto:        { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  chipTextoActivo:  { fontFamily: FUENTES.medio, color: COLORES.blanco },
  statsRow:         { flexDirection: 'row', gap: 10, marginBottom: 24 },
  statCard:         { flex: 1, backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 14, alignItems: 'center', gap: 6, borderWidth: 1, borderColor: COLORES.borde },
  statValor:        { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  statLabel:        { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo, textAlign: 'center' },
  cardEvolucion:    { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 16, marginBottom: 24, borderWidth: 1, borderColor: COLORES.borde },
  pesoRow:          { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  pesoLabel:        { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  pesoValor:        { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco },
  metricaFila:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8, borderTopWidth: 1, borderTopColor: COLORES.borde },
  metricaFecha:     { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  metricaDerecha:   { flexDirection: 'row', alignItems: 'center', gap: 6 },
  metricaPeso:      { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  cardVacio:        { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 28, alignItems: 'center', borderStyle: 'dashed', borderWidth: 1, borderColor: COLORES.borde, marginBottom: 24 },
  vacioTexto:       { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  cardInsight:      { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 16, borderWidth: 1, borderColor: COLORES.borde, marginBottom: 12 },
  insightTexto:     { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, lineHeight: 22 },
  fab:              { position: 'absolute', bottom: 24, right: DISENO.paddingH, width: 56, height: 56, borderRadius: DISENO.radio.full, backgroundColor: COLORES.primario, alignItems: 'center', justifyContent: 'center', elevation: 4 },
});

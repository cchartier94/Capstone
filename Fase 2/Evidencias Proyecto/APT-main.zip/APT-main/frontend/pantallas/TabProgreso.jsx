/**
 * @file TabProgreso.jsx
 * @description Tab de progreso completo conectado al backend (SCRUM-35).
 *              Muestra métricas, gráfico de actividad, ejercicios destacados e insights.
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';
import FiltroPeriodo from '../componentes/FiltroPeriodo';
import TarjetaMetrica from '../componentes/TarjetaMetrica';
import GraficoBarras from '../componentes/GraficoBarras';
import TarjetaInsight from '../componentes/TarjetaInsight';
import servicioProgreso from '../servicios/servicio-progreso';

const ESTADO_ICONO = {
  mejora: { icono: 'arrow-up', color: COLORES.exito },
  estable: { icono: 'remove', color: COLORES.alerta },
  estancado: { icono: 'arrow-down', color: COLORES.error },
};

export default function TabProgreso({ usuarioId, onVolver }) {
  const [periodo, setPeriodo] = useState('semana');
  const [resumen, setResumen] = useState(null);
  const [insights, setInsights] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [refrescando, setRefrescando] = useState(false);

  const cargarDatos = useCallback(async () => {
    try {
      const [resumenData, insightsData] = await Promise.all([
        servicioProgreso.obtenerResumen(periodo, usuarioId),
        servicioProgreso.obtenerInsights(usuarioId),
      ]);
      if (resumenData.exito) setResumen(resumenData);
      if (insightsData.exito) setInsights(insightsData.insights || []);
    } catch (e) {
      console.warn('Error cargando progreso:', e);
    } finally {
      setCargando(false);
      setRefrescando(false);
    }
  }, [periodo, usuarioId]);

  useEffect(() => {
    setCargando(true);
    cargarDatos();
  }, [cargarDatos]);

  const onRefresh = () => {
    setRefrescando(true);
    cargarDatos();
  };

  if (cargando) {
    return (
      <View style={s.centrado}>
        <ActivityIndicator size="large" color={COLORES.primario} />
        <Text style={s.cargandoTexto}>Cargando progreso...</Text>
      </View>
    );
  }

  const metricas = resumen?.metricas || [];
  const grafico = resumen?.grafico_actividad || [];
  const ejercicios = resumen?.ejercicios_destacados || [];

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={s.contenido}
      refreshControl={
        <RefreshControl refreshing={refrescando} onRefresh={onRefresh} tintColor={COLORES.primario} />
      }
    >
      {onVolver && (
        <TouchableOpacity style={s.botonVolver} onPress={onVolver}>
          <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
          <Text style={s.volverTexto}>Volver al Perfil</Text>
        </TouchableOpacity>
      )}
      <Text style={s.titulo}>Tu Progreso</Text>

      {/* Filtro de período */}
      <FiltroPeriodo periodoActivo={periodo} onChange={setPeriodo} />

      {/* Banner Motivacional */}
      <View style={s.bannerMotivacional}>
        <View style={s.bannerIcono}>
          <Ionicons name="bulb" size={24} color={COLORES.alerta} />
        </View>
        <View style={s.bannerTextos}>
          <Text style={s.bannerTitulo}>Sugerencia del Coach</Text>
          <Text style={s.bannerDesc}>
            Recuerda registrar tus pesos y métricas físicas regularmente para que podamos adaptar mejor tu crecimiento.
          </Text>
        </View>
      </View>

      {/* Métricas principales */}
      {metricas.length > 0 && (
        <View style={s.metricasRow}>
          {metricas.map((m) => (
            <TarjetaMetrica
              key={m.etiqueta}
              etiqueta={m.etiqueta}
              valor={m.valor}
              unidad={m.unidad}
              tendencia={m.tendencia}
              cambioPorcentual={m.cambio_porcentual}
            />
          ))}
        </View>
      )}

      {/* Logros y Medallas */}
      <View style={s.seccion}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <Text style={[s.subtitulo, { marginBottom: 0 }]}>Tus Logros</Text>
          <View style={{ backgroundColor: 'rgba(108,99,255,0.15)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 }}>
            <Text style={{ fontFamily: FUENTES.semiNegrita, fontSize: 10, color: COLORES.primario }}>LOGROS ACTIVOS</Text>
          </View>
        </View>
        
        {resumen?.logros && resumen.logros.length > 0 ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 16, paddingVertical: 8 }}>
            {resumen.logros.map((logro) => {
              const colorMedalla = logro.tipo === 'oro' ? '#FFD700' : logro.tipo === 'plata' ? '#C0C0C0' : '#CD7F32';
              const desbloqueado = !!logro.desbloqueado;
              
              return (
                <TouchableOpacity
                  key={logro.id}
                  style={s.medallaItem}
                  onPress={() => {
                    const statusText = desbloqueado ? '🏆 ¡Logro Completado!' : '🔒 Logro Bloqueado';
                    require('react-native').Alert.alert(
                      logro.nombre,
                      `${logro.descripcion}\n\nEstado: ${statusText}`
                    );
                  }}
                  activeOpacity={0.8}
                >
                  <View style={[
                    s.medallaCirculo, 
                    desbloqueado 
                      ? { 
                          backgroundColor: colorMedalla,
                          shadowColor: colorMedalla,
                          shadowOpacity: 0.6,
                          shadowRadius: 12,
                          shadowOffset: { width: 0, height: 4 }
                        }
                      : { 
                          backgroundColor: 'rgba(255,255,255,0.03)',
                          borderWidth: 1.5,
                          borderColor: 'rgba(255,255,255,0.08)'
                        }
                  ]}>
                    <Ionicons 
                      name={desbloqueado ? logro.icono : 'lock-closed'} 
                      size={24} 
                      color={desbloqueado ? '#FFF' : 'rgba(255,255,255,0.25)'} 
                    />
                  </View>
                  <Text style={[
                    s.medallaTexto, 
                    !desbloqueado && { color: 'rgba(255,255,255,0.4)' }
                  ]}>
                    {logro.nombre}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        ) : (
          <View style={s.cardVacio}>
            <Text style={s.vacioTexto}>No hay logros configurados en este momento.</Text>
          </View>
        )}
      </View>

      {/* Gráfico de actividad */}
      {grafico.length > 0 && (
        <View style={s.seccion}>
          <GraficoBarras datos={grafico} titulo="Actividad de entrenamiento" />
        </View>
      )}

      {/* Ejercicios destacados */}
      {ejercicios.length > 0 && (
        <View style={s.seccion}>
          <Text style={s.subtitulo}>Ejercicios destacados</Text>
          {ejercicios.map((ej) => {
            const cfg = ESTADO_ICONO[ej.estado] || ESTADO_ICONO.estable;
            return (
              <View key={ej.nombre} style={s.ejercicioItem}>
                <View style={s.ejercicioInfo}>
                  <Text style={s.ejercicioNombre}>{ej.nombre}</Text>
                  <Text style={s.ejercicioGrupo}>{ej.grupo_muscular}</Text>
                </View>
                <Text style={[s.ejercicioProg, { color: cfg.color }]}>
                  {ej.progreso_porcentual > 0 ? '+' : ''}{ej.progreso_porcentual}%
                </Text>
              </View>
            );
          })}
        </View>
      )}

      {/* Insights IA */}
      <View style={s.seccion}>
        <Text style={s.subtitulo}>Recomendaciones IA</Text>
        {insights.length > 0 ? (
          <View style={s.insightsLista}>
            {insights.map((ins, i) => (
              <TarjetaInsight
                key={`${ins.titulo}-${i}`}
                tipo={ins.tipo}
                icono={ins.icono}
                titulo={ins.titulo}
                descripcion={ins.descripcion}
              />
            ))}
          </View>
        ) : (
          <View style={s.cardVacio}>
            <Text style={s.vacioTexto}>Completa más entrenamientos para recibir consejos personalizados.</Text>
          </View>
        )}
      </View>

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  contenido: { paddingHorizontal: DISENO.paddingH, paddingBottom: 100 },
  centrado: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  cargandoTexto: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginTop: 12 },
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 16, marginTop: 20 },
  subtitulo: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 12 },
  metricasRow: { flexDirection: 'row', gap: 10, marginTop: 20 },
  seccion: { marginTop: 24 },
  ejercicioItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg,
    padding: 14, marginBottom: 8, borderWidth: 1, borderColor: COLORES.borde,
  },
  ejercicioInfo: { flex: 1 },
  ejercicioNombre: { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 2 },
  ejercicioGrupo: { fontFamily: FUENTES.regular, fontSize: 13, color: COLORES.subtitulo },
  ejercicioProg: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base },
  insightsLista: { gap: 12 },
  medallaItem: { alignItems: 'center', width: 80 },
  medallaCirculo: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  medallaTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.xs, color: COLORES.blanco, textAlign: 'center' },
  cardVacio: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.lg,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORES.borde,
    borderStyle: 'dashed',
  },
  vacioTexto: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
    textAlign: 'center',
  },
  bannerMotivacional: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 193, 7, 0.1)',
    borderRadius: DISENO.radio.lg,
    padding: 16,
    marginTop: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 193, 7, 0.3)',
    alignItems: 'center',
  },
  bannerIcono: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 193, 7, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  bannerTextos: {
    flex: 1,
  },
  bannerTitulo: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.base,
    color: COLORES.alerta,
    marginBottom: 4,
  },
  bannerDesc: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.sm,
    color: COLORES.blanco,
    lineHeight: 20,
  },
  botonVolver: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 16 },
  volverTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
});

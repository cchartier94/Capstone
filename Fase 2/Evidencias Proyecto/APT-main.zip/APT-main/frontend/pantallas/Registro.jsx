/**
 * @file Registro.jsx
 * @description Pantalla de creación de cuenta. Valida nombre, correo, contraseña y su confirmación.
 *              La persistencia real (Supabase Auth) está pendiente; actualmente simula un delay de 800 ms.
 */

import React, { useState } from 'react'; // hook de estado
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, ScrollView, Platform,
} from 'react-native'; // componentes de UI y utilidades de teclado/plataforma
import { COLORES } from '../constantes/colores'; // paleta de colores del sistema de diseño
import { FUENTES, TAMANOS } from '../constantes/tipografia'; // familias tipográficas y tamaños de fuente
import { DISENO } from '../constantes/diseno'; // constantes de layout (paddings, radios, alturas)

/**
 * Pantalla de registro de nuevo usuario.
 *
 * @param {object}   props
 * @param {Function} props.onVolver           - Regresa a la pantalla de Bienvenida.
 * @param {Function} props.onRegistroExitoso  - Callback tras registro exitoso (navega a onboarding).
 * @returns {JSX.Element}
 */
export default function Registro({ onVolver, onRegistroExitoso }) {
  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [confirmar, setConfirmar] = useState('');
  const [verContrasena, setVerContrasena] = useState(false);
  const [verConfirmar, setVerConfirmar] = useState(false);
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);

  /**
   * Valida todos los campos del formulario de registro.
   *
   * @returns {string|null} Mensaje de error, o null si el formulario es válido.
   */
  const validar = () => {
    if (!nombre.trim()) return 'El nombre es obligatorio';
    if (!correo.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo))
      return 'Ingresa un correo válido';
    if (contrasena.length < 6) return 'La contraseña debe tener mínimo 6 caracteres';
    if (contrasena !== confirmar) return 'Las contraseñas no coinciden';
    return null;
  };

  /**
   * Maneja el submit del formulario: valida y llama a `onRegistroExitoso` si todo está correcto.
   */
  const handleRegistro = async () => {
    const err = validar();
    if (err) { setError(err); return; }
    setError('');
    setCargando(true);
    try {
      const BACKEND_URL = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';

      const res = await fetch(`${BACKEND_URL}/auth/registro`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre, correo, contrasena }),
      });

      const data = await res.json();
      if (data.exito) {
        // Pasamos nombre e ID al estado global de App.js
        onRegistroExitoso && onRegistroExitoso({ 
          nombre, 
          correo, 
          id: data.datos_guardados.usuario_id 
        });
      } else {
        setError(data.mensaje || 'Error al registrar. Intenta otro correo.');
      }
    } catch (e) {
      setError('No se pudo conectar con el servidor.');
    } finally {
      setCargando(false);
    }
  };

  /** True cuando todos los campos tienen contenido; habilita el botón principal. */
  const esValido = nombre.trim() && correo.trim() && contrasena && confirmar;

  return (
    <KeyboardAvoidingView
      style={s.contenedor}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={s.circuloFondo} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>

        <TouchableOpacity style={s.btnVolver} onPress={onVolver}>
          <Text style={s.btnVolverTexto}>← Volver</Text>
        </TouchableOpacity>

        <Text style={s.titulo}>Crea tu cuenta</Text>
        <Text style={s.subtitulo}>Únete a FitAI</Text>

        <Text style={s.etiqueta}>Nombre completo</Text>
        <TextInput
          style={s.campo}
          placeholder="Tu nombre"
          placeholderTextColor={COLORES.subtitulo}
          value={nombre}
          onChangeText={t => { setNombre(t); setError(''); }}
          autoCapitalize="words"
        />

        <Text style={s.etiqueta}>Correo electrónico</Text>
        <TextInput
          style={s.campo}
          placeholder="tu@correo.com"
          placeholderTextColor={COLORES.subtitulo}
          value={correo}
          onChangeText={t => { setCorreo(t); setError(''); }}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />

        <Text style={s.etiqueta}>Contraseña</Text>
        <View style={s.campoWrapper}>
          <TextInput
            style={s.campoConIcono}
            placeholder="Mínimo 6 caracteres"
            placeholderTextColor={COLORES.subtitulo}
            value={contrasena}
            onChangeText={t => { setContrasena(t); setError(''); }}
            secureTextEntry={!verContrasena}
            dataSet={{ noreveal: true }}
          />
          <TouchableOpacity style={s.btnVer} onPress={() => setVerContrasena(v => !v)}>
            <Text style={s.btnVerTexto}>{verContrasena ? 'Ocultar' : 'Ver'}</Text>
          </TouchableOpacity>
        </View>

        <Text style={s.etiqueta}>Confirmar contraseña</Text>
        <View style={s.campoWrapper}>
          <TextInput
            style={s.campoConIcono}
            placeholder="Repite tu contraseña"
            placeholderTextColor={COLORES.subtitulo}
            value={confirmar}
            onChangeText={t => { setConfirmar(t); setError(''); }}
            secureTextEntry={!verConfirmar}
            dataSet={{ noreveal: true }}
          />
          <TouchableOpacity style={s.btnVer} onPress={() => setVerConfirmar(v => !v)}>
            <Text style={s.btnVerTexto}>{verConfirmar ? 'Ocultar' : 'Ver'}</Text>
          </TouchableOpacity>
        </View>

        {!!error && <Text style={s.mensajeError}>{error}</Text>}

        <TouchableOpacity
          style={[s.boton, (!esValido || cargando) && s.botonDesactivado]}
          onPress={handleRegistro}
          disabled={!esValido || cargando}
          activeOpacity={0.8}
        >
          <Text style={s.botonTexto}>{cargando ? 'Creando cuenta...' : 'Crear cuenta'}</Text>
        </TouchableOpacity>

        <View style={s.linkContainer}>
          <Text style={s.linkTexto}>¿Ya tienes cuenta? </Text>
          <TouchableOpacity onPress={onVolver}>
            <Text style={s.link}>Inicia sesión</Text>
          </TouchableOpacity>
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  contenedor: { flex: 1, backgroundColor: COLORES.oscuro },
  circuloFondo: {
    position: 'absolute',
    width: 500, height: 500, borderRadius: 250,
    backgroundColor: COLORES.primario, opacity: 0.08,
    top: 0, left: -55,
  },
  scroll: {
    paddingHorizontal: DISENO.paddingH,
    paddingTop: 60,
    paddingBottom: 40,
  },
  btnVolver: { marginBottom: 32 },
  btnVolverTexto: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.base,
    color: COLORES.primario,
  },
  titulo: {
    fontFamily: FUENTES.negrita,
    fontSize: TAMANOS.h1,
    color: COLORES.blanco,
    marginBottom: 8,
  },
  subtitulo: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo,
    marginBottom: 32,
  },
  etiqueta: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
    marginBottom: 8,
  },
  campo: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    height: DISENO.altoBoton,
    paddingHorizontal: 16,
    color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    marginBottom: 20,
  },
  campoWrapper: { position: 'relative', marginBottom: 20 },
  campoConIcono: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    height: DISENO.altoBoton,
    paddingHorizontal: 16, paddingRight: 64,
    color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
  },
  btnVer: { position: 'absolute', right: 16, top: 16 },
  btnVerTexto: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
  },
  mensajeError: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.sm,
    color: COLORES.error,
    marginBottom: 12,
  },
  boton: {
    backgroundColor: COLORES.primario,
    borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 24,
  },
  botonDesactivado: { opacity: 0.4 },
  botonTexto: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.lg,
    color: COLORES.blanco,
  },
  linkContainer: { flexDirection: 'row', justifyContent: 'center' },
  linkTexto: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo,
  },
  link: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.base,
    color: COLORES.primario,
  },
});

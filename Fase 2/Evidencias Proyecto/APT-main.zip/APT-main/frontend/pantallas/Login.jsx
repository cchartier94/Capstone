/**
 * @file Login.jsx
 * @description Pantalla de inicio de sesión. Valida correo y contraseña antes de llamar al callback.
 *              La autenticación real (JWT) está pendiente; actualmente simula un delay de 800 ms.
 */

import React, { useState } from 'react'; // hook de estado
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, ScrollView, Platform,
} from 'react-native'; // componentes de UI y utilidades de teclado/plataforma
import { COLORES } from '../constantes/colores'; // paleta de colores del sistema de diseño
import { FUENTES, TAMANOS } from '../constantes/tipografia'; // familias tipográficas y tamaños de fuente
import { DISENO } from '../constantes/diseno'; // constantes de layout (paddings, radios, alturas)
import { urlApiBase } from '../servicios/api';

/**
 * Pantalla de login con campos de correo y contraseña.
 *
 * @param {object}   props
 * @param {Function} props.onIrRegistro   - Navega a la pantalla de Registro.
 * @param {Function} props.onIrRecuperar  - Navega a RecuperarContrasena.
 * @param {Function} props.onLoginExitoso - Callback tras autenticación exitosa (navega a onboarding).
 * @returns {JSX.Element}
 */
export default function Login({ onIrRegistro, onIrRecuperar, onLoginExitoso }) {
  const [correo, setCorreo] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [verContrasena, setVerContrasena] = useState(false);
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);

  /**
   * Valida el formulario antes de enviar.
   *
   * @returns {string|null} Mensaje de error, o null si es válido.
   */
  const validar = () => {
    if (!correo.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo))
      return 'Ingresa un correo válido';
    if (!contrasena) return 'Ingresa tu contraseña';
    return null;
  };

  /**
   * Maneja el submit del formulario: valida, simula la llamada al backend
   * y llama a `onLoginExitoso` si todo está correcto.
   */
  const handleLogin = async () => {
    const err = validar();
    if (err) { setError(err); return; }
    setError('');
    setCargando(true);
    try {
      const response = await fetch(`${urlApiBase}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          correo: correo.toLowerCase().trim(),
          contrasena: contrasena,
        })
      });
      
      if (!response.ok) throw new Error('Error al conectar con el servidor');
      
      const data = await response.json();
      if (data.exito && data.usuario) {
        onLoginExitoso && onLoginExitoso({ 
          correo: data.usuario.correo_electronico, 
          id: data.usuario.id, 
          nombre: data.usuario.nombre 
        });
      } else {
        setError(data.mensaje || 'Correo no registrado o datos incorrectos');
      }
    } catch (e) {
      setError('Error de conexión con el servidor. Intenta más tarde.');
    } finally {
      setCargando(false);
    }
  };

  /** True cuando ambos campos tienen contenido; habilita el botón. */
  const esValido = correo.trim() && contrasena;

  return (
    <KeyboardAvoidingView
      style={s.contenedor}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={s.circuloFondo} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>

        <View style={s.logo}>
          <Text style={s.logoTexto}>F</Text>
        </View>
        <Text style={s.titulo}>FitAI</Text>
        <Text style={s.subtitulo}>Inicia sesión en tu cuenta</Text>

        <Text style={s.etiqueta}>Correo electrónico</Text>
        <TextInput
          style={s.campo}
          placeholder="tu@correo.com"
          placeholderTextColor={COLORES.subtitulo}
          value={correo}
          onChangeText={t => { setCorreo(t); setError(''); }}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />

        <Text style={s.etiqueta}>Contraseña</Text>
        <View style={s.campoWrapper}>
          <TextInput
            style={s.campoConIcono}
            placeholder="Tu contraseña"
            placeholderTextColor={COLORES.subtitulo}
            value={contrasena}
            onChangeText={t => { setContrasena(t); setError(''); }}
            secureTextEntry={!verContrasena}
            dataSet={{ noreveal: true }}
          />
          <TouchableOpacity style={s.btnVer} onPress={() => setVerContrasena(v => !v)}>
            <Text style={s.btnVerTexto}>{verContrasena ? 'Ocultar' : 'Ver'}</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={onIrRecuperar}>
          <Text style={s.linkOlvide}>¿Olvidaste tu contraseña?</Text>
        </TouchableOpacity>

        {!!error && <Text style={s.mensajeError}>{error}</Text>}

        <TouchableOpacity
          style={[s.boton, (!esValido || cargando) && s.botonDesactivado]}
          onPress={handleLogin}
          disabled={!esValido || cargando}
          activeOpacity={0.8}
        >
          <Text style={s.botonTexto}>{cargando ? 'Entrando...' : 'Iniciar sesión'}</Text>
        </TouchableOpacity>

        <View style={s.linkContainer}>
          <Text style={s.linkTexto}>¿No tienes cuenta? </Text>
          <TouchableOpacity onPress={onIrRegistro}>
            <Text style={s.link}>Regístrate</Text>
          </TouchableOpacity>
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  contenedor: { flex: 1, backgroundColor: COLORES.oscuro },
  circuloFondo: {
    position: 'absolute',
    width: 500, height: 500, borderRadius: 250,
    backgroundColor: COLORES.primario, opacity: 0.08,
    top: 0, left: -55,
  },
  scroll: {
    paddingHorizontal: DISENO.paddingH,
    paddingTop: 80,
    paddingBottom: 40,
  },
  logo: {
    width: 72, height: 72, borderRadius: 20,
    backgroundColor: COLORES.primario,
    alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginBottom: 20,
  },
  logoTexto: {
    fontFamily: FUENTES.negrita,
    fontSize: 32, color: COLORES.blanco,
  },
  titulo: {
    fontFamily: FUENTES.negrita,
    fontSize: TAMANOS.h1,
    color: COLORES.blanco,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitulo: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo,
    textAlign: 'center',
    marginBottom: 40,
  },
  etiqueta: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
    marginBottom: 8,
  },
  campo: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    height: DISENO.altoBoton,
    paddingHorizontal: 16,
    color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    marginBottom: 20,
  },
  campoWrapper: { position: 'relative', marginBottom: 8 },
  campoConIcono: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    height: DISENO.altoBoton,
    paddingHorizontal: 16, paddingRight: 64,
    color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
  },
  btnVer: { position: 'absolute', right: 16, top: 16 },
  btnVerTexto: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo,
  },
  linkOlvide: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.primario,
    textAlign: 'right',
    marginBottom: 24,
    marginTop: 8,
  },
  mensajeError: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.sm,
    color: COLORES.error,
    marginBottom: 12,
    textAlign: 'center',
  },
  boton: {
    backgroundColor: COLORES.primario,
    borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 24,
  },
  botonDesactivado: { opacity: 0.4 },
  botonTexto: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.lg,
    color: COLORES.blanco,
  },
  linkContainer: { flexDirection: 'row', justifyContent: 'center' },
  linkTexto: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo,
  },
  link: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.base,
    color: COLORES.primario,
  },
});

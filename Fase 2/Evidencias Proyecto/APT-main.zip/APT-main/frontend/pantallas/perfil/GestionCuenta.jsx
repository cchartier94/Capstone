import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  StyleSheet, Alert, ActivityIndicator, SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import servicioCuenta from '../../servicios/servicio-cuenta';

export default function GestionCuenta({ usuario, onVolver, onCerrarSesion }) {
  const [eliminando, setEliminando] = useState(false);

  const confirmarEliminar = () => {
    Alert.alert(
      'Eliminar cuenta',
      '¿Estás seguro? Esta acción no se puede deshacer. Perderás tu perfil, plan y todo tu progreso de forma permanente.',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Eliminar', style: 'destructive', onPress: eliminarCuenta },
      ]
    );
  };

  const eliminarCuenta = async () => {
    setEliminando(true);
    await servicioCuenta.eliminarCuenta(usuario?.id);
    setEliminando(false);
    onCerrarSesion();
  };

  return (
    <SafeAreaView style={s.contenedor}>
      <ScrollView contentContainerStyle={s.contenido} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={s.botonVolver} onPress={onVolver}>
          <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
          <Text style={s.volverTexto}>Volver</Text>
        </TouchableOpacity>

        <Text style={s.titulo}>Gestión de cuenta</Text>
        <Text style={s.seccionLabel}>Sesión</Text>
        <TouchableOpacity style={s.fila} onPress={onCerrarSesion} activeOpacity={0.8}>
          <View style={[s.iconBg, { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
            <Ionicons name="log-out-outline" size={20} color={COLORES.blanco} />
          </View>
          <Text style={s.filaTexto}>Cerrar sesión</Text>
          <Ionicons name="chevron-forward" size={18} color={COLORES.subtitulo} style={{ marginLeft: 'auto' }} />
        </TouchableOpacity>

        <Text style={[s.seccionLabel, { marginTop: 32 }]}>Zona de peligro</Text>
        <View style={s.zonaCard}>
          <Text style={s.zonaDesc}>
            Al eliminar tu cuenta, todos tus datos dejarán de estar disponibles de forma permanente.
            No podrás acceder nuevamente con estas credenciales.
          </Text>
          <TouchableOpacity
            style={[s.botonEliminar, eliminando && { opacity: 0.5 }]}
            onPress={confirmarEliminar}
            disabled={eliminando}
            activeOpacity={0.8}
          >
            {eliminando
              ? <ActivityIndicator color={COLORES.error} />
              : <>
                  <Ionicons name="trash-outline" size={18} color={COLORES.error} />
                  <Text style={s.botonEliminarTexto}>Eliminar mi cuenta</Text>
                </>
            }
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  contenedor:         { flex: 1, backgroundColor: COLORES.oscuro },
  botonVolver:        { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 24 },
  volverTexto:        { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  titulo:             { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 24 },
  contenido:          { paddingHorizontal: DISENO.paddingH, paddingTop: 24, paddingBottom: 60 },
  seccionLabel:       { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.8 },
  fila:               { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: COLORES.tarjeta, borderRadius: 18, height: 56, paddingHorizontal: 16, borderWidth: 1, borderColor: COLORES.borde },
  iconBg:             { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  filaTexto:          { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  zonaCard:           { backgroundColor: 'rgba(230,77,77,0.06)', borderRadius: 18, padding: 20, borderWidth: 1, borderColor: 'rgba(230,77,77,0.2)' },
  zonaDesc:           { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo, lineHeight: 20, marginBottom: 20 },
  botonEliminar:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: 'rgba(230,77,77,0.1)', borderRadius: DISENO.radio.lg, height: DISENO.altoBoton, borderWidth: 1, borderColor: 'rgba(230,77,77,0.3)' },
  botonEliminarTexto: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.error },
});

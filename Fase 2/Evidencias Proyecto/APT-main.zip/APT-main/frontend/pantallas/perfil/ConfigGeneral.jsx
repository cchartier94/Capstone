/**
 * @file ConfigGeneral.jsx
 * @description Pantalla de configuración general (SCRUM-39).
 *              Permite al usuario configurar unidad de peso.
 *              Persiste los cambios en el backend y AsyncStorage.
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  StyleSheet, SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import servicioConfiguracion from '../../servicios/servicio-configuracion';

const UNIDADES = [
  { valor: 'kg', label: 'Kilogramos (kg)' },
  { valor: 'lb', label: 'Libras (lb)' },
];

export default function ConfigGeneral({ onVolver, onNavegar, usuarioId }) {
  const [unidadPeso, setUnidadPeso] = useState('kg');

  useEffect(() => {
    servicioConfiguracion.obtener(usuarioId).then((config) => {
      setUnidadPeso(config.general.unidadPeso);
    });
  }, [usuarioId]);

  const seleccionarUnidad = async (valor) => {
    setUnidadPeso(valor);
    await servicioConfiguracion.guardar({ general: { unidadPeso: valor } }, usuarioId);
  };

  return (
    <SafeAreaView style={s.contenedor}>
      <ScrollView contentContainerStyle={s.contenido} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={s.botonVolver} onPress={onVolver}>
          <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
          <Text style={s.volverTexto}>Volver</Text>
        </TouchableOpacity>

        <Text style={s.titulo}>Configuración</Text>

        <Text style={s.seccionLabel}>Unidad de peso</Text>
        {UNIDADES.map(({ valor, label }) => {
          const activo = unidadPeso === valor;
          return (
            <TouchableOpacity
              key={valor}
              style={[s.opcion, activo && s.opcionActiva]}
              onPress={() => seleccionarUnidad(valor)}
              activeOpacity={0.8}
            >
              <Text style={[s.opcionTexto, activo && s.opcionTextoActivo]}>{label}</Text>
              {activo && <Ionicons name="checkmark-circle" size={20} color={COLORES.primario} />}
            </TouchableOpacity>
          );
        })}

        <Text style={[s.seccionLabel, { marginTop: 32 }]}>Más ajustes</Text>
        <TouchableOpacity
          style={s.fila}
          onPress={() => onNavegar('config-notificaciones')}
          activeOpacity={0.8}
        >
          <View style={s.iconBg}>
            <Ionicons name="notifications-outline" size={20} color={COLORES.primario} />
          </View>
          <Text style={s.filaTexto}>Notificaciones</Text>
          <Ionicons name="chevron-forward" size={18} color={COLORES.subtitulo} style={{ marginLeft: 'auto' }} />
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  contenedor:         { flex: 1, backgroundColor: COLORES.oscuro },
  botonVolver:        { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 24 },
  volverTexto:        { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  titulo:             { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 24 },
  contenido:          { paddingHorizontal: DISENO.paddingH, paddingTop: 24, paddingBottom: 60 },
  seccionLabel:       { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.8 },
  opcion:             { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORES.tarjeta, borderRadius: 16, height: 56, paddingHorizontal: 18, marginBottom: 10, borderWidth: 1, borderColor: COLORES.borde },
  opcionActiva:       { borderColor: COLORES.primario, backgroundColor: 'rgba(108,99,255,0.08)' },
  opcionTexto:        { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  opcionTextoActivo:  { color: COLORES.blanco },
  fila:               { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: COLORES.tarjeta, borderRadius: 18, height: 56, paddingHorizontal: 16, borderWidth: 1, borderColor: COLORES.borde },
  iconBg:             { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(108,99,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  filaTexto:          { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
});

/**
 * @file ConfigNotificaciones.jsx
 * @description Pantalla de configuración de notificaciones (SCRUM-40).
 *              Permite activar/desactivar recordatorios de entrenamiento,
 *              alimentación y seguimiento.
 *              Persiste cambios en el backend y AsyncStorage.
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, Switch, ScrollView,
  StyleSheet, SafeAreaView, TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import servicioConfiguracion from '../../servicios/servicio-configuracion';
import servicioNotificaciones from '../../servicios/servicio-notificaciones';

const OPCIONES = [
  { clave: 'entrenamiento', label: 'Entrenamiento', desc: 'Recordatorio para tus sesiones',    icono: 'barbell-outline' },
  { clave: 'seguimiento',   label: 'Seguimiento',   desc: 'Actualizaciones de progreso y plan', icono: 'stats-chart-outline' },
];

export default function ConfigNotificaciones({ onVolver, usuarioId }) {
  const [notificaciones, setNotificaciones] = useState({
    entrenamiento: true,
    seguimiento: true,
    frecuencia: 'Diaria', // Diaria, Entrenamiento, Semanal
  });

  const [timers, setTimers] = useState({});
  const [permisoConcedido, setPermisoConcedido] = useState(false);

  useEffect(() => {
    if (typeof Notification !== 'undefined') {
      setPermisoConcedido(Notification.permission === 'granted');
    }
  }, []);

  const pedirPermiso = async () => {
    const res = await servicioNotificaciones.solicitarPermisoNavegador();
    setPermisoConcedido(res);
  };

  const programarDemo = (tipo, delay, titulo, mensaje) => {
    if (timers[tipo]) return;

    let segundos = delay;
    setTimers(prev => ({ ...prev, [tipo]: segundos }));

    const interval = setInterval(() => {
      segundos -= 1;
      if (segundos <= 0) {
        clearInterval(interval);
        setTimers(prev => {
          const copia = { ...prev };
          delete copia[tipo];
          return copia;
        });
        
        if (tipo === 'broadcast') {
          servicioNotificaciones.enviarBroadcastServidor(titulo, mensaje, 'info', 0);
        } else {
          servicioNotificaciones.mostrar(titulo, mensaje, tipo);
        }
      } else {
        setTimers(prev => ({ ...prev, [tipo]: segundos }));
      }
    }, 1000);
  };

  useEffect(() => {
    servicioConfiguracion.obtener(usuarioId).then((config) => {
      setNotificaciones(config.notificaciones);
    });
  }, [usuarioId]);

  const toggle = async (clave) => {
    const nuevo = { ...notificaciones, [clave]: !notificaciones[clave] };
    setNotificaciones(nuevo);
    await servicioConfiguracion.guardar({ notificaciones: nuevo }, usuarioId);
  };

  const cambiarFrecuencia = async (frecuencia) => {
    const nuevo = { ...notificaciones, frecuencia };
    setNotificaciones(nuevo);
    await servicioConfiguracion.guardar({ notificaciones: nuevo }, usuarioId);
  };

  return (
    <SafeAreaView style={s.contenedor}>
      <ScrollView contentContainerStyle={s.contenido} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={s.botonVolver} onPress={onVolver}>
          <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
          <Text style={s.volverTexto}>Volver</Text>
        </TouchableOpacity>

        <Text style={s.titulo}>Notificaciones</Text>
        <Text style={s.seccionLabel}>Recordatorios</Text>
        {OPCIONES.map(({ clave, label, desc, icono }) => (
          <View key={clave} style={s.fila}>
            <View style={s.iconBg}>
              <Ionicons name={icono} size={20} color={COLORES.primario} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.filaLabel}>{label}</Text>
              <Text style={s.filaDesc}>{desc}</Text>
            </View>
            <Switch
              value={notificaciones[clave]}
              onValueChange={() => toggle(clave)}
              trackColor={{ false: COLORES.borde, true: 'rgba(108,99,255,0.5)' }}
              thumbColor={notificaciones[clave] ? COLORES.primario : COLORES.subtitulo}
            />
          </View>
        ))}

        <Text style={[s.seccionLabel, { marginTop: 24 }]}>Frecuencia de Registro de Peso</Text>
        <View style={s.filaFrecuencia}>
          {['Diaria', 'Entrenamiento', 'Semanal'].map((opcion) => {
            const activo = notificaciones.frecuencia === opcion || (!notificaciones.frecuencia && opcion === 'Diaria');
            return (
              <TouchableOpacity
                key={opcion}
                style={[s.btnFrecuencia, activo && s.btnFrecuenciaActivo]}
                onPress={() => cambiarFrecuencia(opcion)}
                activeOpacity={0.7}
              >
                <Text style={[s.textoFrecuencia, activo && s.textoFrecuenciaActivo]}>
                  {opcion === 'Entrenamiento' ? 'Días entreno' : opcion}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={s.seccionDemo}>
          <Text style={s.tituloDemo}>Panel de Control de la Presentación 🚀</Text>
          <Text style={s.subDemo}>Usa estos botones para simular alertas reales con retardo, dándote tiempo para cambiar de pantalla y lucirlo en vivo.</Text>
          
          <TouchableOpacity 
            style={[s.btnDemo, permisoConcedido && s.btnDemoActivo]} 
            onPress={pedirPermiso}
            activeOpacity={0.7}
          >
            <Ionicons name={permisoConcedido ? "checkmark-circle" : "key-outline"} size={16} color={permisoConcedido ? COLORES.primario : COLORES.blanco} style={{ marginRight: 8 }} />
            <Text style={[s.btnDemoText, permisoConcedido && s.btnDemoTextActivo]}>
              {permisoConcedido ? "Permiso de Alertas Activo" : "Permitir Notificaciones en PC/Navegador"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[s.btnDemo, timers['entrenamiento'] && s.btnDemoActivo]} 
            onPress={() => programarDemo('entrenamiento', 10, 'FitAI Coach 🏋️‍♂️', '¡Es hora de entrenar! Tu rutina de Pecho y Tríceps está lista.')}
            activeOpacity={0.7}
          >
            <Text style={[s.btnDemoText, timers['entrenamiento'] && s.btnDemoTextActivo]}>
              {timers['entrenamiento'] ? `Enviando alerta en ${timers['entrenamiento']}s...` : 'Simular Alerta de Entrenamiento (10 segundos)'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[s.btnDemo, timers['seguimiento'] && s.btnDemoActivo]} 
            onPress={() => programarDemo('seguimiento', 5, 'Seguimiento de Peso 📊', 'Recuerda registrar tu peso de hoy para actualizar los gráficos.')}
            activeOpacity={0.7}
          >
            <Text style={[s.btnDemoText, timers['seguimiento'] && s.btnDemoTextActivo]}>
              {timers['seguimiento'] ? `Enviando alerta en ${timers['seguimiento']}s...` : 'Simular Alerta de Peso (5 segundos)'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[s.btnDemo, timers['broadcast'] && s.btnDemoActivo]} 
            onPress={() => programarDemo('broadcast', 5, 'Broadcast Global 📢', 'Notificación en vivo enviada desde el backend de FitAI.')}
            activeOpacity={0.7}
          >
            <Text style={[s.btnDemoText, timers['broadcast'] && s.btnDemoTextActivo]}>
              {timers['broadcast'] ? `Enviando broadcast en ${timers['broadcast']}s...` : 'Broadcast Servidor (5 segundos)'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  contenedor:  { flex: 1, backgroundColor: COLORES.oscuro },
  botonVolver: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 24 },
  volverTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  titulo:      { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 24 },
  contenido:   { paddingHorizontal: DISENO.paddingH, paddingTop: 24, paddingBottom: 60 },
  seccionLabel:{ fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.8 },
  fila:        { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: COLORES.tarjeta, borderRadius: 18, minHeight: 68, paddingHorizontal: 16, paddingVertical: 14, marginBottom: 10, borderWidth: 1, borderColor: COLORES.borde },
  iconBg:      { width: 38, height: 38, borderRadius: 12, backgroundColor: 'rgba(108,99,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  filaLabel:   { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 2 },
  filaDesc:    { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  filaFrecuencia:{ flexDirection: 'row', gap: 8, backgroundColor: COLORES.tarjeta, borderRadius: 18, padding: 8, borderWidth: 1, borderColor: COLORES.borde },
  btnFrecuencia: { flex: 1, paddingVertical: 12, alignItems: 'center', borderRadius: 12 },
  btnFrecuenciaActivo: { backgroundColor: 'rgba(108,99,255,0.15)' },
  textoFrecuencia: { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo },
  textoFrecuenciaActivo: { fontFamily: FUENTES.semiNegrita, color: COLORES.primario },
  seccionDemo: { marginTop: 32, backgroundColor: 'rgba(108,99,255,0.05)', borderRadius: 20, padding: 18, borderWidth: 1, borderColor: 'rgba(108,99,255,0.2)' },
  tituloDemo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.primario, marginBottom: 4, letterSpacing: 0.5 },
  subDemo: { fontFamily: FUENTES.regular, fontSize: 13, color: COLORES.subtitulo, marginBottom: 16, lineHeight: 18 },
  btnDemo: { flexDirection: 'row', backgroundColor: COLORES.tarjeta, borderRadius: 14, minHeight: 48, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: COLORES.borde, marginBottom: 10, paddingHorizontal: 12 },
  btnDemoActivo: { borderColor: COLORES.primario, backgroundColor: 'rgba(108,99,255,0.1)' },
  btnDemoText: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.blanco },
  btnDemoTextActivo: { color: COLORES.primario, fontFamily: FUENTES.semiNegrita },
});

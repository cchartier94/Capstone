/**
 * @file TabPerfil.jsx
 * @description Pantalla de perfil del usuario (SCRUM-38).
 *              Muestra información personal, objetivo, contexto de entrenamiento,
 *              estado del plan activo y accesos rápidos a otras secciones.
 *              Carga datos reales desde el backend al montar.
 */

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import servicioPerfil from '../../servicios/servicio-perfil';

const OBJETIVOS = {
  bajar_grasa:            'Bajar grasa',
  ganar_masa_muscular:    'Ganar masa muscular',
  mantencion:             'Mantención',
  recomposicion_corporal: 'Recomposición corporal',
  mejorar_rendimiento:    'Mejorar rendimiento',
  // Valores que vienen directos del backend (sin normalizar)
  'Bajar grasa':            'Bajar grasa',
  'Ganar masa muscular':    'Ganar masa muscular',
  'Mantención':             'Mantención',
  'Recomposición corporal': 'Recomposición corporal',
  'Mejorar rendimiento':    'Mejorar rendimiento',
};

export default function TabPerfil({ usuario, plan, onCerrarSesion, onNavegar }) {
  const [perfil, setPerfil] = useState(null);
  const [cargando, setCargando] = useState(true);

  // Cargar datos del perfil desde el backend
  useEffect(() => {
    const cargarPerfil = async () => {
      const id = usuario?.id;
      if (!id) {
        setCargando(false);
        return;
      }
      try {
        const res = await servicioPerfil.obtenerPerfil(id);
        if (res.exito && res.datos_guardados) {
          setPerfil(res.datos_guardados);
        }
      } catch (e) {
        console.warn('Error cargando perfil:', e.message);
      } finally {
        setCargando(false);
      }
    };
    cargarPerfil();
  }, [usuario?.id]);

  // Combinar datos: priorizar perfil del backend, fallback a props del usuario
  const datos = {
    nombre:           perfil?.nombre           || usuario?.nombre          || 'Usuario',
    correo:           usuario?.correo          || '',
    edad:             perfil?.edad             || usuario?.edad            || null,
    sexo:             perfil?.sexo_biologico   || usuario?.sexo            || null,
    peso:             perfil?.peso_actual_kg   || usuario?.peso            || null,
    estatura:         perfil?.estatura_cm      || usuario?.estatura        || null,
    objetivo:         perfil?.objetivo_principal || usuario?.objetivo      || null,
    nivelActividad:   perfil?.nivel_actividad  || usuario?.nivelActividad  || null,
    nivelExperiencia: perfil?.nivel_experiencia || usuario?.nivelExperiencia || null,
    tipoEntrenamiento: perfil?.tipo_entrenamiento || null,
  };

  const inicial = datos.nombre?.charAt(0)?.toUpperCase() || 'U';

  // Calcular semanas restantes del plan
  const calcularSemanasRestantes = () => {
    if (!plan) return null;
    try {
      const fechaCreacion = plan.fecha_creacion ? new Date(plan.fecha_creacion) : null;
      const duracionMeses = plan.duracion_meses || plan.duracion || 1;
      if (fechaCreacion) {
        const fechaFin = new Date(fechaCreacion);
        fechaFin.setMonth(fechaFin.getMonth() + duracionMeses);
        const ahora = new Date();
        const diffMs = fechaFin - ahora;
        const semanasRestantes = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24 * 7)));
        return semanasRestantes;
      }
    } catch {}
    return null;
  };

  const semanasRestantes = calcularSemanasRestantes();

  const textoPlan = () => {
    if (!plan) return 'Sin plan activo';
    if (semanasRestantes !== null && semanasRestantes > 0) {
      return `Plan activo — ${semanasRestantes} semana${semanasRestantes !== 1 ? 's' : ''} restante${semanasRestantes !== 1 ? 's' : ''}`;
    }
    return 'Plan activo';
  };

  if (cargando) {
    return (
      <View style={[s.contenido, { flex: 1, justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={COLORES.primario} />
      </View>
    );
  }

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.contenido}>
      <Text style={s.titulo}>Mi Perfil</Text>

      <LinearGradient colors={[COLORES.tarjeta, COLORES.superficie]} style={s.header}>
        <View style={s.avatar}>
          <Text style={s.avatarLetra}>{inicial}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={s.nombre}>{datos.nombre}</Text>
          <Text style={s.correo}>{datos.correo}</Text>
        </View>
      </LinearGradient>

      <View style={s.seccion}>
        <Text style={s.seccionLabel}>Información personal</Text>
        <View style={s.grid}>
          <Ficha label="Edad"     valor={datos.edad      ? `${datos.edad} años`   : '—'} icono="calendar-outline" />
          <Ficha label="Sexo"     valor={datos.sexo      || '—'}                           icono="person-outline" />
          <Ficha label="Peso"     valor={datos.peso      ? `${datos.peso} kg`     : '—'} icono="barbell-outline" />
          <Ficha label="Estatura" valor={datos.estatura  ? `${datos.estatura} cm` : '—'} icono="resize-outline" />
        </View>
      </View>

      <View style={s.seccion}>
        <Text style={s.seccionLabel}>Objetivo</Text>
        <View style={s.chipObjetivo}>
          <Ionicons name="flag-outline" size={16} color={COLORES.primario} />
          <Text style={s.chipObjetivoTexto}>
            {OBJETIVOS[datos.objetivo] || datos.objetivo || 'Sin definir'}
          </Text>
        </View>
      </View>

      <View style={s.seccion}>
        <Text style={s.seccionLabel}>Contexto de entrenamiento</Text>
        <View style={s.filaContexto}>
          <ContextoItem label="Nivel de actividad" valor={datos.nivelActividad   || '—'} />
          <ContextoItem label="Experiencia"        valor={datos.nivelExperiencia || '—'} />
        </View>
        {datos.tipoEntrenamiento && (
          <View style={[s.filaContexto, { marginTop: 10 }]}>
            <ContextoItem label="Tipo de entrenamiento" valor={datos.tipoEntrenamiento} />
          </View>
        )}
      </View>

      <View style={s.seccion}>
        <Text style={s.seccionLabel}>Plan</Text>
        <View style={[s.planBadge, !plan && s.planBadgeInactivo]}>
          <Ionicons
            name={plan ? 'checkmark-circle' : 'ellipse-outline'}
            size={16}
            color={plan ? COLORES.exito : COLORES.subtitulo}
          />
          <Text style={[s.planTexto, !plan && s.planTextoInactivo]}>
            {textoPlan()}
          </Text>
        </View>
      </View>

      <View style={s.seccion}>
        <Text style={s.seccionLabel}>Accesos rápidos</Text>
        <BotonNavegar icono="document-text-outline" label="Ver mi plan"           onPress={() => onNavegar('planes')}               acento />
        <BotonNavegar icono="trending-up-outline"   label="Ver progreso"          onPress={() => onNavegar('progreso')}             acento />
        <BotonNavegar icono="settings-outline"      label="Configuración"         onPress={() => onNavegar('config-general')}       />
        <BotonNavegar icono="notifications-outline"  label="Notificaciones"        onPress={() => onNavegar('config-notificaciones')} />
        <BotonNavegar icono="shield-outline"        label="Gestión de cuenta"     onPress={() => onNavegar('gestion-cuenta')}       />
      </View>

      <TouchableOpacity style={s.botonCerrar} onPress={onCerrarSesion} activeOpacity={0.8}>
        <Ionicons name="log-out-outline" size={20} color="#ff4444" />
        <Text style={s.botonCerrarTexto}>Cerrar Sesión</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function Ficha({ label, valor, icono }) {
  return (
    <View style={s.ficha}>
      <Ionicons name={icono} size={18} color={COLORES.primario} style={{ marginBottom: 8 }} />
      <Text style={s.fichaValor}>{valor}</Text>
      <Text style={s.fichaLabel}>{label}</Text>
    </View>
  );
}

function ContextoItem({ label, valor }) {
  return (
    <View style={s.contextoItem}>
      <Text style={s.contextoValor}>{valor}</Text>
      <Text style={s.contextoLabel}>{label}</Text>
    </View>
  );
}

function BotonNavegar({ icono, label, onPress, acento }) {
  const colorIcono = acento ? COLORES.primario : COLORES.blanco;
  const bgIcono    = acento ? 'rgba(108,99,255,0.1)' : 'rgba(255,255,255,0.05)';
  return (
    <TouchableOpacity style={s.botonNavegar} onPress={onPress} activeOpacity={0.8}>
      <View style={[s.botonNavegarIconBg, { backgroundColor: bgIcono }]}>
        <Ionicons name={icono} size={20} color={colorIcono} />
      </View>
      <Text style={s.botonNavegarTexto}>{label}</Text>
      <Ionicons name="chevron-forward" size={18} color={COLORES.subtitulo} style={{ marginLeft: 'auto' }} />
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  contenido:           { paddingHorizontal: DISENO.paddingH, paddingBottom: 100, paddingTop: 20 },
  titulo:              { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 20 },
  header:              { flexDirection: 'row', alignItems: 'center', gap: 16, padding: 20, borderRadius: 20, borderWidth: 1, borderColor: COLORES.borde, marginBottom: 24 },
  avatar:              { width: 60, height: 60, borderRadius: 30, backgroundColor: COLORES.primario, alignItems: 'center', justifyContent: 'center' },
  avatarLetra:         { fontFamily: FUENTES.negrita, fontSize: 24, color: COLORES.blanco },
  nombre:              { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 2 },
  correo:              { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  seccion:             { marginBottom: 24 },
  seccionLabel:        { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.8 },
  grid:                { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  ficha:               { flex: 1, minWidth: '45%', backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, padding: 16, borderWidth: 1, borderColor: COLORES.borde },
  fichaValor:          { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 2 },
  fichaLabel:          { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo },
  chipObjetivo:        { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(108,99,255,0.1)', borderRadius: DISENO.radio.chip, paddingHorizontal: 16, paddingVertical: 10, borderWidth: 1, borderColor: 'rgba(108,99,255,0.3)', alignSelf: 'flex-start' },
  chipObjetivoTexto:   { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.base, color: COLORES.primario },
  filaContexto:        { flexDirection: 'row', gap: 10 },
  contextoItem:        { flex: 1, backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, padding: 16, borderWidth: 1, borderColor: COLORES.borde },
  contextoValor:       { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 2 },
  contextoLabel:       { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo },
  planBadge:           { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(51,199,143,0.1)', borderRadius: DISENO.radio.chip, paddingHorizontal: 16, paddingVertical: 10, borderWidth: 1, borderColor: 'rgba(51,199,143,0.3)', alignSelf: 'flex-start' },
  planBadgeInactivo:   { backgroundColor: COLORES.tarjeta, borderColor: COLORES.borde },
  planTexto:           { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.base, color: COLORES.exito },
  planTextoInactivo:   { color: COLORES.subtitulo },
  botonNavegar:        { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: COLORES.tarjeta, borderRadius: 18, height: 56, paddingHorizontal: 16, marginBottom: 10, borderWidth: 1, borderColor: COLORES.borde },
  botonNavegarIconBg:  { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  botonNavegarTexto:   { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  botonCerrar:         { backgroundColor: 'rgba(255,68,68,0.1)', borderRadius: 18, height: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, borderWidth: 1, borderColor: 'rgba(255,68,68,0.2)' },
  botonCerrarTexto:    { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: '#ff4444' },
});

/**
 * @file DetallePlan.jsx
 * @description HU3 — Vista detallada de un plan seleccionado del historial.
 *              Muestra resumen del plan y, si existe, la rutina semanal completa.
 */

import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';

const ESTADO_ESTILOS = {
  activo:     { color: COLORES.exito,    fondo: COLORES.exitoFondo, label: 'Activo' },
  completado: { color: COLORES.subtitulo, fondo: COLORES.tarjeta,   label: 'Completado' },
  cancelado:  { color: COLORES.alerta,   fondo: '#2A1E0D',          label: 'Cancelado' },
};

function formatearFecha(isoString) {
  const d = new Date(isoString);
  if (isNaN(d)) return isoString;
  return d.toLocaleDateString('es-CL', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function FilaMeta({ icono, label, valor }) {
  return (
    <View style={s.filaMeta}>
      <Ionicons name={icono} size={16} color={COLORES.subtitulo} />
      <Text style={s.filaLabel}>{label}</Text>
      <Text style={s.filaValor}>{valor}</Text>
    </View>
  );
}

export default function DetallePlan({ plan, onVolver }) {
  if (!plan) {
    return (
      <View style={[s.contenedor, { alignItems: 'center', justifyContent: 'center' }]}>
        <Text style={{ color: COLORES.subtitulo }}>Plan no disponible</Text>
      </View>
    );
  }

  const estado = ESTADO_ESTILOS[plan.estado] || ESTADO_ESTILOS.completado;
  const rutinaSemana = plan.respuesta_raw_ia?.semana;

  return (
    <View style={s.contenedor}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={onVolver} style={s.botonVolver} activeOpacity={0.7}>
          <Ionicons name="arrow-back" size={22} color={COLORES.blanco} />
        </TouchableOpacity>
        <Text style={s.headerTitulo} numberOfLines={1}>Detalle del Plan</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>
        {/* Badge estado */}
        <View style={[s.badge, { backgroundColor: estado.fondo, alignSelf: 'flex-start', marginBottom: 16 }]}>
          <Text style={[s.badgeTexto, { color: estado.color }]}>{estado.label}</Text>
        </View>

        {/* Título del plan */}
        <Text style={s.planTitulo}>
          {plan.respuesta_raw_ia?.nombre_plan || plan.objetivo_seleccionado}
        </Text>

        {/* Resumen */}
        {plan.respuesta_raw_ia?.resumen && (
          <Text style={s.planResumen}>{plan.respuesta_raw_ia.resumen}</Text>
        )}

        {/* Card de metadatos */}
        <View style={s.cardMeta}>
          <FilaMeta icono="trophy-outline"   label="Objetivo"  valor={plan.objetivo_seleccionado} />
          <FilaMeta icono="calendar-outline" label="Creado"    valor={formatearFecha(plan.fecha_creacion)} />
          <FilaMeta icono="time-outline"     label="Duración"  valor={`${plan.duracion_meses} ${plan.duracion_meses === 1 ? 'mes' : 'meses'}`} />
        </View>

        {/* Rutina semanal */}
        {Array.isArray(rutinaSemana) ? (
          <>
            <Text style={s.seccion}>Plan de entrenamiento</Text>
            {rutinaSemana.map((diaObj, idx) => (
              <View key={idx} style={s.cardDia}>
                <Text style={s.diaNombre}>{diaObj.dia}</Text>
                {diaObj.rutina === 'Descanso' || !Array.isArray(diaObj.rutina) ? (
                  <Text style={s.descanso}>Día de descanso</Text>
                ) : (
                  diaObj.rutina.map((ej, i) => (
                    <View key={i} style={s.ejercicioFila}>
                      <View style={s.ejercicioIcono}>
                        <Ionicons name="fitness" size={16} color={COLORES.primario} />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={s.ejercicioNombre}>{ej.nombre}</Text>
                        <Text style={s.ejercicioDetalle}>
                          {ej.series} series x {ej.reps} reps{ej.descanso ? ` • ${ej.descanso}` : ''}
                        </Text>
                      </View>
                    </View>
                  ))
                )}
              </View>
            ))}
          </>
        ) : (
          <View style={s.cardVacio}>
            <Text style={s.vacioTexto}>Detalle de rutina no disponible para este plan.</Text>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  contenedor:      { flex: 1, backgroundColor: COLORES.oscuro },
  header:          { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: DISENO.paddingH, paddingTop: 56, paddingBottom: 16, backgroundColor: COLORES.superficie, borderBottomWidth: 1, borderBottomColor: COLORES.borde },
  botonVolver:     { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitulo:    { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco, flex: 1, textAlign: 'center' },
  scroll:          { paddingHorizontal: DISENO.paddingH, paddingTop: 24, paddingBottom: 24 },
  badge:           { paddingHorizontal: 12, paddingVertical: 5, borderRadius: DISENO.radio.chip },
  badgeTexto:      { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm },
  planTitulo:      { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 8 },
  planResumen:     { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, lineHeight: 22, marginBottom: 20 },
  cardMeta:        { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 16, borderWidth: 1, borderColor: COLORES.borde, marginBottom: 24, gap: 12 },
  filaMeta:        { flexDirection: 'row', alignItems: 'center', gap: 10 },
  filaLabel:       { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo, flex: 1 },
  filaValor:       { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  seccion:         { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 12 },
  cardDia:         { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: COLORES.borde },
  diaNombre:       { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.base, color: COLORES.primario, marginBottom: 10 },
  descanso:        { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  ejercicioFila:   { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, borderTopWidth: 1, borderTopColor: COLORES.borde },
  ejercicioIcono:  { width: 32, height: 32, borderRadius: DISENO.radio.sm, backgroundColor: COLORES.superficie, alignItems: 'center', justifyContent: 'center' },
  ejercicioNombre: { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 2 },
  ejercicioDetalle:{ fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  cardVacio:       { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 24, alignItems: 'center', borderStyle: 'dashed', borderWidth: 1, borderColor: COLORES.borde },
  vacioTexto:      { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, textAlign: 'center' },
});

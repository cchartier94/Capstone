import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import servicioCoach from '../../servicios/servicio-coach';
import AsyncStorage from '@react-native-async-storage/async-storage';

let nextId = 1;

function crearMensaje(rol, contenido, esError = false) {
  return { id: nextId++, rol, contenido, esError, timestamp: new Date() };
}

function formatearHora(fecha) {
  return fecha.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
}

export default function ChatCoach({ usuario, plan }) {
  const [mensajes, setMensajes] = useState([]);
  const [inputTexto, setInputTexto] = useState('');
  const [enviando, setEnviando] = useState(false);
  const scrollRef = useRef(null);
  const contextoRef = useRef({
    plan_id: plan?.id,
    nombre: usuario?.nombre,
    objetivo: usuario?.objetivo,
    plan_nombre: plan?.nombre_plan,
    plan_resumen: plan?.resumen,
  });
  const primeraVezRef = useRef(true);

  const STORAGE_KEY = `@chat_coach_${usuario?.id}`;

  useEffect(() => {
    const cargarHistorial = async () => {
      try {
        const guardado = await AsyncStorage.getItem(STORAGE_KEY);
        if (guardado) {
          const parseado = JSON.parse(guardado);
          const conFechas = parseado.map(m => ({ ...m, timestamp: new Date(m.timestamp) }));
          setMensajes(conFechas);
          // Actualizar nextId para que no choque
          if (conFechas.length > 0) {
            nextId = Math.max(...conFechas.map(m => m.id)) + 1;
          }
          return;
        }
      } catch (e) {
        console.warn('Error al cargar chat:', e);
      }
      
      // Si no hay guardado, iniciamos
      const bienvenida = crearMensaje(
        'coach',
        `Hola ${usuario?.nombre || 'atleta'}, soy tu coach de entrenamiento. Tengo acceso a tu plan "${plan?.nombre_plan || 'personalizado'}". ¿En qué te puedo ayudar hoy?`
      );
      setMensajes([bienvenida]);
    };
    cargarHistorial();
  }, [usuario?.id]); // Quitamos el plan.id de aquí para que no borre solo al abrir

  // Escuchar cambios de plan
  useEffect(() => {
    if (plan?.id && plan?.id !== contextoRef.current?.plan_id) {
      contextoRef.current = {
        plan_id: plan.id,
        nombre: usuario?.nombre,
        objetivo: usuario?.objetivo,
        plan_nombre: plan.nombre_plan,
        plan_resumen: plan.resumen,
      };
      primeraVezRef.current = true; // Reiniciar contexto
    }
  }, [plan?.id]);

  // Guardar mensajes cada vez que cambien (si no está vacío)
  useEffect(() => {
    if (mensajes.length > 0) {
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(mensajes)).catch(e => console.warn(e));
    }
  }, [mensajes]);

  const nuevoChat = async () => {
    try {
      await AsyncStorage.removeItem(STORAGE_KEY);
    } catch (e) {}
    const bienvenida = crearMensaje(
      'coach',
      `Hola ${usuario?.nombre || 'atleta'}, soy tu coach de entrenamiento. Tengo acceso a tu plan "${plan?.nombre_plan || 'personalizado'}". ¿En qué te puedo ayudar hoy?`
    );
    setMensajes([bienvenida]);
  };

  function scrollAlFinal() {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  }

  async function enviar() {
    const texto = inputTexto.trim();
    if (!texto || enviando) return;

    const msgUsuario = crearMensaje('usuario', texto);
    setMensajes(prev => {
      scrollAlFinal();
      return [...prev, msgUsuario];
    });
    setInputTexto('');
    setEnviando(true);

    const historial = mensajes.map(m => ({ rol: m.rol, contenido: m.contenido }));
    const contexto = primeraVezRef.current ? contextoRef.current : null;
    primeraVezRef.current = false;

    const res = await servicioCoach.enviarMensaje(usuario?.id, texto, historial, contexto);

    const msgCoach = crearMensaje(
      'coach',
      res.exito ? res.respuesta : 'Lo siento, ocurrió un error de conexión con el Coach de IA. Por favor, verifica tu conexión o inténtalo de nuevo.',
      !res.exito
    );
    setMensajes(prev => {
      scrollAlFinal();
      return [...prev, msgCoach];
    });
    setEnviando(false);
  }

  const puedeEnviar = inputTexto.trim().length > 0 && !enviando;

  return (
    <View style={s.contenedor}>
      <View style={s.header}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 }}>
          <View style={s.headerIcono}>
            <Ionicons name="chatbubble-ellipses" size={20} color={COLORES.primario} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitulo}>Coach IA</Text>
            <Text style={s.headerSub}>Tu asistente personal de fitness</Text>
          </View>
        </View>
        <TouchableOpacity style={s.btnNuevoChat} onPress={nuevoChat} activeOpacity={0.7}>
          <Ionicons name="refresh" size={16} color={COLORES.blanco} />
          <Text style={s.textoNuevoChat}>Nuevo chat</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        ref={scrollRef}
        style={s.listaMensajes}
        contentContainerStyle={s.listaMensajesContenido}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={scrollAlFinal}
      >
        {mensajes.map(msg => (
          <View
            key={msg.id}
            style={[s.filaMensaje, msg.rol === 'usuario' ? s.filaUsuario : s.filaCoach]}
          >
            <View style={[
              s.burbuja,
              msg.rol === 'usuario' ? s.burbujaUsuario : s.burbujaCoach,
              msg.esError && s.burbujaError,
            ]}>
              <Text style={[
                s.textoBurbuja,
                msg.esError && s.textoError,
              ]}>
                {msg.contenido}
              </Text>
            </View>
            <Text style={s.hora}>{formatearHora(msg.timestamp)}</Text>
          </View>
        ))}

        {enviando && (
          <View style={[s.filaMensaje, s.filaCoach]}>
            <View style={[s.burbuja, s.burbujaCoach, s.burbujaCargando]}>
              <ActivityIndicator size="small" color={COLORES.primario} />
            </View>
          </View>
        )}
      </ScrollView>

      <View style={s.inputRow}>
        <TextInput
          style={s.input}
          placeholder="Escribe tu pregunta..."
          placeholderTextColor={COLORES.subtitulo}
          value={inputTexto}
          onChangeText={setInputTexto}
          multiline
          maxHeight={100}
          onSubmitEditing={enviar}
        />
        <TouchableOpacity
          style={[s.btnEnviar, !puedeEnviar && s.btnEnviarDisabled]}
          onPress={enviar}
          disabled={!puedeEnviar}
          activeOpacity={0.7}
        >
          <Ionicons
            name="send"
            size={18}
            color={puedeEnviar ? COLORES.primario : COLORES.borde}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  contenedor:          { flex: 1, backgroundColor: COLORES.oscuro, paddingBottom: 100 },
  header:              { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: DISENO.paddingH, paddingTop: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: COLORES.borde },
  headerIcono:         { width: 40, height: 40, borderRadius: 12, backgroundColor: 'rgba(108,99,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  headerTitulo:        { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  headerSub:           { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo },
  btnNuevoChat:        { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.1)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, gap: 4 },
  textoNuevoChat:      { fontFamily: FUENTES.medio, fontSize: 12, color: COLORES.blanco },
  listaMensajes:       { flex: 1 },
  listaMensajesContenido: { paddingHorizontal: DISENO.paddingH, paddingVertical: 16, gap: 12 },
  filaMensaje:         { maxWidth: '80%' },
  filaUsuario:         { alignSelf: 'flex-end' },
  filaCoach:           { alignSelf: 'flex-start' },
  burbuja:             { borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10 },
  burbujaUsuario:      { backgroundColor: COLORES.primario, borderBottomRightRadius: 4 },
  burbujaCoach:        { backgroundColor: COLORES.tarjeta, borderBottomLeftRadius: 4, borderWidth: 1, borderColor: COLORES.borde },
  burbujaError:        { backgroundColor: 'rgba(230,77,77,0.15)', borderColor: COLORES.error, borderWidth: 1 },
  burbujaCargando:     { paddingHorizontal: 20, paddingVertical: 12 },
  textoBurbuja:        { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.blanco, lineHeight: 20 },
  textoError:          { color: COLORES.error },
  hora:                { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo, marginTop: 4, paddingHorizontal: 4 },
  inputRow:            { flexDirection: 'row', alignItems: 'flex-end', gap: 10, paddingHorizontal: DISENO.paddingH, paddingVertical: 12, backgroundColor: COLORES.superficie, borderTopWidth: 1, borderTopColor: COLORES.borde },
  input:               { flex: 1, backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, paddingHorizontal: 14, paddingVertical: 10, color: COLORES.blanco, fontFamily: FUENTES.regular, fontSize: TAMANOS.base, borderWidth: 1, borderColor: COLORES.borde },
  btnEnviar:           { width: 40, height: 40, borderRadius: 12, backgroundColor: 'rgba(108,99,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  btnEnviarDisabled:   { opacity: 0.4 },
});

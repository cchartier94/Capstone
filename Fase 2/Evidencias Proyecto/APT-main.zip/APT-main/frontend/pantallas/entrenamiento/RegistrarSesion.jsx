import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, SafeAreaView, Alert, ActivityIndicator, Modal, FlatList, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import servicioEntrenamiento from '../../servicios/servicio-entrenamiento';

const DIAS_SEMANA_MAP = {
  0: 'Domingo', 1: 'Lunes', 2: 'Martes', 3: 'Miércoles',
  4: 'Jueves', 5: 'Viernes', 6: 'Sábado',
};

function normalizarDia(str) {
  return str.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
}

function filaVacia() {
  return { nombre: '', series: '', reps: '', peso_kg: '', descanso_segundos: '', esNuevo: true };
}

function formatearFecha(fecha) {
  return fecha.toLocaleDateString('es-CL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function calcularFechaCalendario(diaFijado) {
  if (!diaFijado) return new Date();
  const dias = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'];
  const hoy = new Date();
  let indiceHoyJS = hoy.getDay() - 1;
  if (indiceHoyJS === -1) indiceHoyJS = 6;
  
  const indiceFijado = dias.indexOf(diaFijado.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''));
  if (indiceFijado === -1) return new Date();
  
  const diferenciaDias = indiceFijado - indiceHoyJS;
  const fechaCalculada = new Date(hoy);
  fechaCalculada.setDate(hoy.getDate() + diferenciaDias);
  return fechaCalculada;
}

const CATALOGO_LOCAL = [
  { nombre: 'Sentadilla libre', grupo_muscular: 'Piernas' },
  { nombre: 'Prensa de piernas', grupo_muscular: 'Piernas' },
  { nombre: 'Extensiones de cuádriceps', grupo_muscular: 'Piernas' },
  { nombre: 'Curl de piernas acostado', grupo_muscular: 'Piernas' },
  { nombre: 'Elevación de talones', grupo_muscular: 'Piernas' },
  { nombre: 'Zancadas con mancuernas', grupo_muscular: 'Piernas' },
  { nombre: 'Press de Banca plano', grupo_muscular: 'Pecho' },
  { nombre: 'Press de Banca inclinado', grupo_muscular: 'Pecho' },
  { nombre: 'Aperturas con mancuernas', grupo_muscular: 'Pecho' },
  { nombre: 'Cruces de poleas', grupo_muscular: 'Pecho' },
  { nombre: 'Dominadas', grupo_muscular: 'Espalda' },
  { nombre: 'Remo con barra', grupo_muscular: 'Espalda' },
  { nombre: 'Remo en polea baja', grupo_muscular: 'Espalda' },
  { nombre: 'Jalón al pecho', grupo_muscular: 'Espalda' },
  { nombre: 'Press Militar', grupo_muscular: 'Hombros' },
  { nombre: 'Elevaciones laterales', grupo_muscular: 'Hombros' },
  { nombre: 'Pájaros con mancuerna', grupo_muscular: 'Hombros' },
  { nombre: 'Curl de bíceps con barra', grupo_muscular: 'Brazos' },
  { nombre: 'Curl de bíceps martillo', grupo_muscular: 'Brazos' },
  { nombre: 'Extensiones de tríceps en polea', grupo_muscular: 'Brazos' },
  { nombre: 'Press francés', grupo_muscular: 'Brazos' },
  { nombre: 'Plancha abdominal', grupo_muscular: 'Core' },
  { nombre: 'Crunches abdominales', grupo_muscular: 'Core' },
];

export default function RegistrarSesion({ usuarioId, plan, diaFijado, onVolver }) {
  const [ejercicios, setEjercicios] = useState([filaVacia()]);
  const [buscadorVisible, setBuscadorVisible] = useState(false);
  const [indiceSeleccionado, setIndiceSeleccionado] = useState(null);
  const [queryBusqueda, setQueryBusqueda] = useState('');
  const [resultadosBusqueda, setResultadosBusqueda] = useState(CATALOGO_LOCAL);
  const [buscando, setBuscando] = useState(false);

  const fechaObjetivo = calcularFechaCalendario(diaFijado);
  const [guardando, setGuardando] = useState(false);
  const [errores, setErrores] = useState({});

  const abrirBuscador = (index) => {
    setIndiceSeleccionado(index);
    setQueryBusqueda('');
    setResultadosBusqueda(CATALOGO_LOCAL);
    setBuscadorVisible(true);
  };

  const ejecutarBusqueda = async (text) => {
    setQueryBusqueda(text);
    if (!text.trim()) {
      setResultadosBusqueda(CATALOGO_LOCAL);
      return;
    }
    
    setBuscando(true);
    try {
      const res = await servicioEntrenamiento.buscarEjercicios(text);
      if (res.exito && res.resultados && res.resultados.length > 0) {
        setResultadosBusqueda(res.resultados);
      } else {
        const filtrados = CATALOGO_LOCAL.filter(e => 
          e.nombre.toLowerCase().includes(text.toLowerCase()) || 
          (e.grupo_muscular && e.grupo_muscular.toLowerCase().includes(text.toLowerCase()))
        );
        setResultadosBusqueda(filtrados);
      }
    } catch (e) {
      const filtrados = CATALOGO_LOCAL.filter(e => 
        e.nombre.toLowerCase().includes(text.toLowerCase()) || 
        (e.grupo_muscular && e.grupo_muscular.toLowerCase().includes(text.toLowerCase()))
      );
      setResultadosBusqueda(filtrados);
    } finally {
      setBuscando(false);
    }
  };

  const seleccionarEjercicio = (nombre) => {
    if (indiceSeleccionado !== null) {
      actualizarCampo(indiceSeleccionado, 'nombre', nombre);
    }
    setBuscadorVisible(false);
    setIndiceSeleccionado(null);
  };

  const hoy = new Date();

  useEffect(() => {
    if (!plan?.semana) return;
    const nombreHoy = DIAS_SEMANA_MAP[hoy.getDay()];
    const diaALoad = diaFijado || nombreHoy;
    const diaObj = plan.semana.find(d => normalizarDia(d.dia) === normalizarDia(diaALoad));
    
    if (diaObj && Array.isArray(diaObj.rutina) && diaObj.rutina.length > 0) {
      const cargarPesosPrevios = async () => {
        const exs = diaObj.rutina.map(ex => ({
          nombre: ex.nombre || '',
          series: '', reps: '', peso_kg: '', descanso_segundos: '',
          ultimo_peso: null
        }));
        setEjercicios(exs);

        for (let i = 0; i < exs.length; i++) {
          if (exs[i].nombre) {
            const res = await servicioEntrenamiento.obtenerUltimoPeso(exs[i].nombre, usuarioId);
            if (res.exito && res.peso_kg) {
              setEjercicios(prev => {
                const copia = [...prev];
                copia[i].ultimo_peso = res.peso_kg;
                return copia;
              });
            }
          }
        }
      };
      cargarPesosPrevios();
    }
  }, []);

  function actualizarCampo(index, campo, valor) {
    setEjercicios(prev => {
      const copia = [...prev];
      copia[index] = { ...copia[index], [campo]: valor };
      return copia;
    });
    if (errores[`${index}.${campo}`]) {
      setErrores(prev => { const e = { ...prev }; delete e[`${index}.${campo}`]; return e; });
    }
  }

  function agregarEjercicio() {
    setEjercicios(prev => [...prev, filaVacia()]);
  }

  function eliminarEjercicio(index) {
    if (ejercicios.length === 1) return;
    setEjercicios(prev => prev.filter((_, i) => i !== index));
    setErrores(prev => {
      const e = { ...prev };
      Object.keys(e).forEach(k => { if (k.startsWith(`${index}.`)) delete e[k]; });
      return e;
    });
  }

  function validar() {
    const nuevosErrores = {};
    ejercicios.forEach((ex, i) => {
      if (!ex.nombre.trim()) nuevosErrores[`${i}.nombre`] = 'Requerido';
      if (!ex.series.trim()) nuevosErrores[`${i}.series`] = 'Requerido';
      else if (isNaN(Number(ex.series)) || Number(ex.series) <= 0) nuevosErrores[`${i}.series`] = 'Número positivo';
      if (!ex.reps.trim()) nuevosErrores[`${i}.reps`] = 'Requerido';
      if (!ex.peso_kg.trim()) nuevosErrores[`${i}.peso_kg`] = 'Requerido';
      else if (isNaN(Number(ex.peso_kg)) || Number(ex.peso_kg) <= 0) nuevosErrores[`${i}.peso_kg`] = 'Número positivo';
      if (!ex.descanso_segundos.trim()) nuevosErrores[`${i}.descanso_segundos`] = 'Requerido';
      else if (isNaN(Number(ex.descanso_segundos)) || Number(ex.descanso_segundos) <= 0) nuevosErrores[`${i}.descanso_segundos`] = 'Número positivo';
    });
    return nuevosErrores;
  }

  async function guardar() {
    const erroresValidacion = validar();
    if (Object.keys(erroresValidacion).length > 0) {
      setErrores(erroresValidacion);
      if (Platform.OS === 'web') {
        alert('Revisa los campos en rojo.');
      } else {
        Alert.alert('Faltan datos', 'Revisa los campos en rojo.');
      }
      return;
    }
    setGuardando(true);
    const payload = ejercicios.map(ex => ({
      nombre: ex.nombre.trim(),
      series: parseInt(ex.series, 10),
      reps: ex.reps.trim(),
      peso_kg: parseFloat(ex.peso_kg),
      descanso_segundos: parseInt(ex.descanso_segundos, 10),
    }));

    const res = await servicioEntrenamiento.registrarSesion(
      usuarioId,
      payload,
      fechaObjetivo.toISOString().split('T')[0]
    );
    setGuardando(false);
    if (res.exito) {
      if (Platform.OS === 'web') {
        alert('Tu entrenamiento quedó guardado correctamente.');
        onVolver();
      } else {
        Alert.alert('Sesion registrada', 'Tu entrenamiento quedó guardado correctamente.', [
          { text: 'OK', onPress: onVolver },
        ]);
      }
    } else {
      if (Platform.OS === 'web') {
        alert(res.mensaje || 'No se pudo guardar la sesion. Intenta nuevamente.');
      } else {
        Alert.alert('Error', res.mensaje || 'No se pudo guardar la sesion. Intenta nuevamente.');
      }
    }
  }

  return (
    <SafeAreaView style={s.contenedor}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={s.contenido}
        keyboardShouldPersistTaps="handled"
      >
        <TouchableOpacity style={s.botonVolver} onPress={onVolver}>
          <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
          <Text style={s.volverTexto}>Cancelar</Text>
        </TouchableOpacity>

        <View style={s.headerContainer}>
          <Text style={s.titulo}>Registrar Sesion</Text>
          <Text style={s.fecha}>
            {diaFijado ? diaFijado.toUpperCase() + ' - ' : ''}
            {formatearFecha(fechaObjetivo)}
          </Text>
        </View>

        {ejercicios.map((ex, i) => (
          <View key={i} style={s.tarjetaEjercicio}>
            <View style={s.tarjetaHeader}>
              <Text style={s.tarjetaTitulo}>Ejercicio {i + 1}</Text>
              {ejercicios.length > 1 && (
                <TouchableOpacity onPress={() => eliminarEjercicio(i)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                  <Ionicons name="trash-outline" size={18} color={COLORES.error} />
                </TouchableOpacity>
              )}
            </View>

            <Text style={s.label}>Ejercicio</Text>
            {ex.esNuevo ? (
              <TouchableOpacity
                style={[s.input, errores[`${i}.nombre`] && s.inputError, { justifyContent: 'center' }]}
                onPress={() => abrirBuscador(i)}
                activeOpacity={0.7}
              >
                <Text style={{ color: ex.nombre ? COLORES.blanco : COLORES.subtitulo, fontFamily: FUENTES.regular, fontSize: TAMANOS.base }}>
                  {ex.nombre || "Seleccionar ejercicio..."}
                </Text>
              </TouchableOpacity>
            ) : (
              <View style={[s.input, { justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.02)', opacity: 0.7 }]}>
                <Text style={{ color: COLORES.blanco, fontFamily: FUENTES.medio, fontSize: TAMANOS.base }}>
                  {ex.nombre}
                </Text>
              </View>
            )}
            {errores[`${i}.nombre`] && <Text style={s.textoError}>{errores[`${i}.nombre`]}</Text>}

            <View style={s.fila}>
              <View style={s.mitad}>
                <Text style={s.label}>Series</Text>
                <TextInput
                  style={[s.input, errores[`${i}.series`] && s.inputError]}
                  placeholder="Ej: 4"
                  placeholderTextColor={COLORES.subtitulo}
                  keyboardType="numeric"
                  value={ex.series}
                  onChangeText={v => actualizarCampo(i, 'series', v)}
                />
                {errores[`${i}.series`] && <Text style={s.textoError}>{errores[`${i}.series`]}</Text>}
              </View>
              <View style={s.mitad}>
                <Text style={s.label}>Repeticiones</Text>
                <TextInput
                  style={[s.input, errores[`${i}.reps`] && s.inputError]}
                  placeholder="Ej: 8-10"
                  placeholderTextColor={COLORES.subtitulo}
                  value={ex.reps}
                  onChangeText={v => actualizarCampo(i, 'reps', v)}
                />
                {errores[`${i}.reps`] && <Text style={s.textoError}>{errores[`${i}.reps`]}</Text>}
              </View>
            </View>

            <View style={s.fila}>
              <View style={s.mitad}>
                <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end'}}>
                  <Text style={s.label}>Peso (kg)</Text>
                  {ex.ultimo_peso && (
                    <TouchableOpacity onPress={() => actualizarCampo(i, 'peso_kg', String(ex.ultimo_peso))}>
                      <Text style={s.labelUltimo}>Último: {ex.ultimo_peso}kg</Text>
                    </TouchableOpacity>
                  )}
                </View>
                <TextInput
                  style={[s.input, errores[`${i}.peso_kg`] && s.inputError]}
                  placeholder="Ej: 80"
                  placeholderTextColor={COLORES.subtitulo}
                  keyboardType="decimal-pad"
                  value={ex.peso_kg}
                  onChangeText={v => actualizarCampo(i, 'peso_kg', v)}
                />
                {errores[`${i}.peso_kg`] && <Text style={s.textoError}>{errores[`${i}.peso_kg`]}</Text>}
              </View>
              <View style={s.mitad}>
                <Text style={s.label}>Descanso (seg)</Text>
                <TextInput
                  style={[s.input, errores[`${i}.descanso_segundos`] && s.inputError]}
                  placeholder="Ej: 90"
                  placeholderTextColor={COLORES.subtitulo}
                  keyboardType="numeric"
                  value={ex.descanso_segundos}
                  onChangeText={v => actualizarCampo(i, 'descanso_segundos', v)}
                />
                {errores[`${i}.descanso_segundos`] && <Text style={s.textoError}>{errores[`${i}.descanso_segundos`]}</Text>}
              </View>
            </View>
          </View>
        ))}

        <TouchableOpacity style={s.btnAgregar} onPress={agregarEjercicio} activeOpacity={0.7}>
          <Ionicons name="add-circle-outline" size={20} color={COLORES.primario} />
          <Text style={s.btnAgregarTexto}>Agregar ejercicio</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[s.btnGuardar, guardando && s.btnGuardandoDisabled]}
          onPress={guardar}
          activeOpacity={0.8}
          disabled={guardando}
        >
          {guardando
            ? <ActivityIndicator size="small" color={COLORES.blanco} />
            : <Text style={s.btnGuardarTexto}>Guardar sesion</Text>
          }
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>

      <Modal
        animationType="slide"
        transparent={false}
        visible={buscadorVisible}
        onRequestClose={() => setBuscadorVisible(false)}
      >
        <SafeAreaView style={s.modalContenedor}>
          <View style={s.modalHeader}>
            <Text style={s.modalTitulo}>Buscar Ejercicio</Text>
            <TouchableOpacity style={s.btnModalCerrar} onPress={() => setBuscadorVisible(false)}>
              <Ionicons name="close" size={24} color={COLORES.blanco} />
            </TouchableOpacity>
          </View>

          <View style={s.modalBuscadorContainer}>
            <Ionicons name="search" size={18} color={COLORES.subtitulo} style={{ marginRight: 8 }} />
            <TextInput
              style={s.modalInput}
              placeholder="Buscar por nombre o músculo..."
              placeholderTextColor={COLORES.subtitulo}
              value={queryBusqueda}
              onChangeText={ejecutarBusqueda}
              autoFocus={true}
            />
            {queryBusqueda.length > 0 && (
              <TouchableOpacity onPress={() => ejecutarBusqueda('')}>
                <Ionicons name="close-circle" size={16} color={COLORES.subtitulo} />
              </TouchableOpacity>
            )}
          </View>

          {buscando ? (
            <ActivityIndicator size="large" color={COLORES.primario} style={{ marginTop: 40 }} />
          ) : (
            <FlatList
              data={resultadosBusqueda}
              keyExtractor={(item, index) => `${item.nombre}-${index}`}
              contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 10, paddingBottom: 40 }}
              ListHeaderComponent={
                queryBusqueda.trim().length > 0 ? (
                  <TouchableOpacity 
                    style={[s.itemEjercicio, { borderColor: COLORES.primario, backgroundColor: 'rgba(108,99,255,0.04)', marginBottom: 12 }]} 
                    onPress={() => seleccionarEjercicio(queryBusqueda.trim())}
                    activeOpacity={0.7}
                  >
                    <Ionicons name="create-outline" size={18} color={COLORES.primario} style={{ marginRight: 10 }} />
                    <View style={{ flex: 1 }}>
                      <Text style={[s.itemNombre, { color: COLORES.primario }]}>Usar: "{queryBusqueda.trim()}"</Text>
                      <Text style={s.itemGrupo}>Ejercicio Personalizado</Text>
                    </View>
                  </TouchableOpacity>
                ) : null
              }
              renderItem={({ item }) => (
                <TouchableOpacity style={s.itemEjercicio} onPress={() => seleccionarEjercicio(item.nombre)}>
                  <View style={{ flex: 1 }}>
                    <Text style={s.itemNombre}>{item.nombre}</Text>
                    <Text style={s.itemGrupo}>{item.grupo_muscular}</Text>
                  </View>
                  <Ionicons name="chevron-forward-outline" size={18} color={COLORES.subtitulo} />
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                <View style={{ alignItems: 'center', marginTop: 40 }}>
                  <Text style={{ color: COLORES.subtitulo, fontFamily: FUENTES.regular }}>No se encontraron ejercicios</Text>
                </View>
              }
            />
          )}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  contenedor:        { flex: 1, backgroundColor: COLORES.oscuro },
  contenido:         { paddingHorizontal: DISENO.paddingH, paddingTop: 16, paddingBottom: 60 },
  botonVolver:       { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 24 },
  volverTexto:       { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  titulo:            { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 4 },
  fecha:             { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 24 },
  tarjetaEjercicio:  { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.xl, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: COLORES.borde },
  tarjetaHeader:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  tarjetaTitulo:     { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.blanco },
  label:             { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 6 },
  input:             { backgroundColor: COLORES.superficie, borderRadius: DISENO.radio.md, height: 46, paddingHorizontal: 14, color: COLORES.blanco, fontFamily: FUENTES.regular, fontSize: TAMANOS.base, borderWidth: 1, borderColor: COLORES.borde, marginBottom: 12 },
  inputError:        { borderColor: COLORES.error },
  textoError:        { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.error, marginTop: -8, marginBottom: 8 },
  fila:              { flexDirection: 'row', gap: 12 },
  mitad:             { flex: 1 },
  btnAgregar:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, borderWidth: 1, borderColor: COLORES.primario, borderStyle: 'dashed', borderRadius: DISENO.radio.lg, height: 48, marginBottom: 20 },
  btnAgregarTexto:   { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.primario },
  btnGuardar:        { backgroundColor: COLORES.exito, borderRadius: DISENO.radio.lg, height: DISENO.altoBoton, alignItems: 'center', justifyContent: 'center' },
  btnGuardandoDisabled: { opacity: 0.6 },
  btnGuardarTexto:   { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  labelUltimo:       { fontFamily: FUENTES.medio, fontSize: TAMANOS.xs, color: COLORES.primario, marginBottom: 6 },
  modalContenedor:   { flex: 1, backgroundColor: COLORES.oscuro },
  modalHeader:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 },
  modalTitulo:       { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  btnModalCerrar:    { width: 36, height: 36, borderRadius: 10, backgroundColor: COLORES.tarjeta, alignItems: 'center', justifyContent: 'center' },
  modalBuscadorContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORES.tarjeta, borderRadius: 14, height: 48, paddingHorizontal: 14, marginHorizontal: 20, marginBottom: 16, borderWidth: 1, borderColor: COLORES.borde },
  modalInput:        { flex: 1, color: COLORES.blanco, fontFamily: FUENTES.regular, fontSize: TAMANOS.base },
  itemEjercicio:     { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORES.tarjeta, borderRadius: 16, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: COLORES.borde },
  itemNombre:        { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 2 },
  itemGrupo:         { fontFamily: FUENTES.regular, fontSize: 12, color: COLORES.subtitulo, textTransform: 'uppercase', letterSpacing: 0.5 },
});

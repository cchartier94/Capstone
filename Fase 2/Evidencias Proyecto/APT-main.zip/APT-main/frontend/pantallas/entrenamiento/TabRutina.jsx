import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Modal, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import Chip from '../../componentes/Chip';
import DetalleEjercicio from './DetalleEjercicio';
import servicioPlanes from '../../servicios/servicio-planes';
import servicioEntrenamiento from '../../servicios/servicio-entrenamiento';

let _diaGuardado = null;
let _scrollGuardado = 0;

const DIAS_SEMANA_MAP = {
  0: 'Domingo',
  1: 'Lunes',
  2: 'Martes',
  3: 'Miércoles',
  4: 'Jueves',
  5: 'Viernes',
  6: 'Sábado',
};

function normalizarDia(str) {
  return str
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .trim();
}

function obtenerAbreviatura(diaNombre) {
  return diaNombre.substring(0, 3);
}

export default function TabRutina({ nombre, usuarioId, plan, onIrRegistrar, onActualizarPlan }) {
  const hoyIndex = new Date().getDay();
  const nombreDiaHoy = DIAS_SEMANA_MAP[hoyIndex];
  const [diaSeleccionado, setDiaSeleccionado] = useState(_diaGuardado || nombreDiaHoy);
  const [ejercicioAbierto, setEjercicioAbierto] = useState(null);
  const [modalRutinasVisible, setModalRutinasVisible] = useState(false);
  
  const [evolucionando, setEvolucionando] = useState(false);
  const [ejerciciosCompletados, setEjerciciosCompletados] = useState({});

  React.useEffect(() => {
    setEjerciciosCompletados({});
  }, [diaSeleccionado]);

  const toggleEjercicio = (index) => {
    const nuevosCompletados = {
      ...ejerciciosCompletados,
      [index]: !ejerciciosCompletados[index]
    };
    setEjerciciosCompletados(nuevosCompletados);

    const todosMarcados = ejerciciosDelDia.length > 0 &&
      ejerciciosDelDia.every((_, idx) => nuevosCompletados[idx]);

    if (todosMarcados) {
      Alert.alert(
        "¡Excelente trabajo!",
        "Has marcado todos los ejercicios como listos. ¿Quieres registrar esta rutina de forma express?",
        [
          { text: "Cancelar", style: "cancel" },
          { 
            text: "Sí, registrar", 
            onPress: () => registrarRutinaExpress() 
          }
        ]
      );
    }
  };

  const registrarRutinaExpress = async () => {
    if (!plan || !onActualizarPlan) return;
    
    const payload = ejerciciosDelDia.map(ex => {
      let numSeries = 4;
      if (ex.series) {
        const parseado = parseInt(ex.series, 10);
        if (!isNaN(parseado)) numSeries = parseado;
      }
      
      const repsStr = ex.reps ? String(ex.reps) : "12";
      
      let descansoSeg = 60;
      if (ex.descanso) {
        const match = ex.descanso.match(/\d+/g);
        if (match && match.length > 0) {
          descansoSeg = parseInt(match[match.length - 1], 10);
        }
      }

      return {
        nombre: ex.nombre,
        series: numSeries,
        reps: repsStr,
        peso_kg: 0.0,
        descanso_segundos: descansoSeg
      };
    });

    const fechaHoyStr = new Date().toISOString().split('T')[0];
    
    const res = await servicioEntrenamiento.registrarSesion(
      usuarioId,
      payload,
      fechaHoyStr
    );

    if (res.exito) {
      const nuevosDias = [...(plan.dias_completados || []), diaSeleccionadoNorm];
      
      try {
        const resPlan = await servicioPlanes.obtenerPlanActivo(usuarioId);
        if (resPlan.exito && resPlan.plan) {
          onActualizarPlan(resPlan.plan);
        } else {
          onActualizarPlan({ ...plan, dias_completados: nuevosDias });
        }
      } catch (err) {
        onActualizarPlan({ ...plan, dias_completados: nuevosDias });
      }
      
      Alert.alert("¡Rutina Registrada!", "Tu sesión express ha sido guardada con éxito.");
    } else {
      Alert.alert("Error", res.mensaje || "No se pudo registrar la rutina.");
    }
  };

  const handleEvolucionar = async (feedback) => {
    if (!plan?.id) return;
    setEvolucionando(true);
    const res = await servicioPlanes.evolucionarPlan(plan.id, feedback);
    if (res.exito) {
      alert("Plan ajustado: " + res.mensaje);
      if (onActualizarPlan) onActualizarPlan();
    } else {
      alert("Error: " + res.mensaje);
    }
    setEvolucionando(false);
  };
  const scrollRef = React.useRef(null);

  React.useEffect(() => {
    if (scrollRef.current && _scrollGuardado > 0) {
      setTimeout(() => {
        scrollRef.current?.scrollTo({ x: _scrollGuardado, animated: false });
      }, 50);
    }
  }, []);

  const diasOrdenados = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'];
  const indiceHoyNorm = diasOrdenados.indexOf(normalizarDia(nombreDiaHoy));
  const indiceSelNorm = diasOrdenados.indexOf(normalizarDia(diaSeleccionado));
  const esFuturo = indiceSelNorm > indiceHoyNorm;
  const esHoy = indiceSelNorm === indiceHoyNorm;

  const handleScroll = (e) => {
    _scrollGuardado = e.nativeEvent.contentOffset.x;
  };

  const cambiarDia = (dia) => {
    _diaGuardado = dia;
    setDiaSeleccionado(dia);
  };

  const diasDelPlan = plan?.semana || [];

  const diaObj = diasDelPlan.find(
    d => normalizarDia(d.dia) === normalizarDia(diaSeleccionado)
  ) || diasDelPlan[0];

  const rutina = diaObj?.rutina;
  const esDescanso = !Array.isArray(rutina);
  const ejerciciosDelDia = Array.isArray(rutina) ? rutina : [];
  const rutinasDisponibles = diasDelPlan.filter(d => Array.isArray(d.rutina));

  const handleSwapRutina = (diaSeleccionadoSwap) => {
    if (!plan || !onActualizarPlan) return;
    
    const nuevaSemana = [...plan.semana];
    const idxDescanso = nuevaSemana.findIndex(d => normalizarDia(d.dia) === normalizarDia(diaSeleccionado));
    const idxEntreno = nuevaSemana.findIndex(d => normalizarDia(d.dia) === normalizarDia(diaSeleccionadoSwap));
    
    if (idxDescanso !== -1 && idxEntreno !== -1) {
      const rutinaTemp = nuevaSemana[idxDescanso].rutina;
      const tipoTemp = nuevaSemana[idxDescanso].tipo;
      
      nuevaSemana[idxDescanso].rutina = nuevaSemana[idxEntreno].rutina;
      nuevaSemana[idxDescanso].tipo = nuevaSemana[idxEntreno].tipo;
      
      nuevaSemana[idxEntreno].rutina = rutinaTemp;
      nuevaSemana[idxEntreno].tipo = tipoTemp;
      
      onActualizarPlan({ ...plan, semana: nuevaSemana });
      servicioPlanes.actualizarPlan(plan.id, { semana: nuevaSemana }).catch(e => console.warn('Error al persistir swap:', e));
      setModalRutinasVisible(false);
    }
  };

  if (!plan) {
    return (
      <View style={[s.contenido, { flex: 1, justifyContent: 'center', alignItems: 'center' }]}>
        <Ionicons name="document-text-outline" size={64} color={COLORES.subtitulo} />
        <Text style={[s.vacioTitulo, { marginTop: 16 }]}>Aún no tienes un plan</Text>
        <Text style={s.vacioDesc}>
          Ve a la pestaña "Planes" para que nuestro Coach IA genere una rutina perfecta para ti.
        </Text>
      </View>
    );
  }

  const diasCompletados = plan?.dias_completados || [];
  const diaSeleccionadoNorm = normalizarDia(diaSeleccionado);
  const estaCompletado = diasCompletados.includes(diaSeleccionadoNorm);
  const esDomingo = diaSeleccionadoNorm === 'domingo';

  if (ejercicioAbierto) {
    return (
      <DetalleEjercicio
        ejercicio={ejercicioAbierto}
        onVolver={() => setEjercicioAbierto(null)}
      />
    );
  }

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={s.contenido}
    >
      <View style={s.header}>
        <Text style={s.saludo}>Buen día, {nombre || 'Fitness'}</Text>
        <Text style={s.subtitulo}>{plan?.nombre_plan || 'Cargando tu plan...'}</Text>
      </View>

      {diasDelPlan.length > 0 && (
        <ScrollView
          ref={scrollRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={s.selectorDias}
          onMomentumScrollEnd={handleScroll}
          onScrollEndDrag={handleScroll}
          scrollEventThrottle={16}
        >
          {diasDelPlan.map((d, i) => (
            <View key={`${d.dia}-${i}`} style={s.chipWrapper}>
              <Chip
                label={obtenerAbreviatura(d.dia)}
                selected={normalizarDia(d.dia) === normalizarDia(diaSeleccionado)}
                onPress={() => cambiarDia(d.dia)}
              />
            </View>
          ))}
        </ScrollView>
      )}

      <LinearGradient
        colors={esDescanso ? [COLORES.tarjeta, COLORES.superficie] : [COLORES.primario, '#2ecc71']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={s.cardDia}
      >
        <Text style={s.cardLabel}>{diaObj?.dia?.toUpperCase() || 'HOY'}</Text>
        <Text style={s.cardTitulo}>
          {esDescanso ? 'Día de Descanso' : (diaObj?.tipo || 'Entrenamiento')}
        </Text>
        <Text style={s.cardSub}>{plan?.resumen || 'Plan personalizado por tu coach IA.'}</Text>
      </LinearGradient>

      {/* Banner de Evolución (Solo mostrar en Domingos) */}
      {esDomingo && (
        <View style={s.evolucionBanner}>
          <Text style={s.evolucionTitulo}>¿Cómo sentiste la semana?</Text>
          <Text style={s.evolucionSub}>La IA ajustará el peso y volumen para tu próxima semana basándose en tu feedback.</Text>
          {evolucionando ? (
            <Text style={{color: COLORES.primario, fontFamily: FUENTES.negrita, marginTop: 10}}>Re-calculando con Claude IA...</Text>
          ) : (
            <View style={s.evolucionBtns}>
              <TouchableOpacity style={s.btnEvol} onPress={() => handleEvolucionar('muy_facil')}>
                <Text style={s.btnEvolTxt}>Muy Fácil</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btnEvol, {backgroundColor: COLORES.borde}]} onPress={() => handleEvolucionar('bien')}>
                <Text style={s.btnEvolTxt}>Justo</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btnEvol, {backgroundColor: COLORES.error}]} onPress={() => handleEvolucionar('muy_dificil')}>
                <Text style={s.btnEvolTxt}>Muy Difícil</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      )}

      {esDescanso ? (
        <View style={s.cardVacio}>
          <Ionicons name="cafe-outline" size={36} color={COLORES.primario} style={{ marginBottom: 12 }} />
          <Text style={s.vacioTitulo}>Día de recuperación</Text>
          <Text style={s.vacioDesc}>
            Tu plan sugiere descanso hoy. Aprovecha para recuperarte y volver más fuerte mañana.
          </Text>
          {esHoy && rutinasDisponibles.length > 0 && (
            <TouchableOpacity 
              style={s.btnEvitarDescanso}
              onPress={() => setModalRutinasVisible(true)}
            >
              <Text style={s.btnEvitarDescansoTexto}>Adelantar Entrenamiento</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : estaCompletado ? (
        <View style={s.cardCompletado}>
          <Ionicons name="checkmark-circle" size={48} color={COLORES.exito} style={{ marginBottom: 12 }} />
          <Text style={s.completadoTitulo}>¡Día Completado!</Text>
          <Text style={s.completadoDesc}>
            Ya registraste tu entrenamiento para este día. ¡Buen trabajo!
          </Text>
        </View>
      ) : (
        <>
          <View style={s.seccionHeader}>
            <Text style={s.seccionTitulo}>Rutina del día</Text>
            <Text style={s.contadorEjercicios}>{ejerciciosDelDia.length} ejercicios</Text>
          </View>

          <View style={s.listaEjercicios}>
            {ejerciciosDelDia.length > 0 ? (
              ejerciciosDelDia.map((ex, i) => {
                const isChecked = !!ejerciciosCompletados[i];
                return (
                  <TouchableOpacity
                    key={i}
                    style={s.ejercicioItem}
                    activeOpacity={0.7}
                    onPress={() => setEjercicioAbierto(ex)}
                  >
                    <TouchableOpacity
                      style={[
                        s.ejercicioIconoCheckbox,
                        isChecked && { backgroundColor: 'rgba(46, 204, 113, 0.15)' }
                      ]}
                      onPress={() => toggleEjercicio(i)}
                      activeOpacity={0.8}
                    >
                      <Ionicons
                        name={isChecked ? "checkmark-circle" : "radio-button-off"}
                        size={26}
                        color={isChecked ? COLORES.exito : 'rgba(255,255,255,0.3)'}
                      />
                    </TouchableOpacity>
                    <View style={{ flex: 1 }}>
                      <Text style={[s.ejercicioNombre, isChecked && { textDecorationLine: 'line-through', color: COLORES.subtitulo }]}>{ex.nombre}</Text>
                      <Text style={s.ejercicioDetalle}>
                        {ex.series} series x {ex.reps} reps · {ex.descanso}
                      </Text>
                      {ex.grupo_muscular && (
                        <Text style={s.grupoBadge}>{ex.grupo_muscular}</Text>
                      )}
                    </View>
                    <Ionicons name="chevron-forward" size={16} color={COLORES.subtitulo} />
                  </TouchableOpacity>
                );
              })
            ) : (
              <View style={s.cardVacioSimple}>
                <Text style={s.vacioTexto}>Tu plan está siendo procesado...</Text>
              </View>
            )}
          </View>

          {onIrRegistrar && !esFuturo && !estaCompletado && (
            <TouchableOpacity style={s.btnRegistrar} onPress={() => onIrRegistrar(diaSeleccionadoNorm)} activeOpacity={0.8}>
              <Ionicons name="add-circle-outline" size={20} color={COLORES.blanco} />
              <Text style={s.btnRegistrarTexto}>Registrar sesión</Text>
            </TouchableOpacity>
          )}
        </>
      )}

      <Text style={[s.seccionTitulo, { marginTop: 24, marginBottom: 12 }]}>Estado del plan</Text>
      <View style={s.statsRow}>
        {[
          { etiqueta: 'Estado', valor: 'Óptimo', icon: 'flash' },
          { etiqueta: 'Fuerza', valor: '85%', icon: 'barbell' },
          { etiqueta: 'Meta', valor: 'Cerca', icon: 'trophy' },
        ].map(stat => (
          <View key={stat.etiqueta} style={s.statCard}>
            <View style={s.statIconoWrapper}>
              <Ionicons name={stat.icon} size={14} color={COLORES.primario} />
            </View>
            <Text style={s.statValor}>{stat.valor}</Text>
            <Text style={s.statEtiqueta}>{stat.etiqueta}</Text>
          </View>
        ))}
      </View>

      <View style={{ height: 16 }} />

      {/* Rutinas Rápidas Ocultas Temporalmente (No Funcionales) */}
      {/* 
      <Text style={[s.seccionTitulo, { marginBottom: 12 }]}>Rutinas Rápidas</Text>
      ...
      */}

      <View style={{ height: 32 }} />

      {/* Modal de Rutinas Disponibles */}
      <Modal
        visible={modalRutinasVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setModalRutinasVisible(false)}
      >
        <View style={s.modalOverlay}>
          <View style={s.modalContenido}>
            <View style={s.modalHeader}>
              <Text style={s.modalTitulo}>Elegir rutina para hoy</Text>
              <TouchableOpacity onPress={() => setModalRutinasVisible(false)} style={s.btnCerrarModal}>
                <Ionicons name="close" size={24} color={COLORES.subtitulo} />
              </TouchableOpacity>
            </View>
            <Text style={s.modalSub}>
              Selecciona una rutina de tu plan para hacer hoy. Tu día original de esta rutina pasará a ser de descanso.
            </Text>
            <ScrollView style={s.modalLista} showsVerticalScrollIndicator={false}>
              {rutinasDisponibles.map((r, i) => (
                <TouchableOpacity
                  key={i}
                  style={s.rutinaOpcion}
                  onPress={() => handleSwapRutina(r.dia)}
                >
                  <View style={s.rutinaOpcionInfo}>
                    <Text style={s.rutinaOpcionDia}>{r.dia} - {r.tipo}</Text>
                    <Text style={s.rutinaOpcionDesc}>{r.rutina.length} ejercicios</Text>
                  </View>
                  <Ionicons name="swap-horizontal" size={20} color={COLORES.primario} />
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  contenido:         { paddingHorizontal: DISENO.paddingH, paddingBottom: 100 },
  header:            { paddingTop: 20, marginBottom: 20 },
  saludo:            { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 4 },
  subtitulo:         { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  selectorDias:      { flexDirection: 'row', gap: 8, paddingVertical: 4, marginBottom: 20 },
  chipWrapper:       {},
  cardDia:           { borderRadius: 24, padding: 24, marginBottom: 28, shadowColor: COLORES.primario, shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.3, shadowRadius: 20, elevation: 10 },
  cardLabel:         { fontFamily: FUENTES.negrita, fontSize: 10, color: 'rgba(255,255,255,0.7)', marginBottom: 8, letterSpacing: 1 },
  cardTitulo:        { fontFamily: FUENTES.negrita, fontSize: 22, color: COLORES.blanco, marginBottom: 6 },
  cardSub:           { fontFamily: FUENTES.regular, fontSize: 13, color: 'rgba(255,255,255,0.85)', lineHeight: 18 },
  seccionHeader:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  seccionTitulo:     { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  contadorEjercicios:{ fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  listaEjercicios:   { gap: 12, marginBottom: 24 },
  ejercicioItem:     { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORES.tarjeta, borderRadius: 20, padding: 12, gap: 16, borderWidth: 1, borderColor: COLORES.borde },
  ejercicioIcono:    { width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  ejercicioIconoCheckbox: { width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.05)' },
  ejercicioNombre:   { fontFamily: FUENTES.negrita, fontSize: 15, color: COLORES.blanco, marginBottom: 2 },
  ejercicioDetalle:  { fontFamily: FUENTES.regular, fontSize: 12, color: COLORES.subtitulo },
  grupoBadge:        { fontFamily: FUENTES.medio, fontSize: 10, color: COLORES.primario, marginTop: 3 },
  btnRegistrar:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: COLORES.primario, borderRadius: DISENO.radio.lg, height: DISENO.altoBoton, marginBottom: 24 },
  btnRegistrarTexto: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  cardVacio:         { backgroundColor: COLORES.tarjeta, borderRadius: 24, padding: 36, alignItems: 'center', borderWidth: 1, borderColor: COLORES.borde, borderStyle: 'dashed', marginBottom: 24 },
  vacioTitulo:       { fontFamily: FUENTES.negrita, fontSize: 18, color: COLORES.blanco, marginBottom: 8 },
  vacioDesc:         { fontFamily: FUENTES.regular, fontSize: 14, color: COLORES.subtitulo, textAlign: 'center', lineHeight: 20 },
  btnEvitarDescanso: { marginTop: 20, backgroundColor: 'rgba(0, 210, 255, 0.1)', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  btnEvitarDescansoTexto: { fontFamily: FUENTES.medio, fontSize: 13, color: COLORES.primario },
  cardCompletado:    { backgroundColor: 'rgba(46, 204, 113, 0.1)', borderRadius: 24, padding: 36, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(46, 204, 113, 0.3)', borderStyle: 'solid', marginBottom: 24 },
  completadoTitulo:  { fontFamily: FUENTES.negrita, fontSize: 18, color: COLORES.exito, marginBottom: 8 },
  completadoDesc:    { fontFamily: FUENTES.regular, fontSize: 14, color: COLORES.blanco, textAlign: 'center', lineHeight: 20 },
  cardVacioSimple:   { padding: 20, alignItems: 'center' },
  vacioTexto:        { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo },
  statsRow:          { flexDirection: 'row', gap: 12 },
  statCard:          { flex: 1, backgroundColor: COLORES.tarjeta, borderRadius: 20, padding: 16, alignItems: 'center', borderWidth: 1, borderColor: COLORES.borde },
  statIconoWrapper:  { width: 32, height: 32, borderRadius: 10, backgroundColor: 'rgba(108,99,255,0.1)', alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  statValor:         { fontFamily: FUENTES.negrita, fontSize: 18, color: COLORES.blanco, marginBottom: 2 },
  statEtiqueta:      { fontFamily: FUENTES.regular, fontSize: 10, color: COLORES.subtitulo, textTransform: 'uppercase' },
  modalOverlay:      { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalContenido:    { backgroundColor: COLORES.oscuro, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 24, paddingBottom: 40, maxHeight: '80%' },
  modalHeader:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  modalTitulo:       { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco },
  btnCerrarModal:    { padding: 4 },
  modalSub:          { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 20, lineHeight: 20 },
  modalLista:        { },
  rutinaOpcion:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: COLORES.tarjeta, padding: 16, borderRadius: 16, marginBottom: 10, borderWidth: 1, borderColor: COLORES.borde },
  rutinaOpcionInfo:  { flex: 1 },
  rutinaOpcionDia:   { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 4 },
  rutinaOpcionDesc:  { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  rutinasExpressWrapper: { },
  cardExpress:       { width: 140, height: 160, borderRadius: 20, overflow: 'hidden' },
  cardExpressBg:     { flex: 1, padding: 16, justifyContent: 'flex-end' },
  cardExpressTitulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.blanco, marginTop: 12, marginBottom: 4 },
  cardExpressSub:    { fontFamily: FUENTES.medio, fontSize: TAMANOS.xs, color: 'rgba(255,255,255,0.8)' },
  evolucionBanner:   { backgroundColor: COLORES.tarjeta, padding: 16, borderRadius: DISENO.radio.lg, marginTop: 16 },
  evolucionTitulo:   { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 4 },
  evolucionSub:      { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo, marginBottom: 12 },
  evolucionBtns:     { flexDirection: 'row', gap: 8 },
  btnEvol:           { flex: 1, backgroundColor: COLORES.primario, paddingVertical: 10, borderRadius: DISENO.radio.md, alignItems: 'center' },
  btnEvolTxt:        { fontFamily: FUENTES.negrita, fontSize: 13, color: COLORES.blanco },
});

import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView, Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';
import servicioEntrenamiento from '../../servicios/servicio-entrenamiento';



export default function DetalleEjercicio({ ejercicio, onVolver }) {
  const [alternativasVisible, setAlternativasVisible] = useState(false);

  const parsearDescanso = (descansoStr) => {
    if (!descansoStr) return 60;
    const str = String(descansoStr).toLowerCase();
    const numeros = str.match(/[\d\.]+/);
    if (!numeros) return 60;
    let valor = parseFloat(numeros[0]);
    if (str.includes("min")) return Math.round(valor * 60);
    return Math.round(valor);
  };

  const tiempoDescanso = parsearDescanso(ejercicio?.descanso);
  const [tiempoRestante, setTiempoRestante] = useState(tiempoDescanso);
  const [timerActivo, setTimerActivo] = useState(false);

  React.useEffect(() => {
    let interval;
    if (timerActivo && tiempoRestante > 0) {
      interval = setInterval(() => {
        setTiempoRestante((prev) => prev - 1);
      }, 1000);
    } else if (tiempoRestante === 0 && timerActivo) {
      Vibration.vibrate([0, 500, 200, 500]);
      setTimerActivo(false);
    }
    return () => clearInterval(interval);
  }, [timerActivo, tiempoRestante]);

  const toggleTimer = () => {
    if (tiempoRestante === 0) {
      setTiempoRestante(tiempoDescanso);
    }
    setTimerActivo(!timerActivo);
  };

  const formatearTiempo = (segs) => {
    const m = Math.floor(segs / 60);
    const s = segs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const [alternativas, setAlternativas] = useState([]);
  const [cargandoAlternativas, setCargandoAlternativas] = useState(false);

  React.useEffect(() => {
    if (alternativasVisible && alternativas.length === 0 && ejercicio?.grupo_muscular) {
      const cargar = async () => {
        setCargandoAlternativas(true);
        const res = await servicioEntrenamiento.obtenerAlternativas(ejercicio.grupo_muscular, ejercicio.nombre);
        if (res.exito && res.alternativas) {
          // Extraer los nombres de las alternativas, limitando a 4
          const nombres = res.alternativas.slice(0, 4).map(a => typeof a === 'string' ? a : (a.nombre || 'Variante de ' + ejercicio.grupo_muscular));
          setAlternativas(nombres);
        } else {
          setAlternativas(['No se encontraron alternativas']);
        }
        setCargandoAlternativas(false);
      };
      cargar();
    }
  }, [alternativasVisible]);

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={s.contenido}
    >
      <TouchableOpacity style={s.botonVolver} onPress={onVolver}>
        <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
        <Text style={s.volverTexto}>Volver a la rutina</Text>
      </TouchableOpacity>

      <LinearGradient
        colors={[COLORES.primario, '#2ecc71']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={s.cardHeader}
      >
        {ejercicio?.grupo_muscular && (
          <View style={s.grupoBadge}>
            <Text style={s.grupoTexto}>{ejercicio.grupo_muscular}</Text>
          </View>
        )}
        <Text style={s.nombreEjercicio}>{ejercicio?.nombre || 'Ejercicio'}</Text>
        {ejercicio?.tipo && (
          <Text style={s.tipoTexto}>{ejercicio.tipo}</Text>
        )}
      </LinearGradient>

      <View style={s.statsRow}>
        <View style={s.statCard}>
          <Text style={s.statValor}>{ejercicio?.series ?? '—'}</Text>
          <Text style={s.statEtiqueta}>Series</Text>
        </View>
        <View style={s.statCard}>
          <Text style={s.statValor}>{ejercicio?.reps ?? '—'}</Text>
          <Text style={s.statEtiqueta}>Reps</Text>
        </View>
        <View style={s.statCard}>
          <Text style={s.statValor}>{ejercicio?.descanso ?? '—'}</Text>
          <Text style={s.statEtiqueta}>Descanso</Text>
        </View>
      </View>

      <View style={s.timerCard}>
        <View style={s.timerInfo}>
          <Ionicons name="timer-outline" size={24} color={COLORES.primario} />
          <Text style={s.timerValor}>{formatearTiempo(tiempoRestante)}</Text>
        </View>
        <TouchableOpacity style={[s.btnTimer, timerActivo && s.btnTimerPausar]} onPress={toggleTimer} activeOpacity={0.8}>
          <Ionicons name={timerActivo ? "pause" : (tiempoRestante === 0 ? "refresh" : "play")} size={18} color={COLORES.blanco} />
          <Text style={s.btnTimerTexto}>{timerActivo ? "Pausar" : (tiempoRestante === 0 ? "Reiniciar" : "Iniciar Descanso")}</Text>
        </TouchableOpacity>
      </View>

      {ejercicio?.notas && (
        <View style={s.tarjetaInstrucciones}>
          <Text style={s.instruccionesTitulo}>Instrucciones</Text>
          <Text style={s.instruccionesTexto}>{ejercicio.notas}</Text>
        </View>
      )}

      <TouchableOpacity
        style={s.acordeonHeader}
        onPress={() => setAlternativasVisible(v => !v)}
        activeOpacity={0.7}
      >
        <Text style={s.acordeonTitulo}>Ejercicios alternativos</Text>
        <Ionicons
          name={alternativasVisible ? 'chevron-up' : 'chevron-down'}
          size={18}
          color={COLORES.subtitulo}
        />
      </TouchableOpacity>

      {alternativasVisible && (
        <View style={s.listaAlternativas}>
          {cargandoAlternativas ? (
            <Text style={s.sinAlternativas}>Cargando alternativas con IA...</Text>
          ) : alternativas.length > 0 ? (
            alternativas.map((alt, i) => (
              <View key={i} style={s.alternativaItem}>
                <View style={s.alternativaIcono}>
                  <Ionicons name="swap-horizontal" size={14} color={COLORES.primario} />
                </View>
                <Text style={s.alternativaTexto}>{alt}</Text>
              </View>
            ))
          ) : (
            <Text style={s.sinAlternativas}>
              No hay alternativas registradas para este grupo muscular.
            </Text>
          )}
        </View>
      )}

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  contenido:            { paddingHorizontal: DISENO.paddingH, paddingBottom: 100, paddingTop: 16 },
  botonVolver:          { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 20 },
  volverTexto:          { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  cardHeader:           { borderRadius: 24, padding: 28, marginBottom: 20 },
  grupoBadge:           { alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: DISENO.radio.chip, paddingHorizontal: 12, paddingVertical: 4, marginBottom: 12 },
  grupoTexto:           { fontFamily: FUENTES.medio, fontSize: TAMANOS.xs, color: COLORES.blanco },
  nombreEjercicio:      { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 4 },
  tipoTexto:            { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: 'rgba(255,255,255,0.8)' },
  statsRow:             { flexDirection: 'row', gap: 12, marginBottom: 20 },
  statCard:             { flex: 1, backgroundColor: COLORES.tarjeta, borderRadius: 20, padding: 16, alignItems: 'center', borderWidth: 1, borderColor: COLORES.borde },
  statValor:            { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 4 },
  statEtiqueta:         { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo, textTransform: 'uppercase' },
  tarjetaInstrucciones: { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.xl, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: COLORES.borde },
  instruccionesTitulo:  { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 10 },
  instruccionesTexto:   { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, lineHeight: 22 },
  acordeonHeader:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.xl, padding: 18, marginBottom: 8, borderWidth: 1, borderColor: COLORES.borde },
  acordeonTitulo:       { fontFamily: FUENTES.negrita, fontSize: TAMANOS.base, color: COLORES.blanco },
  listaAlternativas:    { gap: 8, marginBottom: 16 },
  alternativaItem:      { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, padding: 14, borderWidth: 1, borderColor: COLORES.borde },
  alternativaIcono:     { width: 28, height: 28, borderRadius: 8, backgroundColor: 'rgba(108,99,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  alternativaTexto:     { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.blanco },
  sinAlternativas:      { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, textAlign: 'center', padding: 16 },
  timerCard:            { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.xl, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: COLORES.primario, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  timerInfo:            { flexDirection: 'row', alignItems: 'center', gap: 10 },
  timerValor:           { fontFamily: FUENTES.negrita, fontSize: 24, color: COLORES.blanco },
  btnTimer:             { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORES.primario, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  btnTimerPausar:       { backgroundColor: COLORES.alerta },
  btnTimerTexto:        { fontFamily: FUENTES.negrita, fontSize: TAMANOS.sm, color: COLORES.blanco },
});

/**
 * @file HistorialPlanes.jsx
 * @description HU3 — Lista de planes generados anteriormente por el usuario,
 *              ordenados cronológicamente (más reciente primero).
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  FlatList, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';
import servicioPlanes from '../servicios/servicio-planes';

const ESTADO_ESTILOS = {
  activo:      { color: COLORES.exito,    fondo: COLORES.exitoFondo, label: 'Activo' },
  completado:  { color: COLORES.subtitulo, fondo: COLORES.tarjeta,   label: 'Completado' },
  cancelado:   { color: COLORES.alerta,   fondo: '#2A1E0D',          label: 'Cancelado' },
};

function formatearFecha(isoString) {
  const d = new Date(isoString);
  if (isNaN(d)) return isoString;
  return d.toLocaleDateString('es-CL', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function PlanCard({ plan, onPress }) {
  const estado = ESTADO_ESTILOS[plan.estado] || ESTADO_ESTILOS.completado;
  return (
    <TouchableOpacity style={s.card} onPress={() => onPress(plan)} activeOpacity={0.75}>
      <View style={s.cardTop}>
        <View style={[s.badge, { backgroundColor: estado.fondo }]}>
          <Text style={[s.badgeTexto, { color: estado.color }]}>{estado.label}</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={COLORES.subtitulo} />
      </View>
      <Text style={s.objetivo}>{plan.objetivo_seleccionado}</Text>
      <View style={s.cardMeta}>
        <View style={s.metaItem}>
          <Ionicons name="calendar-outline" size={13} color={COLORES.subtitulo} />
          <Text style={s.metaTexto}>{formatearFecha(plan.fecha_creacion)}</Text>
        </View>
        <View style={s.metaItem}>
          <Ionicons name="time-outline" size={13} color={COLORES.subtitulo} />
          <Text style={s.metaTexto}>
            {plan.duracion_meses} {plan.duracion_meses === 1 ? 'mes' : 'meses'}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default function HistorialPlanes({ usuario, onVerDetalle, onVolver }) {
  const [planes, setPlanes]   = useState([]);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    const cargar = async () => {
      setCargando(true);
      const datos = await servicioPlanes.obtener(usuario?.id || '11111111-1111-1111-1111-111111111111');
      setPlanes(datos);
      setCargando(false);
    };
    cargar();
  }, [usuario?.id]);

  return (
    <View style={s.contenedor}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={onVolver} style={s.botonVolver} activeOpacity={0.7}>
          <Ionicons name="arrow-back" size={22} color={COLORES.blanco} />
        </TouchableOpacity>
        <Text style={s.headerTitulo}>Mis Planes</Text>
        <View style={{ width: 40 }} />
      </View>

      {cargando ? (
        <View style={s.centrado}>
          <ActivityIndicator color={COLORES.primario} size="large" />
        </View>
      ) : planes.length === 0 ? (
        <View style={s.centrado}>
          <Ionicons name="document-outline" size={48} color={COLORES.borde} />
          <Text style={s.vacioTitulo}>Sin planes aún</Text>
          <Text style={s.vacioDesc}>Completa el onboarding para generar tu primer plan.</Text>
        </View>
      ) : (
        <FlatList
          data={planes}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => <PlanCard plan={item} onPress={onVerDetalle} />}
          contentContainerStyle={s.lista}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  contenedor:   { flex: 1, backgroundColor: COLORES.oscuro },
  header:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: DISENO.paddingH, paddingTop: 56, paddingBottom: 16, backgroundColor: COLORES.superficie, borderBottomWidth: 1, borderBottomColor: COLORES.borde },
  botonVolver:  { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitulo: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  centrado:     { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: DISENO.paddingH },
  vacioTitulo:  { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  vacioDesc:    { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, textAlign: 'center', lineHeight: 22 },
  lista:        { paddingHorizontal: DISENO.paddingH, paddingTop: 20, paddingBottom: 32, gap: 12 },
  card:         { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 16, borderWidth: 1, borderColor: COLORES.borde },
  cardTop:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  badge:        { paddingHorizontal: 10, paddingVertical: 4, borderRadius: DISENO.radio.chip },
  badgeTexto:   { fontFamily: FUENTES.medio, fontSize: TAMANOS.xs },
  objetivo:     { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 10 },
  cardMeta:     { flexDirection: 'row', gap: 16 },
  metaItem:     { flexDirection: 'row', alignItems: 'center', gap: 5 },
  metaTexto:    { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
});

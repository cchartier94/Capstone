/**
 * @file RecuperarContrasena.jsx
 * @description Pantalla de recuperación de contraseña. El usuario ingresa su correo
 *              y recibe un enlace. Muestra un estado de éxito al confirmar el envío.
 *              El envío real del correo (Supabase/Resend) está pendiente.
 */

import React, { useState } from 'react'; // hook de estado
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, ScrollView, Platform,
} from 'react-native'; // componentes de UI y utilidades de teclado/plataforma
import { Ionicons } from '@expo/vector-icons'; // icono checkmark en la vista de confirmación
import { COLORES } from '../constantes/colores'; // paleta de colores del sistema de diseño
import { FUENTES, TAMANOS } from '../constantes/tipografia'; // familias tipográficas y tamaños de fuente
import { DISENO } from '../constantes/diseno'; // constantes de layout (paddings, radios, alturas)

/**
 * Pantalla de recuperación de contraseña vía correo electrónico.
 *
 * @param {object}   props
 * @param {Function} props.onVolver - Regresa a la pantalla de Login.
 * @returns {JSX.Element}
 */
export default function RecuperarContrasena({ onVolver }) {
  const [correo, setCorreo] = useState('');
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);
  const [enviado, setEnviado] = useState(false);

  /**
   * Valida que el correo tenga formato válido.
   *
   * @returns {string|null} Mensaje de error, o null si es válido.
   */
  const validar = () => {
    if (!correo.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo))
      return 'Ingresa un correo válido';
    return null;
  };

  /**
   * Simula el envío del correo de recuperación y activa el estado de éxito.
   * TODO: conectar con endpoint real de recuperación de contraseña.
   */
  const handleEnviar = async () => {
    const err = validar();
    if (err) { setError(err); return; }
    setError('');
    setCargando(true);
    try {
      await new Promise(r => setTimeout(r, 800));
      setEnviado(true);
    } catch (e) {
      setError('No pudimos enviar el correo. Verifica la dirección.');
    } finally {
      setCargando(false);
    }
  };

  /** Vista de confirmación que se muestra tras enviar el enlace correctamente. */
  if (enviado) {
    return (
      <View style={s.contenedor}>
        <View style={s.exitoContenedor}>
          <View style={s.exitoIcono}>
            <Ionicons name="checkmark" size={36} color={COLORES.exito} />
          </View>
          <Text style={s.exitoTitulo}>Correo enviado</Text>
          <Text style={s.exitoSubtitulo}>
            Revisa tu bandeja de entrada y sigue el enlace para crear tu nueva contraseña.
          </Text>
          <TouchableOpacity style={s.boton} onPress={onVolver} activeOpacity={0.8}>
            <Text style={s.botonTexto}>Volver al inicio</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={s.contenedor}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={s.circuloFondo} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>

        <TouchableOpacity style={s.btnVolver} onPress={onVolver}>
          <Text style={s.btnVolverTexto}>← Volver</Text>
        </TouchableOpacity>

        <Text style={s.titulo}>Recuperar contraseña</Text>
        <Text style={s.subtitulo}>Te enviaremos un enlace a tu correo</Text>

        <Text style={s.etiqueta}>Correo electrónico</Text>
        <TextInput
          style={s.campo}
          placeholder="tu@correo.com"
          placeholderTextColor={COLORES.subtitulo}
          value={correo}
          onChangeText={t => { setCorreo(t); setError(''); }}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />

        {!!error && <Text style={s.mensajeError}>{error}</Text>}

        <TouchableOpacity
          style={[s.boton, (!correo.trim() || cargando) && s.botonDesactivado]}
          onPress={handleEnviar}
          disabled={!correo.trim() || cargando}
          activeOpacity={0.8}
        >
          <Text style={s.botonTexto}>{cargando ? 'Enviando...' : 'Enviar enlace'}</Text>
        </TouchableOpacity>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  contenedor: { flex: 1, backgroundColor: COLORES.oscuro },
  circuloFondo: {
    position: 'absolute',
    width: 500, height: 500, borderRadius: 250,
    backgroundColor: COLORES.primario, opacity: 0.08,
    top: 0, left: -55,
  },
  scroll: {
    paddingHorizontal: DISENO.paddingH,
    paddingTop: 60, paddingBottom: 40,
  },
  exitoContenedor: {
    flex: 1,
    paddingHorizontal: DISENO.paddingH,
    justifyContent: 'center', alignItems: 'center',
  },
  exitoIcono: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: COLORES.exitoFondo,
    borderWidth: 2, borderColor: COLORES.exito,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 28,
  },
  exitoTitulo: {
    fontFamily: FUENTES.negrita,
    fontSize: TAMANOS.xxl,
    color: COLORES.blanco,
    textAlign: 'center', marginBottom: 16,
  },
  exitoSubtitulo: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo,
    textAlign: 'center', lineHeight: 22,
    paddingHorizontal: 16, marginBottom: 40,
  },
  btnVolver: { marginBottom: 32 },
  btnVolverTexto: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.base,
    color: COLORES.primario,
  },
  titulo: {
    fontFamily: FUENTES.negrita,
    fontSize: TAMANOS.h1,
    color: COLORES.blanco, marginBottom: 8,
  },
  subtitulo: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo, marginBottom: 32,
  },
  etiqueta: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.sm,
    color: COLORES.subtitulo, marginBottom: 8,
  },
  campo: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    height: DISENO.altoBoton,
    paddingHorizontal: 16,
    color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    marginBottom: 20,
  },
  mensajeError: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.sm,
    color: COLORES.error, marginBottom: 12,
  },
  boton: {
    backgroundColor: COLORES.primario,
    borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton,
    alignItems: 'center', justifyContent: 'center',
    width: '100%',
  },
  botonDesactivado: { opacity: 0.4 },
  botonTexto: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.lg, color: COLORES.blanco,
  },
});

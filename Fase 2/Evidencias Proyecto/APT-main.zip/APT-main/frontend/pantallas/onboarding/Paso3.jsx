/**
 * @file Paso3.jsx
 * @description Paso 3 del onboarding: Datos físicos (Peso, Estatura).
 */

import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';

export default function Paso3({ peso, setPeso, estatura, setEstatura }) {
  return (
    <View>
      <Text style={st.titulo}>Datos físicos</Text>
      <Text style={st.descripcion}>Cuéntanos tus medidas</Text>
      
      <Text style={st.etiqueta}>Peso (kg)</Text>
      <TextInput
        placeholder="Ej: 75.5"
        placeholderTextColor={COLORES.subtitulo}
        value={peso}
        onChangeText={setPeso}
        keyboardType="decimal-pad"
        style={st.campo}
      />
      
      <Text style={st.etiqueta}>Estatura (cm)</Text>
      <TextInput
        placeholder="Ej: 176"
        placeholderTextColor={COLORES.subtitulo}
        value={estatura}
        onChangeText={setEstatura}
        keyboardType="decimal-pad"
        style={st.campo}
        maxLength={3}
      />
    </View>
  );
}

const st = StyleSheet.create({
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 8 },
  descripcion: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginBottom: 32 },
  etiqueta: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 8 },
  campo: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    height: DISENO.altoBoton,
    paddingHorizontal: 16,
    color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    marginBottom: 20,
  },
});

/**
 * @file Paso1.jsx
 * @description Paso 1 del onboarding: Perfil inicial (Nombre, Edad, Sexo).
 */

import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';

const SEXOS = [
  { id: 'Masculino', etiqueta: 'Masculino' },
  { id: 'Femenino',  etiqueta: 'Femenino' },
  { id: 'Otro',      etiqueta: 'Otro' },
];

export default function Paso1({ nombre, setNombre, edad, setEdad, sexo, setSexo, renderChip }) {
  return (
    <View>
      <Text style={st.titulo}>Tu perfil inicial</Text>
      <Text style={st.descripcion}>Cuéntanos sobre ti</Text>
      
      <Text style={st.etiqueta}>Nombre</Text>
      <TextInput
        placeholder="Tu nombre completo"
        placeholderTextColor={COLORES.subtitulo}
        value={nombre}
        onChangeText={setNombre}
        style={st.campo}
        autoCapitalize="words"
      />
      
      <Text style={st.etiqueta}>Edad</Text>
      <TextInput
        placeholder="Ej: 24"
        placeholderTextColor={COLORES.subtitulo}
        value={edad}
        onChangeText={setEdad}
        keyboardType="number-pad"
        style={st.campo}
        maxLength={3}
      />
      
      <Text style={st.etiqueta}>Sexo biológico</Text>
      <View style={st.chipGroup}>
        {SEXOS.map(s_ => renderChip(s_, sexo, setSexo))}
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 8 },
  descripcion: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginBottom: 32 },
  etiqueta: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 8 },
  campo: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    height: DISENO.altoBoton,
    paddingHorizontal: 16,
    color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    marginBottom: 20,
  },
  chipGroup: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
});

/**
 * @file Paso2.jsx
 * @description Paso 2 del onboarding: Objetivo principal.
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';

const OBJETIVOS = [
  { id: 'bajar_grasa',            etiqueta: 'Bajar grasa' },
  { id: 'ganar_masa_muscular',    etiqueta: 'Ganar masa muscular' },
  { id: 'mantencion',             etiqueta: 'Mantención' },
  { id: 'recomposicion_corporal', etiqueta: 'Recomposición corporal' },
  { id: 'mejorar_rendimiento',    etiqueta: 'Mejorar rendimiento' },
];

export default function Paso2({ objetivo, setObjetivo, renderChip }) {
  return (
    <View>
      <Text style={st.titulo}>Objetivo principal</Text>
      <Text style={st.descripcion}>¿Qué quieres lograr?</Text>
      <View style={st.chipGroup}>
        {OBJETIVOS.map(opt => renderChip(opt, objetivo, setObjetivo))}
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 8 },
  descripcion: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginBottom: 32 },
  chipGroup: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
});

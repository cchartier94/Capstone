/**
 * @file Paso4.jsx
 * @description Paso 4 del onboarding: Actividad física.
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';

const NIVELES_ACTIVIDAD = [
  { id: 'Sedentario',  etiqueta: 'Sedentario' },
  { id: 'Ligero',      etiqueta: 'Ligero' },
  { id: 'Moderado',    etiqueta: 'Moderado' },
  { id: 'Activo',      etiqueta: 'Activo' },
  { id: 'Muy activo',  etiqueta: 'Muy activo' },
];

const NIVELES_EXPERIENCIA = [
  { id: 'Principiante', etiqueta: 'Principiante' },
  { id: 'Intermedio',   etiqueta: 'Intermedio' },
  { id: 'Avanzado',     etiqueta: 'Avanzado' },
];

export default function Paso4({ 
  nivelActividad, setNivelActividad, 
  nivelExperiencia, setNivelExperiencia, 
  dias, setDias, 
  minutos, setMinutos, 
  renderChip, renderNumChip 
}) {
  return (
    <View>
      <Text style={st.titulo}>Actividad física</Text>
      <Text style={st.descripcion}>Tu nivel y disponibilidad</Text>
      
      <Text style={st.etiqueta}>Nivel de actividad</Text>
      <View style={st.chipGroup}>
        {NIVELES_ACTIVIDAD.map(opt => renderChip(opt, nivelActividad, setNivelActividad))}
      </View>
      
      <Text style={st.etiqueta}>Experiencia</Text>
      <View style={st.chipGroup}>
        {NIVELES_EXPERIENCIA.map(opt => renderChip(opt, nivelExperiencia, setNivelExperiencia))}
      </View>
      
      <Text style={st.etiqueta}>Días por semana</Text>
      <View style={st.chipGroupDias}>
        {[1, 2, 3, 4, 5, 6, 7].map(d => renderNumChip(d, dias, setDias))}
      </View>
      
      <Text style={st.etiqueta}>Duración sesión (min)</Text>
      <View style={st.chipGroup}>
        {[30, 45, 60, 90].map(m => renderNumChip(m, minutos, setMinutos))}
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 8 },
  descripcion: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginBottom: 32 },
  etiqueta: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 8 },
  chipGroup: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  chipGroupDias: { flexDirection: 'row', gap: 8, marginBottom: 20 },
});

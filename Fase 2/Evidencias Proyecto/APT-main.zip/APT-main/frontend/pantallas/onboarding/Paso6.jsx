/**
 * @file Paso6.jsx
 * @description Paso 6 del onboarding: Preferencias alimentarias.
 */

import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';

const TIPOS_DIETA = [
  { id: 'Sin restricciones', etiqueta: 'Sin restricciones' },
  { id: 'Vegetariano',       etiqueta: 'Vegetariano' },
  { id: 'Vegano',            etiqueta: 'Vegano' },
  { id: 'Keto',              etiqueta: 'Keto' },
  { id: 'Paleo',             etiqueta: 'Paleo' },
  { id: 'Sin gluten',        etiqueta: 'Sin gluten' },
];

export default function Paso6({ tipoDieta, setTipoDieta, alimentos, setAlimentos, renderChip }) {
  return (
    <View>
      <Text style={st.titulo}>Preferencias alimentarias</Text>
      <Text style={st.descripcion}>¿Alguna restricción dietética?</Text>
      
      <Text style={st.etiqueta}>Tipo de dieta</Text>
      <View style={st.chipGroup}>
        {TIPOS_DIETA.map(opt => renderChip(opt, tipoDieta, setTipoDieta))}
      </View>
      
      <Text style={st.etiqueta}>Alimentos a excluir (opcional)</Text>
      <TextInput
        placeholder="Ej: Mariscos, nueces"
        placeholderTextColor={COLORES.subtitulo}
        value={alimentos}
        onChangeText={setAlimentos}
        multiline
        numberOfLines={3}
        textAlignVertical="top"
        style={st.textarea}
      />
    </View>
  );
}

const st = StyleSheet.create({
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 8 },
  descripcion: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginBottom: 32 },
  etiqueta: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 8 },
  textarea: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    padding: 16, color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    minHeight: 100, marginBottom: 16,
  },
  chipGroup: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
});

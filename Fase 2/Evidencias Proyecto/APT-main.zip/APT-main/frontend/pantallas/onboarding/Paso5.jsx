/**
 * @file Paso5.jsx
 * @description Paso 5 del onboarding: Salud y restricciones.
 */

import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { COLORES } from '../../constantes/colores';
import { FUENTES, TAMANOS } from '../../constantes/tipografia';
import { DISENO } from '../../constantes/diseno';

export default function Paso5({ condiciones, setCondiciones }) {
  return (
    <View>
      <Text style={st.titulo}>Salud y restricciones</Text>
      <Text style={st.descripcion}>Para tu seguridad (opcional)</Text>
      
      <Text style={st.etiqueta}>¿Tienes enfermedades, lesiones u otras condiciones?</Text>
      <TextInput
        placeholder="Ej: tendinitis en rodilla, diabetes tipo 2..."
        placeholderTextColor={COLORES.subtitulo}
        value={condiciones}
        onChangeText={setCondiciones}
        multiline
        numberOfLines={4}
        textAlignVertical="top"
        style={st.textarea}
      />
      <Text style={st.aviso}>
        Si no tienes ninguna condición, puedes continuar sin completar este campo.
      </Text>
    </View>
  );
}

const st = StyleSheet.create({
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginBottom: 8 },
  descripcion: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginBottom: 32 },
  etiqueta: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 8 },
  textarea: {
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    borderWidth: 1, borderColor: COLORES.borde,
    padding: 16, color: COLORES.blanco,
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    minHeight: 100, marginBottom: 16,
  },
  aviso: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.sm, color: COLORES.subtitulo,
    lineHeight: 18, marginBottom: 20,
  },
});

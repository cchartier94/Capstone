/**
 * @file TabPlanes.jsx
 * @description Tab de historial de planes conectado al backend (SCRUM-37).
 *              Lista de planes + vista detalle del plan seleccionado.
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';
import servicioPlanes from '../servicios/servicio-planes';

const ESTADO_CONFIG = {
  activo: { color: COLORES.exito, label: 'Activo', icono: 'checkmark-circle' },
  completado: { color: COLORES.primario, label: 'Completado', icono: 'trophy' },
  cancelado: { color: COLORES.subtitulo, label: 'Cancelado', icono: 'close-circle' },
};

export default function TabPlanes({ usuarioId, planGlobal, onActualizarPlanGlobal, onVolver }) {
  const [planes, setPlanes] = useState([]);
  const [planDetalle, setPlanDetalle] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [cargandoDetalle, setCargandoDetalle] = useState(false);
  const [refrescando, setRefrescando] = useState(false);
  const [modoEdicion, setModoEdicion] = useState(false);
  const [semanaEditada, setSemanaEditada] = useState(null);

  const cargarPlanes = useCallback(async () => {
    try {
      const data = await servicioPlanes.obtenerHistorial(usuarioId);
      if (data.exito) setPlanes(data.planes || []);
    } catch (e) {
      console.warn('Error cargando planes:', e);
    } finally {
      setCargando(false);
      setRefrescando(false);
    }
  }, [usuarioId]);

  useEffect(() => { cargarPlanes(); }, [cargarPlanes]);

  const verDetalle = async (planId) => {
    setCargandoDetalle(true);
    const data = await servicioPlanes.obtenerDetalle(planId, usuarioId);
    setCargandoDetalle(false);
    if (data.exito && data.plan) {
      setPlanDetalle(data.plan);
      setSemanaEditada(data.plan.respuesta_raw_ia?.semana ? JSON.parse(JSON.stringify(data.plan.respuesta_raw_ia.semana)) : null);
      setModoEdicion(false);
    }
  };

  const moverRutina = (idx, direccion) => {
    if (!semanaEditada) return;
    const nuevaIdx = idx + direccion;
    
    if (nuevaIdx < 0 || nuevaIdx >= semanaEditada.length) return;
    
    // Clonar profundamente cada día para evitar mutaciones directas sobre el plan original por referencia
    const nuevaSemana = semanaEditada.map(item => ({
      ...item,
      rutina: Array.isArray(item.rutina) ? [...item.rutina] : item.rutina
    }));
    
    // Intercambiar rutina y tipo, manteniendo el nombre del día fijo
    const rutinaTemp = nuevaSemana[idx].rutina;
    const tipoTemp = nuevaSemana[idx].tipo;
    
    nuevaSemana[idx].rutina = nuevaSemana[nuevaIdx].rutina;
    nuevaSemana[idx].tipo = nuevaSemana[nuevaIdx].tipo;
    
    nuevaSemana[nuevaIdx].rutina = rutinaTemp;
    nuevaSemana[nuevaIdx].tipo = tipoTemp;
    
    setSemanaEditada(nuevaSemana);
  };

  const guardarCambios = async () => {
    if (!planDetalle || !semanaEditada) return;
    setCargandoDetalle(true);
    
    const nuevaRespuestaIA = { ...planDetalle.respuesta_raw_ia, semana: semanaEditada };
    const res = await servicioPlanes.actualizarPlan(planDetalle.id, usuarioId, { respuesta_raw_ia: nuevaRespuestaIA });
    
    if (res.exito) {
      const planActualizado = { ...planDetalle, respuesta_raw_ia: nuevaRespuestaIA };
      setPlanDetalle(planActualizado);
      setModoEdicion(false);
      
      if (planGlobal && planGlobal.id === planDetalle.id && onActualizarPlanGlobal) {
         onActualizarPlanGlobal({ ...planGlobal, ...nuevaRespuestaIA });
      }
    }
    setCargandoDetalle(false);
  };

  // --- Vista Detalle ---
  if (planDetalle) {
    const cfg = ESTADO_CONFIG[planDetalle.estado] || ESTADO_CONFIG.activo;
    const planIA = planDetalle.respuesta_raw_ia;
    const datosSemana = semanaEditada;

    return (
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.contenido}>
        <TouchableOpacity style={s.botonVolver} onPress={() => { setPlanDetalle(null); setModoEdicion(false); setSemanaEditada(null); }}>
          <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
          <Text style={s.volverTexto}>Volver al historial</Text>
        </TouchableOpacity>

        <View style={s.detalleHeader}>
          <View style={[s.estadoBadge, { backgroundColor: cfg.color + '20' }]}>
            <Ionicons name={cfg.icono} size={14} color={cfg.color} />
            <Text style={[s.estadoTexto, { color: cfg.color }]}>{cfg.label}</Text>
          </View>
          <Text style={s.detalleTitulo}>{planDetalle.objetivo_seleccionado}</Text>
          <Text style={s.detalleSub}>
            {planDetalle.duracion_meses} {planDetalle.duracion_meses === 1 ? 'mes' : 'meses'} • Creado: {planDetalle.fecha_creacion?.split('T')[0]}
          </Text>
        </View>

        {planIA ? (
          <View style={s.planIACard}>
            {planIA.nombre_plan && <Text style={s.planIANombre}>{planIA.nombre_plan}</Text>}
            {planIA.resumen && <Text style={s.planIAResumen}>{planIA.resumen}</Text>}

            {datosSemana && Array.isArray(datosSemana) && (
              <>
                <View style={s.headerRutinaSemanal}>
                  <Text style={s.subtitulo}>Rutina semanal</Text>
                  {!modoEdicion ? (
                    <TouchableOpacity style={s.btnEditar} onPress={() => {
                      setModoEdicion(true);
                      if (planIA?.semana) {
                        setSemanaEditada(JSON.parse(JSON.stringify(planIA.semana)));
                      }
                    }}>
                      <Ionicons name="pencil" size={16} color={COLORES.primario} />
                      <Text style={s.btnEditarTexto}>Editar días</Text>
                    </TouchableOpacity>
                  ) : (
                    <View style={s.accionesEdicion}>
                      <TouchableOpacity style={s.btnCancelar} onPress={() => {
                        setModoEdicion(false);
                        if (planIA?.semana) {
                          setSemanaEditada(JSON.parse(JSON.stringify(planIA.semana)));
                        }
                      }}>
                        <Text style={s.btnCancelarTexto}>Cancelar</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={s.btnGuardar} onPress={guardarCambios}>
                        <Text style={s.btnGuardarTexto}>Guardar</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
                
                {datosSemana.map((dia, i) => (
                  <View key={i} style={[s.diaCard, modoEdicion && s.diaCardEdicion]}>
                    <View style={s.diaHeader}>
                      <Text style={s.diaNombre}>{dia.dia || `Día ${i + 1}`}</Text>
                      {modoEdicion && (
                        <View style={s.controlesEdicion}>
                          <TouchableOpacity onPress={() => moverRutina(i, -1)} disabled={i === 0} style={[s.btnMover, i === 0 && s.btnMoverDisabled]}>
                            <Ionicons name="caret-up" size={18} color={i === 0 ? COLORES.subtitulo : COLORES.primario} />
                          </TouchableOpacity>
                          <TouchableOpacity onPress={() => moverRutina(i, 1)} disabled={i === datosSemana.length - 1} style={[s.btnMover, i === datosSemana.length - 1 && s.btnMoverDisabled]}>
                            <Ionicons name="caret-down" size={18} color={i === datosSemana.length - 1 ? COLORES.subtitulo : COLORES.primario} />
                          </TouchableOpacity>
                        </View>
                      )}
                    </View>

                    {Array.isArray(dia.rutina) ? (
                      dia.rutina.map((ej, j) => (
                        <Text key={j} style={s.ejercicioTexto}>
                          • {ej.nombre} — {ej.series}x{ej.reps}
                        </Text>
                      ))
                    ) : (
                      <Text style={s.descansoTexto}>{dia.rutina || 'Descanso'}</Text>
                    )}
                  </View>
                ))}
              </>
            )}
          </View>
        ) : (
          <View style={s.cardVacio}>
            <Text style={s.vacioTitulo}>Sin detalle IA</Text>
            <Text style={s.vacioDesc}>Este plan no tiene datos generados por la IA.</Text>
          </View>
        )}
        <View style={{ height: 24 }} />
      </ScrollView>
    );
  }

  // --- Vista Lista ---
  if (cargando) {
    return (
      <View style={s.centrado}>
        <ActivityIndicator size="large" color={COLORES.primario} />
        <Text style={s.cargandoTexto}>Cargando planes...</Text>
      </View>
    );
  }

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={s.contenido}
      refreshControl={
        <RefreshControl refreshing={refrescando} onRefresh={() => { setRefrescando(true); cargarPlanes(); }} tintColor={COLORES.primario} />
      }
    >
      {onVolver && (
        <TouchableOpacity style={s.botonVolver} onPress={onVolver}>
          <Ionicons name="arrow-back" size={20} color={COLORES.blanco} />
          <Text style={s.volverTexto}>Volver al Perfil</Text>
        </TouchableOpacity>
      )}
      <Text style={s.titulo}>Historial de Planes</Text>

      {planes.length === 0 ? (
        <View style={s.cardVacio}>
          <Ionicons name="document-text-outline" size={40} color={COLORES.subtitulo} />
          <Text style={s.vacioTitulo}>Sin planes</Text>
          <Text style={s.vacioDesc}>Aún no se han generado planes. Completa el onboarding para obtener tu primer plan.</Text>
        </View>
      ) : (
        planes.map((plan) => {
          const cfg = ESTADO_CONFIG[plan.estado] || ESTADO_CONFIG.activo;
          return (
            <TouchableOpacity
              key={plan.id}
              style={s.planCard}
              onPress={() => verDetalle(plan.id)}
              activeOpacity={0.7}
            >
              <View style={s.planCardHeader}>
                <View style={[s.estadoBadge, { backgroundColor: cfg.color + '20' }]}>
                  <Ionicons name={cfg.icono} size={12} color={cfg.color} />
                  <Text style={[s.estadoTexto, { color: cfg.color }]}>{cfg.label}</Text>
                </View>
                <Text style={s.planFecha}>{plan.fecha_creacion?.split('T')[0]}</Text>
              </View>
              <Text style={s.planObjetivo}>{plan.objetivo_seleccionado}</Text>
              <Text style={s.planDuracion}>
                {plan.duracion_meses} {plan.duracion_meses === 1 ? 'mes' : 'meses'}
              </Text>
              <View style={s.planVerDetalle}>
                <Text style={s.verDetalleTexto}>Ver detalle</Text>
                <Ionicons name="chevron-forward" size={16} color={COLORES.primario} />
              </View>
            </TouchableOpacity>
          );
        })
      )}

      {cargandoDetalle && (
        <View style={s.overlay}>
          <ActivityIndicator size="large" color={COLORES.primario} />
        </View>
      )}

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  contenido: { paddingHorizontal: DISENO.paddingH, paddingBottom: 100 },
  centrado: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  cargandoTexto: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, marginTop: 12 },
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xl, color: COLORES.blanco, marginBottom: 16, marginTop: 20 },
  subtitulo: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginBottom: 12, marginTop: 16 },
  planCard: {
    backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.xl,
    padding: 18, marginBottom: 12, borderWidth: 1, borderColor: COLORES.borde,
  },
  planCardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  planFecha: { fontFamily: FUENTES.regular, fontSize: TAMANOS.xs, color: COLORES.subtitulo },
  planObjetivo: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 4 },
  planDuracion: { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo, marginBottom: 12 },
  planVerDetalle: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  verDetalleTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.primario },
  estadoBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20,
  },
  estadoTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.xs },
  cardVacio: {
    backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.lg, padding: 32,
    alignItems: 'center', borderStyle: 'dashed', borderWidth: 1, borderColor: COLORES.borde,
  },
  vacioTitulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.lg, color: COLORES.blanco, marginTop: 12, marginBottom: 8 },
  vacioDesc: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, textAlign: 'center', lineHeight: 22 },
  // Detalle
  botonVolver: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 16 },
  volverTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.blanco },
  detalleHeader: { marginBottom: 20 },
  detalleTitulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.xxl, color: COLORES.blanco, marginTop: 10, marginBottom: 4 },
  detalleSub: { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  planIACard: { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.xl, padding: 20, borderWidth: 1, borderColor: COLORES.borde },
  planIANombre: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.primario, marginBottom: 8 },
  planIAResumen: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, lineHeight: 22, marginBottom: 12 },
  diaCard: { backgroundColor: COLORES.superficie, borderRadius: DISENO.radio.md, padding: 14, marginBottom: 8 },
  diaNombre: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.base, color: COLORES.blanco, marginBottom: 6 },
  ejercicioTexto: { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.subtitulo, lineHeight: 20 },
  descansoTexto: { fontFamily: FUENTES.regular, fontSize: TAMANOS.sm, color: COLORES.alerta, fontStyle: 'italic' },
  overlay: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center',
  },
  headerRutinaSemanal: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, marginTop: 16 },
  btnEditar: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(108,99,255,0.1)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  btnEditarTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.primario },
  accionesEdicion: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  btnCancelar: { paddingHorizontal: 12, paddingVertical: 6 },
  btnCancelarTexto: { fontFamily: FUENTES.medio, fontSize: TAMANOS.sm, color: COLORES.subtitulo },
  btnGuardar: { backgroundColor: COLORES.primario, paddingHorizontal: 16, paddingVertical: 6, borderRadius: 12 },
  btnGuardarTexto: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.sm, color: COLORES.blanco },
  diaCardEdicion: { borderColor: COLORES.primario, borderWidth: 1, backgroundColor: 'rgba(108,99,255,0.05)' },
  diaHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  controlesEdicion: { flexDirection: 'row', gap: 8 },
  btnMover: { width: 28, height: 28, borderRadius: 6, backgroundColor: 'rgba(108,99,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  btnMoverDisabled: { backgroundColor: 'transparent' },
});

import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORES } from '../constantes/colores';
import { FUENTES } from '../constantes/tipografia';
import TabProgreso from './TabProgreso';
import TabMetricas from './TabMetricas';
import TabPlanes from './TabPlanes';
import TabRutina from './entrenamiento/TabRutina';
import RegistrarSesion from './entrenamiento/RegistrarSesion';
import ChatCoach from './ia/ChatCoach';
import TabPerfil from './perfil/TabPerfil';
import GestionCuenta from './perfil/GestionCuenta';
import ConfigNotificaciones from './perfil/ConfigNotificaciones';
import ConfigGeneral from './perfil/ConfigGeneral';

const TABS = [
  { id: 'hoy',      label: 'Hoy',      icono: 'home-outline' },
  { id: 'progreso', label: 'Progreso', icono: 'trending-up-outline' },
  { id: 'metricas', label: 'Metricas', icono: 'body-outline' },
  { id: 'planes',   label: 'Planes',   icono: 'document-text-outline' },
  { id: 'coach',    label: 'Coach',    icono: 'chatbubble-ellipses-outline' },
  { id: 'perfil',   label: 'Perfil',   icono: 'person-outline' },
];

export default function Dashboard({ usuario, plan, onActualizarPlan, onCerrarSesion }) {
  const [tabActiva, setTabActiva] = useState('hoy');
  const [vistaActiva, setVistaActiva] = useState(null);
  const [vistaAnterior, setVistaAnterior] = useState(null);
  const [diaParaRegistrar, setDiaParaRegistrar] = useState(null);
  const [vengoDesdePerfil, setVengoDesdePerfil] = useState(false);

  const manejarNavegar = (destino) => {
    const tabs = ['hoy', 'progreso', 'metricas', 'planes', 'coach', 'perfil'];
    if (tabs.includes(destino)) {
      if (tabActiva === 'perfil' && destino !== 'perfil') {
        setVengoDesdePerfil(true);
      } else {
        setVengoDesdePerfil(false);
      }
      setVistaAnterior(null);
      setVistaActiva(null);
      setTabActiva(destino);
    } else {
      setVistaAnterior(vistaActiva);
      setVistaActiva(destino);
    }
  };

  if (vistaActiva === 'registrar') {
    return (
      <SafeAreaView style={s.contenedor}>
        <RegistrarSesion
          usuarioId={usuario?.id}
          plan={plan}
          diaFijado={diaParaRegistrar}
          onVolver={() => { setVistaActiva(vistaAnterior); setVistaAnterior(null); setDiaParaRegistrar(null); }}
        />
      </SafeAreaView>
    );
  }

  if (vistaActiva === 'gestion-cuenta') {
    return (
      <SafeAreaView style={s.contenedor}>
        <GestionCuenta
          usuario={usuario}
          onVolver={() => { setVistaActiva(vistaAnterior); setVistaAnterior(null); }}
          onCerrarSesion={onCerrarSesion}
        />
      </SafeAreaView>
    );
  }

  if (vistaActiva === 'config-notificaciones') {
    return (
      <SafeAreaView style={s.contenedor}>
        <ConfigNotificaciones
          onVolver={() => { setVistaActiva(vistaAnterior); setVistaAnterior(null); }}
          usuarioId={usuario?.id}
        />
      </SafeAreaView>
    );
  }

  if (vistaActiva === 'config-general') {
    return (
      <SafeAreaView style={s.contenedor}>
        <ConfigGeneral
          onVolver={() => { setVistaActiva(vistaAnterior); setVistaAnterior(null); }}
          onNavegar={manejarNavegar}
          usuarioId={usuario?.id}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={s.contenedor}>
      {tabActiva === 'hoy' && (
        <TabRutina
          nombre={usuario?.nombre}
          usuarioId={usuario?.id}
          plan={plan}
          onActualizarPlan={onActualizarPlan}
          onIrRegistrar={(dia) => { setDiaParaRegistrar(dia); setVistaActiva('registrar'); }}
        />
      )}
      {tabActiva === 'progreso' && (
        <TabProgreso 
          usuarioId={usuario?.id} 
          onVolver={vengoDesdePerfil ? () => { setTabActiva('perfil'); setVengoDesdePerfil(false); } : null}
        />
      )}
      {tabActiva === 'metricas' && <TabMetricas usuarioId={usuario?.id} />}
      {tabActiva === 'planes' && (
        <TabPlanes 
          usuarioId={usuario?.id} 
          planGlobal={plan} 
          onActualizarPlanGlobal={onActualizarPlan}
          onVolver={vengoDesdePerfil ? () => { setTabActiva('perfil'); setVengoDesdePerfil(false); } : null}
        />
      )}
      {tabActiva === 'coach' && <ChatCoach usuario={usuario} plan={plan} />}
      {tabActiva === 'perfil' && (
        <TabPerfil
          usuario={usuario}
          plan={plan}
          onCerrarSesion={onCerrarSesion}
          onNavegar={manejarNavegar}
        />
      )}

      <View style={s.tabBar}>
        {TABS.map((tab) => {
          const activa = tabActiva === tab.id;
          return (
            <TouchableOpacity key={tab.id} style={s.tabItem} onPress={() => { setTabActiva(tab.id); setVengoDesdePerfil(false); }}>
              <View style={[s.tabIconBg, activa && s.tabIconBgActivo]}>
                <Ionicons
                  name={activa ? tab.icono.replace('-outline', '') : tab.icono}
                  size={20}
                  color={activa ? COLORES.primario : COLORES.subtitulo}
                />
              </View>
              <Text style={[s.tabTexto, activa && s.tabTextoActivo]}>{tab.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  contenedor:      { flex: 1, backgroundColor: COLORES.oscuro },
  tabBar:          { position: 'absolute', bottom: 20, left: 20, right: 20, height: 74, backgroundColor: 'rgba(20, 27, 38, 0.95)', borderRadius: 25, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)', shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.5, shadowRadius: 20, elevation: 15 },
  tabItem:         { flex: 1, alignItems: 'center', justifyContent: 'center' },
  tabIconBg:       { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  tabIconBgActivo: { backgroundColor: 'rgba(108, 99, 255, 0.1)' },
  tabTexto:        { fontFamily: FUENTES.medio, fontSize: 10, color: COLORES.subtitulo },
  tabTextoActivo:  { color: COLORES.primario, fontFamily: FUENTES.negrita },
});

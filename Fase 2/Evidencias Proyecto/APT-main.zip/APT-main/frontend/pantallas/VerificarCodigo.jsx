import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { COLORES } from '../constantes/colores';
import { FUENTES, TAMANOS } from '../constantes/tipografia';
import { DISENO } from '../constantes/diseno';

export default function VerificarCodigo({ correo, onExito, onCancelar }) {
  const [codigo, setCodigo] = useState('');
  const [cargando, setCargando] = useState(false);

  const handleVerificar = async () => {
    if (codigo.length !== 6) {
      Alert.alert('Error', 'Ingresa el código de 6 dígitos');
      return;
    }

    setCargando(true);
    try {
      const BACKEND_URL = process.env.EXPO_PUBLIC_URL_API || 'http://localhost:8000';
      const response = await fetch(`${BACKEND_URL}/auth/verificar-codigo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo, codigo }),
      });

      const data = await response.json();
      if (data.exito) {
        onExito();
      } else {
        Alert.alert('Error', data.mensaje || 'Código incorrecto');
      }
    } catch (e) {
      Alert.alert('Error', 'No se pudo conectar con el servidor');
    } finally {
      setCargando(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={s.contenedor}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={s.circulo} />
      <Text style={s.titulo}>Verifica tu correo</Text>
      <Text style={s.subtitulo}>Hemos enviado un código a {correo}</Text>
      
      <TextInput
        style={s.campo}
        placeholder="123456"
        placeholderTextColor={COLORES.subtitulo}
        value={codigo}
        onChangeText={setCodigo}
        keyboardType="number-pad"
        maxLength={6}
      />

      <TouchableOpacity
        style={[s.boton, (codigo.length !== 6 || cargando) && s.botonDesactivado]}
        onPress={handleVerificar}
        disabled={codigo.length !== 6 || cargando}
      >
        <Text style={s.botonTexto}>{cargando ? 'Verificando...' : 'Confirmar código'}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onCancelar}>
        <Text style={s.btnCancelar}>Volver al registro</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  contenedor: { flex: 1, backgroundColor: COLORES.oscuro, padding: DISENO.paddingH, justifyContent: 'center', alignItems: 'center' },
  circulo: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: COLORES.primario, opacity: 0.1, top: -100, right: -100 },
  titulo: { fontFamily: FUENTES.negrita, fontSize: TAMANOS.h1, color: COLORES.blanco, marginBottom: 12 },
  subtitulo: { fontFamily: FUENTES.regular, fontSize: TAMANOS.base, color: COLORES.subtitulo, textAlign: 'center', marginBottom: 40 },
  campo: { backgroundColor: COLORES.tarjeta, borderRadius: DISENO.radio.md, width: '100%', height: 60, textAlign: 'center', fontSize: 32, fontFamily: FUENTES.negrita, color: COLORES.primario, letterSpacing: 10, marginBottom: 32, borderWidth: 1, borderColor: COLORES.borde },
  boton: { backgroundColor: COLORES.primario, borderRadius: DISENO.radio.lg, width: '100%', height: 56, justifyContent: 'center', alignItems: 'center', marginBottom: 24 },
  botonDesactivado: { opacity: 0.5 },
  botonTexto: { fontFamily: FUENTES.semiNegrita, fontSize: TAMANOS.lg, color: COLORES.blanco },
  btnCancelar: { fontFamily: FUENTES.medio, fontSize: TAMANOS.base, color: COLORES.subtitulo },
});

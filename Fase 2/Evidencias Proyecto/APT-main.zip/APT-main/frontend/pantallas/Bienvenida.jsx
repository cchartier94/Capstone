/**
 * @file Bienvenida.jsx
 * @description Pantalla de splash/landing de FitAI. Primera pantalla que ve el usuario.
 *              Muestra el branding, las características principales y los botones de acceso.
 */

import React from 'react'; // necesario para JSX
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, SafeAreaView,
} from 'react-native'; // componentes primitivos de UI
import { COLORES } from '../constantes/colores'; // paleta de colores del sistema de diseño
import { FUENTES, TAMANOS } from '../constantes/tipografia'; // familias tipográficas y tamaños de fuente
import { DISENO } from '../constantes/diseno'; // constantes de layout (paddings, radios, alturas)

/** Lista de características que se muestran en las cards de la pantalla de bienvenida. */
const CARACTERISTICAS = [
  { id: '1', texto: 'Plan de entrenamiento personalizado' },
  { id: '2', texto: 'IA que aprende de tu progreso' },
  { id: '3', texto: 'Seguimiento en tiempo real' },
];

/**
 * Pantalla de bienvenida con branding y acceso a registro/login.
 *
 * @param {object}   props
 * @param {Function} props.onCrearCuenta    - Callback al pulsar "Crear cuenta" (navega a Registro).
 * @param {Function} props.onIniciarSesion  - Callback al pulsar "Iniciar sesión" (navega a Login).
 * @returns {JSX.Element}
 */
export default function Bienvenida({ onCrearCuenta, onIniciarSesion }) {
  return (
    <SafeAreaView style={s.contenedor}>
      {/* Círculo decorativo de fondo */}
      <View style={s.circuloFondo} />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={s.scroll}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header con logo y nombre de la app */}
        <View style={s.header}>
          <View style={s.logo}>
            <Text style={s.logoTexto}>F</Text>
          </View>
          <Text style={s.saludo}>Bienvenido a</Text>
          <Text style={s.nombre}>FitAI</Text>
          <Text style={s.descripcion}>Tu coach inteligente de fitness personalizado</Text>
        </View>

        {/* Cards de características */}
        <View style={s.lista}>
          {CARACTERISTICAS.map((item) => (
            <View key={item.id} style={s.caracteristica}>
              <View style={s.caracteristicaIcono} />
              <Text style={s.caracteristicaTexto}>{item.texto}</Text>
            </View>
          ))}
        </View>

        {/* Botones de acción */}
        <View style={s.botones}>
          <TouchableOpacity style={s.botonPrimario} onPress={onCrearCuenta} activeOpacity={0.8}>
            <Text style={s.botonPrimarioTexto}>Crear cuenta</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.botonSecundario} onPress={onIniciarSesion} activeOpacity={0.8}>
            <Text style={s.botonSecundarioTexto}>Iniciar sesión</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  contenedor: {
    flex: 1,
    backgroundColor: COLORES.oscuro,
  },
  circuloFondo: {
    position: 'absolute',
    width: 600,
    height: 400,
    borderRadius: 200,
    backgroundColor: COLORES.primario,
    opacity: 0.1,
    top: -100,
    left: -105,
  },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: DISENO.paddingH,
    paddingTop: 60,
    paddingBottom: 40,
  },

  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logo: {
    width: 72,
    height: 72,
    borderRadius: 20,
    backgroundColor: COLORES.primario,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  logoTexto: {
    fontFamily: FUENTES.negrita,
    fontSize: 32,
    color: COLORES.blanco,
  },
  saludo: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.lg,
    color: COLORES.subtitulo,
    marginBottom: 4,
  },
  nombre: {
    fontFamily: FUENTES.negrita,
    fontSize: 44,
    color: COLORES.blanco,
    marginBottom: 12,
  },
  descripcion: {
    fontFamily: FUENTES.regular,
    fontSize: TAMANOS.base,
    color: COLORES.subtitulo,
    textAlign: 'center',
    lineHeight: 22,
  },

  lista: {
    gap: 12,
    marginBottom: 40,
  },
  caracteristica: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORES.tarjeta,
    borderRadius: DISENO.radio.md,
    height: 56,
    paddingHorizontal: 16,
    gap: 14,
  },
  caracteristicaIcono: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: COLORES.primario,
    opacity: 0.6,
    flexShrink: 0,
  },
  caracteristicaTexto: {
    fontFamily: FUENTES.medio,
    fontSize: TAMANOS.base,
    color: COLORES.blanco,
    flex: 1,
  },

  botones: {
    gap: 12,
  },
  botonPrimario: {
    backgroundColor: COLORES.primario,
    borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton,
    alignItems: 'center',
    justifyContent: 'center',
  },
  botonPrimarioTexto: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.lg,
    color: COLORES.blanco,
  },
  botonSecundario: {
    backgroundColor: COLORES.superficie,
    borderRadius: DISENO.radio.lg,
    height: DISENO.altoBoton,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORES.borde,
  },
  botonSecundarioTexto: {
    fontFamily: FUENTES.semiNegrita,
    fontSize: TAMANOS.lg,
    color: COLORES.blanco,
  },
});
